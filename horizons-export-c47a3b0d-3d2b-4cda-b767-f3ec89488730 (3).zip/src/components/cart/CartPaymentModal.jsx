import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useApp } from '@/contexts/AppContext';
import { CreditCard, Smartphone, DollarSign } from 'lucide-react';

export function CartPaymentModal({ isOpen, onClose, onConfirm }) {
  const { state, dispatch } = useApp();
  const { paymentMethod, changeFor } = state.cartState;

  const handlePaymentMethodChange = (method) => {
    dispatch({type: 'SET_PAYMENT_METHOD', payload: method});
  };

  const handleChangeForChange = (e) => {
    dispatch({type: 'SET_CHANGE_FOR', payload: e.target.value});
  };

  const paymentOptions = [
    { name: 'Cartão de Crédito', icon: CreditCard },
    { name: 'Cartão de Débito', icon: CreditCard },
    { name: 'Pix', icon: Smartphone },
    { name: 'Dinheiro', icon: DollarSign },
  ];
  
  const modalBgColor = 'var(--primary-dynamic)';
  const modalTextColor = 'var(--button-text-dynamic)';
  const buttonActiveBg = 'var(--button-text-dynamic)';
  const buttonActiveText = 'var(--primary-dynamic)';
  const buttonInactiveBg = 'transparent';
  const buttonInactiveBorder = 'hsla(var(--button-text-dynamic_rgb), 0.5)';
  const buttonInactiveText = 'var(--button-text-dynamic)';
  const inputBg = 'hsla(var(--button-text-dynamic_rgb), 0.1)';
  const inputBorder = 'hsla(var(--button-text-dynamic_rgb), 0.5)';
  const inputPlaceholder = 'hsla(var(--button-text-dynamic_rgb), 0.7)';


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className="sm:max-w-md" 
        style={{ backgroundColor: modalBgColor, color: modalTextColor, borderColor: 'hsla(var(--button-text-dynamic_rgb),0.3)' }}
      >
        <DialogHeader>
          <DialogTitle className="text-2xl text-center" style={{ color: modalTextColor }}>Escolha a forma de pagamento</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-3">
            {paymentOptions.map((option) => {
              const Icon = option.icon;
              const isActive = paymentMethod === option.name;
              return (
                <Button
                  key={option.name}
                  variant={isActive ? 'default' : 'outline'}
                  onClick={() => handlePaymentMethodChange(option.name)}
                  className={`h-auto py-3 flex flex-col items-center justify-center space-y-1 text-sm transition-all duration-200`}
                  style={{
                    backgroundColor: isActive ? buttonActiveBg : buttonInactiveBg,
                    color: isActive ? buttonActiveText : buttonInactiveText,
                    borderColor: isActive ? 'transparent' : buttonInactiveBorder,
                  }}
                >
                  <Icon className="h-6 w-6 mb-1" />
                  <span>{option.name}</span>
                </Button>
              );
            })}
          </div>

          {paymentMethod === 'Dinheiro' && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2 pt-2"
            >
              <label htmlFor="changeFor" className="block text-sm font-medium" style={{ color: modalTextColor }}>
                Troco para quanto? (Opcional)
              </label>
              <Input
                id="changeFor"
                type="number"
                value={changeFor}
                onChange={handleChangeForChange}
                placeholder="Ex: 50.00"
                style={{ backgroundColor: inputBg, borderColor: inputBorder, color: modalTextColor }}
                className={`placeholder-[${inputPlaceholder}] focus:bg-[hsla(var(--button-text-dynamic_rgb),0.2)]`}
              />
            </motion.div>
          )}
        </div>
        <DialogFooter className="sm:justify-between gap-2">
          <DialogClose asChild>
            <Button 
                type="button" 
                variant="outline" 
                className="w-full sm:w-auto"
                style={{ 
                    backgroundColor: buttonInactiveBg, 
                    borderColor: buttonInactiveBorder, 
                    color: buttonInactiveText,
                }}
            >
              Cancelar
            </Button>
          </DialogClose>
          <Button 
            type="button" 
            onClick={() => onConfirm(paymentMethod, changeFor)} 
            style={{ backgroundColor: 'var(--secondary-dynamic)', color: 'var(--button-text-dynamic)'}}
            className="w-full sm:w-auto hover:brightness-90"
        >
            Confirmar e Enviar Pedido
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}