import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CartItem } from './CartItem';
import { CartSummary } from './CartSummary';
import { CartPaymentModal } from './CartPaymentModal';
import { CouponInput } from './CouponInput';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function Cart({ isOpen, onClose }) {
  const { state, dispatch } = useApp();
  const { cart, customerName, customerPhone, deliveryType, deliveryAddress, appliedCoupon, orderObservations } = state.cartState;
  const { settings } = state.settingsState;

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  const handleOpenPaymentModal = () => {
     if (cart.length === 0) {
      toast({ title: "Carrinho vazio", description: "Adicione itens ao carrinho.", variant: "destructive" });
      return;
    }
    if (!customerName) {
      toast({ title: "Nome do cliente", description: "Por favor, informe seu nome.", variant: "destructive" });
      return;
    }
    if (deliveryType === 'delivery' && (!deliveryAddress.neighborhood || !deliveryAddress.street || !deliveryAddress.number)) {
      toast({ title: "Endereço incompleto", description: "Preencha o endereço de entrega.", variant: "destructive" });
      return;
    }
    setIsPaymentModalOpen(true);
  };

  const handleConfirmPayment = (paymentMethod, changeFor) => {
    if (!paymentMethod) {
      toast({ title: "Forma de Pagamento", description: "Selecione uma forma de pagamento.", variant: "destructive" });
      return;
    }
    
    const subtotal = cart.reduce((total, item) => {
      const itemTotal = item.price * item.quantity;
      const additionalsTotal = item.selectedAdditionals.reduce((addTotal, additional) => 
        addTotal + (additional.price * item.quantity), 0
      );
      return total + itemTotal + additionalsTotal;
    }, 0);

    let discount = 0;
    if (appliedCoupon) {
      if (appliedCoupon.type === 'percentage') {
        discount = (subtotal * appliedCoupon.value) / 100;
      } else if (appliedCoupon.type === 'fixed') {
        discount = appliedCoupon.value;
      }
      discount = Math.min(discount, subtotal); 
    }
    const totalAfterDiscount = subtotal - discount;
    const total = totalAfterDiscount + (deliveryType === 'delivery' ? state.cartState.deliveryFee : 0);

    if (paymentMethod === 'Dinheiro' && changeFor && parseFloat(changeFor) < total) {
      toast({ title: "Troco Inválido", description: "O valor do troco deve ser maior ou igual ao total do pedido.", variant: "destructive" });
      return;
    }
    setIsPaymentModalOpen(false);
    generateWhatsAppMessage(paymentMethod, changeFor, subtotal, discount, total);
  };

  const generateWhatsAppMessage = (paymentMethod, changeFor, subtotal, discount, total) => {
    let message = `🍽️ *NOVO PEDIDO - ${settings.companyName}*\n\n`;
    message += `👤 *Cliente:* ${customerName}\n`;
    if (customerPhone) {
      message += `📞 *Telefone:* ${customerPhone}\n`;
    }
    message += `\n`;
    
    message += `📋 *ITENS DO PEDIDO:*\n`;
    cart.forEach((item, index) => {
      message += `\n${index + 1}. *${item.name}*\n`;
      message += `   Quantidade: ${item.quantity}\n`;
      message += `   Preço unitário: R$ ${item.price.toFixed(2)}\n`;
      
      if (item.selectedAdditionals.length > 0) {
        message += `   Adicionais:\n`;
        item.selectedAdditionals.forEach(additional => {
          message += `   • ${additional.name} (+R$ ${additional.price.toFixed(2)})\n`;
        });
      }
      
      if (item.observations) {
        message += `   Observações do item: ${item.observations}\n`;
      }
      
      const itemTotalCalc = (item.price * item.quantity) + 
        item.selectedAdditionals.reduce((totalCalc, additional) => totalCalc + (additional.price * item.quantity), 0);
      message += `   Subtotal do item: R$ ${itemTotalCalc.toFixed(2)}\n`;
    });

    if (orderObservations) {
      message += `\n📝 *Observações Gerais do Pedido:* ${orderObservations}\n`;
    }

    message += `\n💰 *RESUMO DO PEDIDO:*\n`;
    message += `Subtotal dos itens: R$ ${subtotal.toFixed(2)}\n`;

    if (appliedCoupon) {
      message += `🎟️ Cupom Aplicado (${appliedCoupon.id}): -R$ ${discount.toFixed(2)}\n`;
      message += `Subtotal com desconto: R$ ${(subtotal - discount).toFixed(2)}\n`;
    }
    
    if (deliveryType === 'delivery') {
      message += `Taxa de entrega: R$ ${state.cartState.deliveryFee.toFixed(2)}\n`;
    }
    message += `*TOTAL: R$ ${total.toFixed(2)}*\n\n`;

    message += `💳 *FORMA DE PAGAMENTO:* ${paymentMethod}\n`;
    if (paymentMethod === 'Dinheiro' && changeFor) {
      message += `   Troco para: R$ ${parseFloat(changeFor).toFixed(2)}\n`;
    }
    message += `\n`;
    
    if (deliveryType === 'delivery') {
      message += `🚚 *ENTREGA:*\n`;
      message += `Endereço: ${deliveryAddress.street}, ${deliveryAddress.number}\n`;
      if (deliveryAddress.complement) {
        message += `Complemento: ${deliveryAddress.complement}\n`;
      }
      message += `Bairro: ${deliveryAddress.neighborhood}\n`;
      if (deliveryAddress.zipCode) {
        message += `CEP: ${deliveryAddress.zipCode}\n`;
      }
    } else {
      message += `🏪 *RETIRADA NO LOCAL:*\n`;
      message += `Endereço: ${settings.address.street}, ${settings.address.neighborhood}\n`;
    }

    const orderData = {
      customerName,
      customerPhone,
      items: cart,
      orderObservations,
      deliveryType,
      deliveryAddress,
      deliveryFee: state.cartState.deliveryFee,
      paymentMethod,
      changeFor,
      subtotal,
      discount,
      total,
      appliedCoupon: appliedCoupon ? appliedCoupon.id : null,
      whatsappMessage: message,
    };
    dispatch({ type: 'ADD_ORDER', payload: orderData });
    
    const newOrderEvent = new CustomEvent('newOrderEvent', { detail: orderData });
    window.dispatchEvent(newOrderEvent);


    if (appliedCoupon) {
      dispatch({ type: 'INCREMENT_COUPON_USAGE', payload: { couponId: appliedCoupon.id, customerIdentifier: customerPhone || customerName } });
    }

    if (settings.whatsappIntegrationEnabled) {
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/${settings.whatsapp}?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
    }
    
    dispatch({ type: 'CLEAR_CART' });
    onClose();
    
    toast({
      title: "Pedido enviado!",
      description: "Seu pedido foi registrado. Aguarde o contato!",
    });
  };


  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
            />
            <motion.div
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl"
              style={{ backgroundColor: 'var(--background-dynamic)'}}
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b" style={{backgroundColor: 'var(--primary-dynamic)', color: 'var(--button-text-dynamic)'}}>
                  <h2 className="text-xl font-bold flex items-center">
                    <ShoppingBag className="h-6 w-6 mr-2" />
                    Seu Pedido ({cart.reduce((total, item) => total + item.quantity, 0)})
                  </h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                    style={{color: 'var(--button-text-dynamic)', backgroundColor: 'hsla(var(--secondary-dynamic_rgb), 0.2)', borderColor: 'var(--secondary-dynamic)'}}
                    className="hover:bg-[hsla(var(--secondary-dynamic_rgb),0.3)]"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
                  {cart.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full" style={{color: 'var(--text-secondary-dynamic)'}}>
                      <ShoppingBag className="h-16 w-16 mb-4 opacity-50" />
                      <p className="text-lg font-medium">Carrinho vazio</p>
                      <p className="text-sm">Adicione itens para continuar</p>
                    </div>
                  ) : (
                    <>
                      {cart.map((item) => (
                        <CartItem key={item.cartId} item={item} />
                      ))}
                      {orderObservations && (
                        <div className="p-3 border rounded-lg" style={{borderColor: 'var(--secondary-dynamic)55', backgroundColor: 'hsla(var(--secondary-dynamic_rgb), 0.1)'}}>
                          <p className="text-sm font-medium mb-1" style={{color: 'var(--text-secondary-dynamic)'}}>Observações Gerais:</p>
                          <p className="text-xs" style={{color: 'hsla(var(--text-secondary-dynamic_rgb), 0.8)'}}>{orderObservations}</p>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="border-t p-4 space-y-4" style={{backgroundColor: 'var(--background-dynamic)', borderColor: 'hsla(var(--primary-dynamic_rgb), 0.2)'}}>
                    <CouponInput />
                    <CartSummary />
                    <Button
                      onClick={handleOpenPaymentModal}
                      className="w-full dynamic-button"
                      size="lg"
                    >
                      <MessageCircle className="h-5 w-5 mr-2" />
                      Escolher Pagamento e Finalizar
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <CartPaymentModal 
        isOpen={isPaymentModalOpen} 
        onClose={() => setIsPaymentModalOpen(false)} 
        onConfirm={handleConfirmPayment} 
      />
    </>
  );
}