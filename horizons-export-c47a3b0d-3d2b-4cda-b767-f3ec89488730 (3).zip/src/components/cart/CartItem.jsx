import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus, Trash2, User as UserIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function CartItem({ item }) {
  const { dispatch, state } = useApp();
  const { customerName } = state.cartState;

  const updateQuantity = (cartId, newQuantity) => {
    if (newQuantity === 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { cartId, quantity: newQuantity } });
    }
  };

  const removeItem = (cartId) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
    toast({
      title: "Item removido",
      description: "Item removido do carrinho com sucesso.",
    });
  };
  
  if (!item) return null;


  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      {item.cartId === state.cartState.cart[0]?.cartId && (
        <div className="p-3 rounded-lg mb-3" style={{backgroundColor: 'hsla(var(--primary-dynamic_rgb), 0.1)'}}>
          <p className="text-sm flex items-center" style={{color: 'var(--primary-dynamic)'}}>
            <UserIcon className="h-4 w-4 mr-2"/>
            Pedido para: <span className="font-semibold ml-1">{customerName || "Cliente não informado"}</span>
          </p>
        </div>
      )}
      <Card style={{borderColor: 'hsla(var(--primary-dynamic_rgb), 0.2)', backgroundColor: 'var(--background-dynamic)'}}>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <h3 className="font-medium" style={{color: 'var(--text-primary-dynamic)'}}>{item.name}</h3>
              <p className="text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>R$ {item.price.toFixed(2)} cada</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => removeItem(item.cartId)}
              className="text-red-500 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>

          {item.selectedAdditionals.length > 0 && (
            <div className="mb-3">
              <p className="text-xs font-medium mb-1" style={{color: 'var(--primary-dynamic)'}}>Adicionais:</p>
              {item.selectedAdditionals.map((additional) => (
                <p key={additional.id} className="text-xs" style={{color: 'var(--text-secondary-dynamic)'}}>
                  • {additional.name} (+R$ {additional.price.toFixed(2)})
                </p>
              ))}
            </div>
          )}

          {item.observations && (
            <div className="mb-3">
              <p className="text-xs font-medium mb-1" style={{color: 'var(--primary-dynamic)'}}>Observações do item:</p>
              <p className="text-xs" style={{color: 'var(--text-secondary-dynamic)'}}>{item.observations}</p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateQuantity(item.cartId, item.quantity - 1)}
                className="h-8 w-8 p-0 dynamic-button-outline"
              >
                <Minus className="h-3 w-3" />
              </Button>
              <span className="font-medium w-8 text-center" style={{color: 'var(--text-secondary-dynamic)'}}>{item.quantity}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateQuantity(item.cartId, item.quantity + 1)}
                className="h-8 w-8 p-0 dynamic-button-outline"
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="text-right">
              <p className="font-bold" style={{color: 'var(--primary-dynamic)'}}>
                R$ {((item.price * item.quantity) + 
                  item.selectedAdditionals.reduce((totalCalc, additional) => 
                    totalCalc + (additional.price * item.quantity), 0
                  )).toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}