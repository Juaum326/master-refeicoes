import React from 'react';
import { useApp } from '@/contexts/AppContext';

export function CartSummary() {
  const { state } = useApp();
  const { cart, deliveryType, deliveryFee, appliedCoupon } = state.cartState;

  const subtotal = cart.reduce((total, item) => {
    const itemTotal = item.price * item.quantity;
    const additionalsTotal = item.selectedAdditionals.reduce((addTotal, additional) => 
      addTotal + (additional.price * item.quantity), 0
    );
    return total + itemTotal + additionalsTotal;
  }, 0);

  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.type === 'percentage') {
      discount = (subtotal * appliedCoupon.value) / 100;
    } else if (appliedCoupon.type === 'fixed') {
      discount = appliedCoupon.value;
    }
    discount = Math.min(discount, subtotal);
  }

  const totalAfterDiscount = subtotal - discount;
  const total = totalAfterDiscount + (deliveryType === 'delivery' ? deliveryFee : 0);

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>
        <span>Subtotal dos itens:</span>
        <span>R$ {subtotal.toFixed(2)}</span>
      </div>
      {appliedCoupon && (
        <>
          <div className="flex justify-between text-sm text-green-600">
            <span>Desconto ({appliedCoupon.id}):</span>
            <span>- R$ {discount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm font-medium" style={{color: 'var(--text-secondary-dynamic)'}}>
            <span>Subtotal com Desconto:</span>
            <span>R$ {totalAfterDiscount.toFixed(2)}</span>
          </div>
        </>
      )}
      {deliveryType === 'delivery' && deliveryFee > 0 && (
        <div className="flex justify-between text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>
          <span>Taxa de entrega:</span>
          <span>R$ {deliveryFee.toFixed(2)}</span>
        </div>
      )}
      <div className="flex justify-between font-bold text-lg border-t pt-2" style={{borderColor: 'hsla(var(--primary-dynamic_rgb), 0.2)'}}>
        <span style={{color: 'var(--primary-dynamic)'}}>Total:</span>
        <span style={{color: 'var(--primary-dynamic)'}}>R$ {total.toFixed(2)}</span>
      </div>
    </div>
  );
}