import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tag, X } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function CouponInput() {
  const { state, dispatch } = useApp();
  const { appliedCoupon, customerName, customerPhone, cart } = state.cartState;
  const { coupons } = state.salesState;

  const [couponCode, setCouponCode] = useState('');

  useEffect(() => {
    if (appliedCoupon) {
      setCouponCode(appliedCoupon.id);
    } else {
      setCouponCode('');
    }
  }, [appliedCoupon]);

  const subtotal = cart.reduce((total, item) => {
    const itemTotal = item.price * item.quantity;
    const additionalsTotal = item.selectedAdditionals.reduce((addTotal, additional) => 
      addTotal + (additional.price * item.quantity), 0
    );
    return total + itemTotal + additionalsTotal;
  }, 0);

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast({ title: "Cupom inválido", description: "Digite um código de cupom.", variant: "destructive" });
      return;
    }
    const coupon = coupons.find(c => c.name.toUpperCase() === couponCode.toUpperCase() && c.active);

    if (!coupon) {
      toast({ title: "Cupom inválido", description: "Este cupom não existe ou não está ativo.", variant: "destructive" });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    if (new Date(coupon.validUntil) < new Date(today)) {
      toast({ title: "Cupom expirado", description: "Este cupom já expirou.", variant: "destructive" });
      dispatch({ type: 'UPDATE_COUPON', payload: { ...coupon, active: false } });
      return;
    }

    if (coupon.usedCount >= coupon.limit) {
      toast({ title: "Limite atingido", description: "Este cupom atingiu o limite de usos.", variant: "destructive" });
      dispatch({ type: 'UPDATE_COUPON', payload: { ...coupon, active: false } });
      return;
    }

    if (coupon.singleUsePerCustomer && coupon.usedByCustomers.includes(customerPhone || customerName)) {
      toast({ title: "Cupom já utilizado", description: "Você já utilizou este cupom.", variant: "destructive" });
      return;
    }
    
    if (coupon.minValue && subtotal < coupon.minValue) {
        toast({ title: "Valor mínimo não atingido", description: `Este cupom requer um pedido mínimo de R$ ${coupon.minValue.toFixed(2)}.`, variant: "destructive" });
        return;
    }

    dispatch({ type: 'APPLY_COUPON', payload: coupon });
    toast({ title: "Cupom aplicado!", description: `Desconto de ${coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`} aplicado.` });
  };

  const handleRemoveCoupon = () => {
    dispatch({ type: 'REMOVE_COUPON' });
    toast({ title: "Cupom removido." });
  };

  return (
    <div className="space-y-1">
      <label className="text-sm font-medium" style={{color: 'var(--text-secondary-dynamic)'}}>Cupom de Desconto</label>
      <div className="flex space-x-2">
        <Input 
          placeholder="Digite seu cupom" 
          value={couponCode}
          onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
          className="flex-grow"
          style={{borderColor: 'hsla(var(--primary-dynamic_rgb), 0.35)'}}
          disabled={!!appliedCoupon}
        />
        {appliedCoupon ? (
            <Button variant="destructive" onClick={handleRemoveCoupon} size="sm"><X className="h-4 w-4 mr-1"/>Remover</Button>
        ) : (
            <Button onClick={handleApplyCoupon} className="dynamic-button" size="sm"><Tag className="h-4 w-4 mr-1"/>Aplicar</Button>
        )}
      </div>
    </div>
  );
}