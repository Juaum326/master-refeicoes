import React, { useState, useEffect } from 'react';
import { Bell, BellOff, Settings, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.jsx";
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function NotificationBell() {
  const { state, dispatch } = useApp();
  const { notificationPreferences } = state.settingsState.settings;
  const [hasNew, setHasNew] = useState(false); 

  const handlePreferenceChange = (key, value) => {
    dispatch({ type: 'UPDATE_NOTIFICATION_PREFERENCES', payload: { [key]: value } });
    toast({ title: "Preferências de Notificação Atualizadas!" });
  };
  
  const toggleAllNotifications = () => {
    const newAllEnabledStatus = !notificationPreferences.allEnabled;
    dispatch({ type: 'UPDATE_NOTIFICATION_PREFERENCES', payload: { 
        allEnabled: newAllEnabledStatus,
        newOrder: newAllEnabledStatus,
        salesBooster: newAllEnabledStatus,
        intelligentManager: newAllEnabledStatus,
      } 
    });
     toast({ title: `Notificações ${newAllEnabledStatus ? 'Ativadas' : 'Desativadas'}!` });
  };


  useEffect(() => {
    const newOrderListener = (event) => {
      if (notificationPreferences.allEnabled && notificationPreferences.newOrder) {
        toast({
          title: "🛎️ Novo Pedido Recebido!",
          description: `Pedido #${event.detail.id} de ${event.detail.customerName}.`,
          duration: 10000,
        });
        setHasNew(true);
      }
    };
    
    const salesBoosterListener = (event) => {
        if (notificationPreferences.allEnabled && notificationPreferences.salesBooster) {
            toast({
                title: "💡 Dica do Impulsionador!",
                description: event.detail.message,
                duration: 10000,
            });
            setHasNew(true);
        }
    };

    const intelligentManagerListener = (event) => {
        if (notificationPreferences.allEnabled && notificationPreferences.intelligentManager) {
            toast({
                title: "🤖 Insight do Gestor!",
                description: event.detail.message,
                duration: 10000,
            });
            setHasNew(true);
        }
    };

    window.addEventListener('newOrderEvent', newOrderListener);
    window.addEventListener('salesBoosterInsightEvent', salesBoosterListener);
    window.addEventListener('intelligentManagerInsightEvent', intelligentManagerListener);

    return () => {
      window.removeEventListener('newOrderEvent', newOrderListener);
      window.removeEventListener('salesBoosterInsightEvent', salesBoosterListener);
      window.removeEventListener('intelligentManagerInsightEvent', intelligentManagerListener);
    };
  }, [notificationPreferences, toast]);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <DropdownMenu onOpenChange={() => setHasNew(false)}>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="icon" className="rounded-full h-12 w-12 shadow-lg bg-card hover:bg-accent">
            {notificationPreferences.allEnabled ? <Bell className="h-6 w-6 text-primary" /> : <BellOff className="h-6 w-6 text-muted-foreground" />}
            {hasNew && notificationPreferences.allEnabled && (
              <span className="absolute top-0 right-0 block h-3 w-3 rounded-full bg-red-500 ring-2 ring-white" />
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-72 mr-2 mb-1" side="top" align="end">
          <DropdownMenuLabel className="flex items-center justify-between">
            <span>Notificações</span>
            <Button variant="ghost" size="sm" onClick={toggleAllNotifications} className="h-auto p-1">
                {notificationPreferences.allEnabled ? <Check className="h-4 w-4 text-green-500"/> : <X className="h-4 w-4 text-red-500"/>}
                <span className="ml-1 text-xs">{notificationPreferences.allEnabled ? 'Ativas' : 'Inativas'}</span>
            </Button>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="flex items-center justify-between" onSelect={(e) => e.preventDefault()}>
            <Label htmlFor="newOrderNotif">Novos Pedidos</Label>
            <Switch
              id="newOrderNotif"
              checked={notificationPreferences.newOrder}
              onCheckedChange={(checked) => handlePreferenceChange('newOrder', checked)}
              disabled={!notificationPreferences.allEnabled}
            />
          </DropdownMenuItem>
          <DropdownMenuItem className="flex items-center justify-between" onSelect={(e) => e.preventDefault()}>
            <Label htmlFor="salesBoosterNotif">Dicas (Impulsionador)</Label>
            <Switch
              id="salesBoosterNotif"
              checked={notificationPreferences.salesBooster}
              onCheckedChange={(checked) => handlePreferenceChange('salesBooster', checked)}
              disabled={!notificationPreferences.allEnabled}
            />
          </DropdownMenuItem>
          <DropdownMenuItem className="flex items-center justify-between" onSelect={(e) => e.preventDefault()}>
            <Label htmlFor="managerNotif">Análises (Gestor)</Label>
            <Switch
              id="managerNotif"
              checked={notificationPreferences.intelligentManager}
              onCheckedChange={(checked) => handlePreferenceChange('intelligentManager', checked)}
              disabled={!notificationPreferences.allEnabled}
            />
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}