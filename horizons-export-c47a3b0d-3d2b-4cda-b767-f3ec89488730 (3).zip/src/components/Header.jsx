import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, MapPin, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/contexts/AppContext';

export function Header({ onCartClick }) {
  const { state } = useApp();
  const { cart } = state.cartState;
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;


  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);
  
  const headerStyle = {
    background: `linear-gradient(135deg, ${visualSettings.colors.primary} 0%, ${visualSettings.colors.secondary} 100%)`,
  };

  return (
    <motion.header 
      className="sticky top-0 z-50 shadow-lg"
      style={headerStyle}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {visualSettings.images.logo && (
              <img 
                src={visualSettings.images.logo} 
                alt={settings.companyName}
                className="h-12 w-12 rounded-full object-cover border-2 border-white/30"
              />
            )}
            <div>
              <h1 className="text-2xl font-bold" style={{ color: visualSettings.colors.buttonText }}>{settings.companyName}</h1>
              <div className="flex items-center text-sm" style={{ color: visualSettings.colors.buttonText, opacity: 0.8 }}>
                <MapPin className="h-4 w-4 mr-1" />
                <span>{settings.address.neighborhood}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center" style={{ color: visualSettings.colors.buttonText, opacity: 0.9 }}>
              <Phone className="h-4 w-4 mr-2" />
              <span className="text-sm">{settings.phone}</span>
            </div>
            
            <Button
              onClick={onCartClick}
              variant="secondary"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                color: visualSettings.colors.buttonText,
                borderColor: 'rgba(255, 255, 255, 0.3)'
              }}
              className="relative hover:bg-white/30"
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Carrinho
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-red-500 text-white min-w-[20px] h-5 flex items-center justify-center text-xs">
                  {cartItemsCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </div>
    </motion.header>
  );
}