import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, Trash2, ShoppingBag, MessageCircle, User as UserIcon, CreditCard, Smartphone, DollarSign, Landmark, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function Cart({ isOpen, onClose }) {
  const { state, dispatch } = useApp();
  const { cart, customerName, customerPhone, deliveryType, deliveryAddress, deliveryFee, orderObservations, appliedCoupon } = state.cartState;
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;
  const { coupons } = state.salesState;

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [changeFor, setChangeFor] = useState('');
  const [couponCode, setCouponCode] = useState('');

  useEffect(() => {
    if (appliedCoupon) {
      setCouponCode(appliedCoupon.id);
    } else {
      setCouponCode('');
    }
  }, [appliedCoupon]);

  const subtotal = cart.reduce((total, item) => {
    const itemTotal = item.price * item.quantity;
    const additionalsTotal = item.selectedAdditionals.reduce((addTotal, additional) => 
      addTotal + (additional.price * item.quantity), 0
    );
    return total + itemTotal + additionalsTotal;
  }, 0);

  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.type === 'percentage') {
      discount = (subtotal * appliedCoupon.value) / 100;
    } else if (appliedCoupon.type === 'fixed') {
      discount = appliedCoupon.value;
    }
    discount = Math.min(discount, subtotal); 
  }

  const totalAfterDiscount = subtotal - discount;
  const total = totalAfterDiscount + (deliveryType === 'delivery' ? deliveryFee : 0);

  const updateQuantity = (cartId, newQuantity) => {
    if (newQuantity === 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { cartId, quantity: newQuantity } });
    }
  };

  const removeItem = (cartId) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
    toast({
      title: "Item removido",
      description: "Item removido do carrinho com sucesso.",
    });
  };

  const handleOpenPaymentModal = () => {
     if (cart.length === 0) {
      toast({ title: "Carrinho vazio", description: "Adicione itens ao carrinho.", variant: "destructive" });
      return;
    }
    if (!customerName) {
      toast({ title: "Nome do cliente", description: "Por favor, informe seu nome.", variant: "destructive" });
      return;
    }
    if (deliveryType === 'delivery' && (!deliveryAddress.neighborhood || !deliveryAddress.street || !deliveryAddress.number)) {
      toast({ title: "Endereço incompleto", description: "Preencha o endereço de entrega.", variant: "destructive" });
      return;
    }
    setIsPaymentModalOpen(true);
  };

  const handleConfirmPayment = () => {
    if (!paymentMethod) {
      toast({ title: "Forma de Pagamento", description: "Selecione uma forma de pagamento.", variant: "destructive" });
      return;
    }
    if (paymentMethod === 'Dinheiro' && changeFor && parseFloat(changeFor) < total) {
      toast({ title: "Troco Inválido", description: "O valor do troco deve ser maior ou igual ao total do pedido.", variant: "destructive" });
      return;
    }
    setIsPaymentModalOpen(false);
    generateWhatsAppMessage();
  };

  const generateWhatsAppMessage = () => {
    let message = `🍽️ *NOVO PEDIDO - ${settings.companyName}*\n\n`;
    message += `👤 *Cliente:* ${customerName}\n`;
    if (customerPhone) {
      message += `📞 *Telefone:* ${customerPhone}\n`;
    }
    message += `\n`;
    
    message += `📋 *ITENS DO PEDIDO:*\n`;
    cart.forEach((item, index) => {
      message += `\n${index + 1}. *${item.name}*\n`;
      message += `   Quantidade: ${item.quantity}\n`;
      message += `   Preço unitário: R$ ${item.price.toFixed(2)}\n`;
      
      if (item.selectedAdditionals.length > 0) {
        message += `   Adicionais:\n`;
        item.selectedAdditionals.forEach(additional => {
          message += `   • ${additional.name} (+R$ ${additional.price.toFixed(2)})\n`;
        });
      }
      
      if (item.observations) {
        message += `   Observações do item: ${item.observations}\n`;
      }
      
      const itemTotalCalc = (item.price * item.quantity) + 
        item.selectedAdditionals.reduce((totalCalc, additional) => totalCalc + (additional.price * item.quantity), 0);
      message += `   Subtotal do item: R$ ${itemTotalCalc.toFixed(2)}\n`;
    });

    if (orderObservations) {
      message += `\n📝 *Observações Gerais do Pedido:* ${orderObservations}\n`;
    }

    message += `\n💰 *RESUMO DO PEDIDO:*\n`;
    message += `Subtotal dos itens: R$ ${subtotal.toFixed(2)}\n`;

    if (appliedCoupon) {
      message += `🎟️ Cupom Aplicado (${appliedCoupon.id}): -R$ ${discount.toFixed(2)}\n`;
      message += `Subtotal com desconto: R$ ${totalAfterDiscount.toFixed(2)}\n`;
    }
    
    if (deliveryType === 'delivery') {
      message += `Taxa de entrega: R$ ${deliveryFee.toFixed(2)}\n`;
    }
    message += `*TOTAL: R$ ${total.toFixed(2)}*\n\n`;

    message += `💳 *FORMA DE PAGAMENTO:* ${paymentMethod}\n`;
    if (paymentMethod === 'Dinheiro' && changeFor) {
      message += `   Troco para: R$ ${parseFloat(changeFor).toFixed(2)}\n`;
    }
    message += `\n`;
    
    if (deliveryType === 'delivery') {
      message += `🚚 *ENTREGA:*\n`;
      message += `Endereço: ${deliveryAddress.street}, ${deliveryAddress.number}\n`;
      if (deliveryAddress.complement) {
        message += `Complemento: ${deliveryAddress.complement}\n`;
      }
      message += `Bairro: ${deliveryAddress.neighborhood}\n`;
      if (deliveryAddress.zipCode) {
        message += `CEP: ${deliveryAddress.zipCode}\n`;
      }
    } else {
      message += `🏪 *RETIRADA NO LOCAL:*\n`;
      message += `Endereço: ${settings.address.street}, ${settings.address.neighborhood}\n`;
    }

    const orderData = {
      customerName,
      customerPhone,
      items: cart,
      orderObservations,
      deliveryType,
      deliveryAddress,
      deliveryFee,
      paymentMethod,
      changeFor,
      subtotal,
      discount,
      total,
      appliedCoupon: appliedCoupon ? appliedCoupon.id : null,
      whatsappMessage: message,
    };
    dispatch({ type: 'ADD_ORDER', payload: orderData });

    if (appliedCoupon) {
      dispatch({ type: 'INCREMENT_COUPON_USAGE', payload: { couponId: appliedCoupon.id, customerIdentifier: customerPhone || customerName } });
    }

    if (settings.whatsappIntegrationEnabled) {
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/${settings.whatsapp}?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
    }
    
    dispatch({ type: 'CLEAR_CART' });
    setPaymentMethod('');
    setChangeFor('');
    onClose();
    
    toast({
      title: "Pedido enviado!",
      description: "Seu pedido foi registrado. Aguarde o contato!",
    });
  };

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast({ title: "Cupom inválido", description: "Digite um código de cupom.", variant: "destructive" });
      return;
    }
    const coupon = coupons.find(c => c.name.toUpperCase() === couponCode.toUpperCase() && c.active);

    if (!coupon) {
      toast({ title: "Cupom inválido", description: "Este cupom não existe ou não está ativo.", variant: "destructive" });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    if (new Date(coupon.validUntil) < new Date(today)) {
      toast({ title: "Cupom expirado", description: "Este cupom já expirou.", variant: "destructive" });
      dispatch({ type: 'UPDATE_COUPON', payload: { ...coupon, active: false } });
      return;
    }

    if (coupon.usedCount >= coupon.limit) {
      toast({ title: "Limite atingido", description: "Este cupom atingiu o limite de usos.", variant: "destructive" });
      dispatch({ type: 'UPDATE_COUPON', payload: { ...coupon, active: false } });
      return;
    }

    if (coupon.singleUsePerCustomer && coupon.usedByCustomers.includes(customerPhone || customerName)) {
      toast({ title: "Cupom já utilizado", description: "Você já utilizou este cupom.", variant: "destructive" });
      return;
    }
    
    if (coupon.minValue && subtotal < coupon.minValue) {
        toast({ title: "Valor mínimo não atingido", description: `Este cupom requer um pedido mínimo de R$ ${coupon.minValue.toFixed(2)}.`, variant: "destructive" });
        return;
    }

    dispatch({ type: 'APPLY_COUPON', payload: coupon });
    toast({ title: "Cupom aplicado!", description: `Desconto de ${coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`} aplicado.` });
  };

  const handleRemoveCoupon = () => {
    dispatch({ type: 'REMOVE_COUPON' });
    toast({ title: "Cupom removido." });
  };

  const paymentOptions = [
    { name: 'Cartão de Crédito', icon: CreditCard },
    { name: 'Cartão de Débito', icon: CreditCard },
    { name: 'Pix', icon: Smartphone },
    { name: 'Dinheiro', icon: DollarSign },
  ];

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
            />
            <motion.div
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl"
              style={{ backgroundColor: 'var(--background-dynamic)'}}
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b" style={{backgroundColor: 'var(--primary-dynamic)', color: 'var(--button-text-dynamic)'}}>
                  <h2 className="text-xl font-bold flex items-center">
                    <ShoppingBag className="h-6 w-6 mr-2" />
                    Seu Pedido ({cart.length})
                  </h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                    style={{color: 'var(--button-text-dynamic)', backgroundColor: 'var(--secondary-dynamic)33', borderColor: 'var(--secondary-dynamic)'}}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
                  {cart.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full" style={{color: 'var(--text-secondary-dynamic)'}}>
                      <ShoppingBag className="h-16 w-16 mb-4 opacity-50" />
                      <p className="text-lg font-medium">Carrinho vazio</p>
                      <p className="text-sm">Adicione itens para continuar</p>
                    </div>
                  ) : (
                    <>
                    <div className="p-3 rounded-lg" style={{backgroundColor: 'var(--primary-dynamic)1A'}}>
                      <p className="text-sm flex items-center" style={{color: 'var(--primary-dynamic)'}}>
                        <UserIcon className="h-4 w-4 mr-2"/>
                        Pedido para: <span className="font-semibold ml-1">{customerName || "Cliente não informado"}</span>
                      </p>
                    </div>
                    {cart.map((item) => (
                      <motion.div
                        key={item.cartId}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                      >
                        <Card style={{borderColor: 'var(--primary-dynamic)33', backgroundColor: 'var(--background-dynamic)'}}>
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-3">
                              <div className="flex-1">
                                <h3 className="font-medium" style={{color: 'var(--text-primary-dynamic)'}}>{item.name}</h3>
                                <p className="text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>R$ {item.price.toFixed(2)} cada</p>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeItem(item.cartId)}
                                className="text-red-500 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>

                            {item.selectedAdditionals.length > 0 && (
                              <div className="mb-3">
                                <p className="text-xs font-medium mb-1" style={{color: 'var(--primary-dynamic)'}}>Adicionais:</p>
                                {item.selectedAdditionals.map((additional) => (
                                  <p key={additional.id} className="text-xs" style={{color: 'var(--text-secondary-dynamic)'}}>
                                    • {additional.name} (+R$ {additional.price.toFixed(2)})
                                  </p>
                                ))}
                              </div>
                            )}

                            {item.observations && (
                              <div className="mb-3">
                                <p className="text-xs font-medium mb-1" style={{color: 'var(--primary-dynamic)'}}>Observações do item:</p>
                                <p className="text-xs" style={{color: 'var(--text-secondary-dynamic)'}}>{item.observations}</p>
                              </div>
                            )}

                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateQuantity(item.cartId, item.quantity - 1)}
                                  className="h-8 w-8 p-0 dynamic-button-outline"
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="font-medium w-8 text-center" style={{color: 'var(--text-secondary-dynamic)'}}>{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateQuantity(item.cartId, item.quantity + 1)}
                                  className="h-8 w-8 p-0 dynamic-button-outline"
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                              <div className="text-right">
                                <p className="font-bold" style={{color: 'var(--primary-dynamic)'}}>
                                  R$ {((item.price * item.quantity) + 
                                    item.selectedAdditionals.reduce((totalCalc, additional) => 
                                      totalCalc + (additional.price * item.quantity), 0
                                    )).toFixed(2)}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                    {orderObservations && (
                      <div className="p-3 border rounded-lg" style={{borderColor: 'var(--secondary-dynamic)55', backgroundColor: 'var(--secondary-dynamic)1A'}}>
                        <p className="text-sm font-medium mb-1" style={{color: 'var(--text-secondary-dynamic)'}}>Observações Gerais:</p>
                        <p className="text-xs" style={{color: 'var(--text-secondary-dynamic)CC'}}>{orderObservations}</p>
                      </div>
                    )}
                    </>
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="border-t p-4 space-y-4" style={{backgroundColor: 'var(--background-dynamic)', borderColor: 'var(--primary-dynamic)33'}}>
                    <div className="space-y-1">
                      <label className="text-sm font-medium" style={{color: 'var(--text-secondary-dynamic)'}}>Cupom de Desconto</label>
                      <div className="flex space-x-2">
                        <Input 
                          placeholder="Digite seu cupom" 
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                          className="flex-grow"
                          style={{borderColor: 'var(--primary-dynamic)55'}}
                          disabled={!!appliedCoupon}
                        />
                        {appliedCoupon ? (
                           <Button variant="destructive" onClick={handleRemoveCoupon} size="sm"><X className="h-4 w-4 mr-1"/>Remover</Button>
                        ) : (
                           <Button onClick={handleApplyCoupon} className="dynamic-button" size="sm"><Tag className="h-4 w-4 mr-1"/>Aplicar</Button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>
                        <span>Subtotal dos itens:</span>
                        <span>R$ {subtotal.toFixed(2)}</span>
                      </div>
                      {appliedCoupon && (
                        <>
                          <div className="flex justify-between text-sm text-green-600">
                            <span>Desconto ({appliedCoupon.id}):</span>
                            <span>- R$ {discount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-sm font-medium" style={{color: 'var(--text-secondary-dynamic)'}}>
                            <span>Subtotal com Desconto:</span>
                            <span>R$ {totalAfterDiscount.toFixed(2)}</span>
                          </div>
                        </>
                      )}
                      {deliveryType === 'delivery' && deliveryFee > 0 && (
                        <div className="flex justify-between text-sm" style={{color: 'var(--text-secondary-dynamic)'}}>
                          <span>Taxa de entrega:</span>
                          <span>R$ {deliveryFee.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-bold text-lg border-t pt-2" style={{borderColor: 'var(--primary-dynamic)33'}}>
                        <span style={{color: 'var(--primary-dynamic)'}}>Total:</span>
                        <span style={{color: 'var(--primary-dynamic)'}}>R$ {total.toFixed(2)}</span>
                      </div>
                    </div>

                    <Button
                      onClick={handleOpenPaymentModal}
                      className="w-full dynamic-button"
                      size="lg"
                    >
                      <MessageCircle className="h-5 w-5 mr-2" />
                      Escolher Pagamento e Finalizar
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <Dialog open={isPaymentModalOpen} onOpenChange={setIsPaymentModalOpen}>
        <DialogContent className="sm:max-w-md" style={{ backgroundColor: '#800000', color: 'white' }}>
          <DialogHeader>
            <DialogTitle className="text-2xl text-center text-white">Escolha a forma de pagamento</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-3">
              {paymentOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <Button
                    key={option.name}
                    variant={paymentMethod === option.name ? 'default' : 'outline'}
                    onClick={() => dispatch({type: 'SET_PAYMENT_METHOD', payload: option.name})}
                    className={`h-auto py-3 flex flex-col items-center justify-center space-y-1 text-sm
                      ${paymentMethod === option.name 
                        ? 'bg-white text-[#800000] hover:bg-gray-200' 
                        : 'bg-transparent border-white/50 text-white hover:bg-white/10'
                      }`}
                  >
                    <Icon className="h-6 w-6 mb-1" />
                    <span>{option.name}</span>
                  </Button>
                );
              })}
            </div>

            {paymentMethod === 'Dinheiro' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-2 pt-2"
              >
                <label htmlFor="changeFor" className="block text-sm font-medium text-white">
                  Troco para quanto? (Opcional)
                </label>
                <Input
                  id="changeFor"
                  type="number"
                  value={changeFor}
                  onChange={(e) => dispatch({type: 'SET_CHANGE_FOR', payload: e.target.value})}
                  placeholder="Ex: 50.00"
                  className="bg-white/10 border-white/50 text-white placeholder-white/70 focus:bg-white/20"
                />
              </motion.div>
            )}
          </div>
          <DialogFooter className="sm:justify-between gap-2">
            <DialogClose asChild>
              <Button type="button" variant="outline" className="bg-transparent border-white/50 text-white hover:bg-white/10 w-full sm:w-auto">
                Cancelar
              </Button>
            </DialogClose>
            <Button type="button" onClick={handleConfirmPayment} className="bg-green-600 hover:bg-green-700 text-white w-full sm:w-auto">
              Confirmar e Enviar Pedido
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}