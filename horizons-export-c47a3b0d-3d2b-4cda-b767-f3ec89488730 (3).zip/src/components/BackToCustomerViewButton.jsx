import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeftCircle } from 'lucide-react';

export function BackToCustomerViewButton({ className }) {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate('/');
  };

  return (
    <Button
      variant="outline"
      className={`w-full justify-start text-left h-12 text-base ${className}`}
      onClick={handleNavigate}
    >
      <ArrowLeftCircle className="h-5 w-5 mr-3" />
      Ver Loja (Cliente)
    </Button>
  );
}