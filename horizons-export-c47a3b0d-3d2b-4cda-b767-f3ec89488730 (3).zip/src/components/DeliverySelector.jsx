import React from 'react';
import { motion } from 'framer-motion';
import { Truck, Store, MapPin, Home, User as UserIcon, Phone as PhoneIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useApp } from '@/contexts/AppContext';

export function DeliverySelector() {
  const { state, dispatch } = useApp();
  const { customerName, customerPhone, deliveryType, deliveryAddress, deliveryFee, orderObservations } = state.cartState;
  const { neighborhoods } = state.productState;
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;


  const handleDeliveryTypeChange = (type) => {
    dispatch({ type: 'SET_DELIVERY_TYPE', payload: type });
  };

  const handleAddressChange = (field, value) => {
    const newAddress = { ...deliveryAddress, [field]: value };
    const neighborhood = neighborhoods.find(n => n.name === newAddress.neighborhood);
    dispatch({ type: 'SET_DELIVERY_ADDRESS', payload: { address: newAddress, fee: neighborhood ? neighborhood.fee : 0 } });
  };

  const handleCustomerNameChange = (e) => {
    dispatch({ type: 'SET_CUSTOMER_NAME', payload: e.target.value });
  };
  
  const handleCustomerPhoneChange = (e) => {
    dispatch({ type: 'SET_CUSTOMER_PHONE', payload: e.target.value });
  };

  const handleObservationsChange = (e) => {
    dispatch({ type: 'SET_ORDER_OBSERVATIONS', payload: e.target.value });
  };

  return (
    <motion.div
      className="mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card className="glass-effect" style={{ borderColor: visualSettings.colors.primary+'33' }}>
        <CardHeader>
          <CardTitle className="flex items-center" style={{color: visualSettings.colors.primary}}>
            <MapPin className="h-6 w-6 mr-2" />
            Como você quer receber seu pedido?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                Seu Nome *
              </label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4" style={{color: visualSettings.colors.primary+'99'}} />
                <Input
                  placeholder="Digite seu nome"
                  value={customerName}
                  onChange={handleCustomerNameChange}
                  className="pl-10"
                  style={{borderColor: visualSettings.colors.primary+'55'}}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                Seu WhatsApp (para contato)
              </label>
              <div className="relative">
                <PhoneIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4" style={{color: visualSettings.colors.primary+'99'}} />
                <Input
                  type="tel"
                  placeholder="Ex: 11999998888"
                  value={customerPhone}
                  onChange={handleCustomerPhoneChange}
                  className="pl-10"
                  style={{borderColor: visualSettings.colors.primary+'55'}}
                />
              </div>
            </div>
          </div>


          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              variant={deliveryType === 'delivery' ? 'default' : 'outline'}
              className={`h-20 flex flex-col items-center justify-center space-y-2 dynamic-button ${
                deliveryType !== 'delivery' && 'dynamic-button-outline hover-dynamic-primary-bg-light'
              }`}
              onClick={() => handleDeliveryTypeChange('delivery')}
            >
              <Truck className="h-6 w-6" />
              <span>Entrega</span>
            </Button>

            <Button
              variant={deliveryType === 'pickup' ? 'default' : 'outline'}
              className={`h-20 flex flex-col items-center justify-center space-y-2 dynamic-button ${
                deliveryType !== 'pickup' && 'dynamic-button-outline hover-dynamic-primary-bg-light'
              }`}
              onClick={() => handleDeliveryTypeChange('pickup')}
            >
              <Store className="h-6 w-6" />
              <span>Retirada</span>
            </Button>
          </div>

          {deliveryType === 'delivery' && (
            <motion.div
              className="space-y-4 p-4 rounded-lg"
              style={{backgroundColor: visualSettings.colors.primary+'1A'}}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center mb-3" style={{color: visualSettings.colors.primary}}>
                <Home className="h-5 w-5 mr-2" />
                <span className="font-medium">Endereço de entrega</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                    Bairro *
                  </label>
                  <Select
                    value={deliveryAddress.neighborhood}
                    onValueChange={(value) => handleAddressChange('neighborhood', value)}
                  >
                    <SelectTrigger className="bg-white" style={{borderColor: visualSettings.colors.primary+'55'}}>
                      <SelectValue placeholder="Selecione o bairro" />
                    </SelectTrigger>
                    <SelectContent>
                      {neighborhoods.map((neighborhood) => (
                        <SelectItem key={neighborhood.name} value={neighborhood.name}>
                          {neighborhood.name} - R$ {neighborhood.fee.toFixed(2)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                    Rua *
                  </label>
                  <Input
                    placeholder="Nome da rua"
                    value={deliveryAddress.street}
                    onChange={(e) => handleAddressChange('street', e.target.value)}
                    className="bg-white"
                    style={{borderColor: visualSettings.colors.primary+'55'}}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                    Número *
                  </label>
                  <Input
                    placeholder="Número"
                    value={deliveryAddress.number}
                    onChange={(e) => handleAddressChange('number', e.target.value)}
                    className="bg-white"
                    style={{borderColor: visualSettings.colors.primary+'55'}}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                    Complemento
                  </label>
                  <Input
                    placeholder="Apto, bloco, etc."
                    value={deliveryAddress.complement}
                    onChange={(e) => handleAddressChange('complement', e.target.value)}
                    className="bg-white"
                    style={{borderColor: visualSettings.colors.primary+'55'}}
                  />
                </div>
                 <div>
                  <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
                    CEP
                  </label>
                  <Input
                    placeholder="00000-000"
                    value={deliveryAddress.zipCode}
                    onChange={(e) => handleAddressChange('zipCode', e.target.value)}
                    className="bg-white"
                    style={{borderColor: visualSettings.colors.primary+'55'}}
                  />
                </div>
              </div>

              {deliveryFee > 0 && (
                <div className="p-3 rounded-lg" style={{backgroundColor: visualSettings.colors.primary+'33'}}>
                  <p className="font-medium" style={{color: visualSettings.colors.primary}}>
                    Taxa de entrega: R$ {deliveryFee.toFixed(2)}
                  </p>
                </div>
              )}
            </motion.div>
          )}
          
          <div>
            <label className="block text-sm font-medium mb-1" style={{color: visualSettings.colors.secondary}}>
              Observações do Pedido
            </label>
            <Textarea
              placeholder="Alguma preferência ou restrição? Ex: sem cebola, ponto da carne..."
              value={orderObservations}
              onChange={handleObservationsChange}
              className="bg-white"
              style={{borderColor: visualSettings.colors.primary+'55'}}
            />
          </div>

        </CardContent>
      </Card>
    </motion.div>
  );
}