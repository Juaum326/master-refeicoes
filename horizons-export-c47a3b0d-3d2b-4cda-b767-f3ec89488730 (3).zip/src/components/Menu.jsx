import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Utensils, Coffee, Cookie, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { useApp } from '@/contexts/AppContext';

export function Menu() {
  const { state } = useApp();
  const { products, beverages, sides, categories: appCategories } = state.productState;
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;

  const isStoreOpen = () => {
    if (settings.manualOpen !== null) return settings.manualOpen;

    const now = new Date();
    const dayOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][now.getDay()];
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const todayHours = settings.openingHours[dayOfWeek];

    if (!todayHours || !todayHours.enabled) return false;
    return currentTime >= todayHours.open && currentTime <= todayHours.close;
  };
  
  const storeOpen = isStoreOpen();
  
  const sortedCategories = [...appCategories].sort((a, b) => a.order - b.order);
  const [activeCategory, setActiveCategory] = useState(sortedCategories[0]?.id || 'quentinhas');


  const getCategoryIcon = (categoryId) => {
    switch (categoryId) {
      case 'quentinhas': return Utensils;
      case 'bebidas': return Coffee;
      case 'acompanhamentos': return Cookie;
      default: return Utensils;
    }
  };

  const getItemsForCategory = (categoryId) => {
    let items = [];
    switch (categoryId) {
      case 'quentinhas': items = products; break;
      case 'bebidas': items = beverages; break;
      case 'acompanhamentos': items = sides; break;
      default: items = [];
    }
    return items.sort((a,b) => a.order - b.order);
  };
  
  const activeItems = getItemsForCategory(activeCategory);

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-3xl font-bold text-center dynamic-text-gradient" style={{ fontFamily: 'var(--font-titles)', color: 'var(--primary-dynamic)'}}>
        Nosso Cardápio
      </h2>

      {!storeOpen && (
        <motion.div 
          className="p-4 rounded-lg text-center"
          style={{backgroundColor: visualSettings.colors.secondary+'22', color: visualSettings.colors.secondary}}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <XCircle className="h-8 w-8 mx-auto mb-2" />
          <p className="font-semibold">Loja Fechada no Momento</p>
          <p className="text-sm">Nosso delivery está temporariamente indisponível. Voltamos em breve!</p>
        </motion.div>
      )}

      <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8">
        {sortedCategories.map((category) => {
          const Icon = getCategoryIcon(category.id);
          return (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? 'default' : 'outline'}
              onClick={() => setActiveCategory(category.id)}
              className={`rounded-full px-4 py-2 text-sm md:text-base transition-all duration-300 ease-in-out transform hover:scale-105
                ${activeCategory === category.id 
                  ? 'dynamic-button shadow-lg' 
                  : 'dynamic-button-outline hover:shadow-md'
                }`}
            >
              <Icon className="h-4 w-4 mr-2" />
              {category.name}
            </Button>
          );
        })}
      </div>

      <motion.div 
        key={activeCategory}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {activeItems.map((item) => (
          <ProductCard key={item.id} product={item} categoryType={activeCategory} storeOpen={storeOpen} />
        ))}
      </motion.div>
      {activeItems.length === 0 && storeOpen && (
        <p className="text-center text-gray-500">Nenhum item disponível nesta categoria no momento.</p>
      )}
    </motion.div>
  );
}