import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CalendarHeart, Plus, Edit, Trash2, ToggleLeft, ToggleRight, Palette, Image as ImageIcon, MessageSquare, AlertTriangle, Sparkles, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { differenceInDays, parseISO } from 'date-fns';

const predefinedEventsList = [
  { id: 'inauguracao', name: 'Inauguração da Loja', description: 'Grande inauguração! Venha celebrar conosco.', theme: { bannerText: '🎉 Inauguração Especial! 🎉', primaryColor: '#ffD700', secondaryColor: '#ffA500' }, icon: '🎉', autoSuggest: true },
  { id: 'natal', name: 'Natal', description: 'Feliz Natal! Temos ofertas especiais para você.', theme: { bannerText: '🎅 Feliz Natal! 🎁', primaryColor: '#c82333', secondaryColor: '#1e7e34', siteBackground: 'https://www.transparenttextures.com/patterns/snow.png' }, icon: '🎅', autoSuggest: true },
  { id: 'carnaval', name: 'Carnaval', description: 'Carnaval de ofertas! Aproveite a folia.', theme: { bannerText: '🎭 Carnaval de Ofertas! ✨', primaryColor: '#f9c22e', secondaryColor: '#3949ab' }, icon: '🎭', autoSuggest: true },
  { id: 'namorados', name: 'Dia dos Namorados', description: 'Celebre o amor com nossas delícias.', theme: { bannerText: '💘 Dia dos Namorados 💘', primaryColor: '#e91e63', secondaryColor: '#f48fb1' }, icon: '💘', autoSuggest: true },
  { id: 'blackfriday', name: 'Black Friday', description: 'Descontos imperdíveis! Só na Black Friday.', theme: { bannerText: '🛍️ BLACK FRIDAY IMPERDÍVEL 🛍️', primaryColor: '#212529', secondaryColor: '#ffc107', textPrimary: '#ffffff', textSecondary: '#f8f9fa', buttonBackground: '#ffc107', buttonText: '#212529' }, icon: '🛍️', autoSuggest: true },
  { id: 'halloween', name: 'Halloween', description: 'Doces ou travessuras? Temos ofertas de arrepiar!', theme: { bannerText: '🎃 Halloween Assustadoramente Gostoso! 👻', primaryColor: '#fd7e14', secondaryColor: '#6f42c1' }, icon: '🎃', autoSuggest: true },
  { id: 'anonovo', name: 'Ano Novo', description: 'Feliz Ano Novo! Comece o ano com sabor.', theme: { bannerText: '🎆 Feliz Ano Novo! 🥂', primaryColor: '#007bff', secondaryColor: '#adb5bd' }, icon: '🎆', autoSuggest: true },
  { id: 'diadasmaes', name: 'Dia das Mães', description: 'Para a melhor mãe do mundo, o melhor sabor.', theme: { bannerText: '💐 Feliz Dia das Mães! 💖', primaryColor: '#dc3545', secondaryColor: '#f8f9fa', textPrimary: '#212529', textSecondary: '#6c757d', buttonBackground: '#dc3545', buttonText: '#ffffff' }, icon: '💐', autoSuggest: true },
];


export function EventsManagement() {
  const { state, dispatch } = useApp();
  const { events, inaugurationDate } = state.eventsState;
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewTheme, setPreviewTheme] = useState(null);
  const [daysSinceInauguration, setDaysSinceInauguration] = useState(0);

  const initialFormData = {
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    active: false,
    priority: 0,
    icon: '🎉',
    theme: {
      bannerText: '',
      primaryColor: visualSettings.colors.primary,
      secondaryColor: visualSettings.colors.secondary,
      siteBackground: '',
      logoOverride: '',
      customCSS: '',
    }
  };
  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (inaugurationDate) {
      const diff = differenceInDays(new Date(), parseISO(inaugurationDate));
      setDaysSinceInauguration(Math.max(0, diff));
    } else {
      setDaysSinceInauguration(0);
    }
  }, [inaugurationDate]);

  const resetForm = () => {
    setFormData(initialFormData);
    setEditingEvent(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleThemeChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, theme: { ...prev.theme, [name]: value } }));
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({ ...prev, theme: { ...prev.theme, logoOverride: e.target.result }}));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.startDate || !formData.endDate) {
      toast({ title: "Campos Obrigatórios", description: "Nome, Data de Início e Data de Fim são obrigatórios.", variant: "destructive"});
      return;
    }
    const eventData = { ...formData, priority: parseInt(formData.priority, 10) || 0 };

    if (editingEvent) {
      dispatch({ type: 'UPDATE_EVENT', payload: { ...eventData, id: editingEvent.id } });
      toast({ title: "Evento atualizado!"});
    } else {
      dispatch({ type: 'ADD_EVENT', payload: { ...eventData, id: formData.id || Date.now().toString() } });
      toast({ title: "Evento adicionado!"});
    }
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (event) => {
    setEditingEvent(event);
    setFormData({
      id: event.id,
      name: event.name,
      description: event.description,
      startDate: event.startDate,
      endDate: event.endDate,
      active: event.active,
      priority: event.priority || 0,
      icon: event.icon || '🎉',
      theme: {
        bannerText: event.theme?.bannerText || '',
        primaryColor: event.theme?.primaryColor || visualSettings.colors.primary,
        secondaryColor: event.theme?.secondaryColor || visualSettings.colors.secondary,
        siteBackground: event.theme?.siteBackground || '',
        logoOverride: event.theme?.logoOverride || '',
        customCSS: event.theme?.customCSS || '',
      }
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (eventId) => {
    dispatch({ type: 'DELETE_EVENT', payload: eventId });
    toast({ title: "Evento removido!"});
  };

  const handleToggleActive = (event) => {
    dispatch({ type: 'UPDATE_EVENT', payload: { ...event, active: !event.active } });
  };

  const addPredefinedEvent = (predefEvent) => {
    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(new Date().setDate(new Date().getDate() + 7)).toISOString().split('T')[0];
    
    const newEventData = {
      id: predefEvent.id, 
      name: predefEvent.name,
      description: predefEvent.description,
      startDate: today,
      endDate: nextWeek,
      active: false,
      priority: 0,
      icon: predefEvent.icon || '🎉',
      theme: {
        bannerText: predefEvent.theme?.bannerText || '',
        primaryColor: predefEvent.theme?.primaryColor || visualSettings.colors.primary,
        secondaryColor: predefEvent.theme?.secondaryColor || visualSettings.colors.secondary,
        siteBackground: predefEvent.theme?.siteBackground || '',
        logoOverride: '',
        customCSS: '',
      }
    };
    dispatch({ type: 'ADD_EVENT', payload: newEventData });
    toast({ title: `Evento "${predefEvent.name}" adicionado! Configure as datas.`});
  };

  const handlePreviewTheme = (eventTheme) => {
    setPreviewTheme(eventTheme);
    setIsPreviewOpen(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center"><CalendarHeart className="mr-2 h-7 w-7 text-purple-600" /> Gerenciar Eventos e Temas</h2>
          <p className="text-gray-600">Configure temas comemorativos para datas especiais.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if(!open) resetForm();}}>
          <DialogTrigger asChild>
            <Button onClick={() => { resetForm(); setEditingEvent(null); }} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" /> Novo Evento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editingEvent ? 'Editar' : 'Novo'} Evento</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><Label htmlFor="eventName">Nome do Evento *</Label><Input id="eventName" name="name" value={formData.name} onChange={handleInputChange} required /></div>
                <div><Label htmlFor="eventPriority">Prioridade (0 = normal, maior = mais prioritário)</Label><Input id="eventPriority" name="priority" type="number" value={formData.priority} onChange={handleInputChange} /></div>
              </div>
              <div><Label htmlFor="eventIcon">Ícone do Evento (Emoji)</Label><Input id="eventIcon" name="icon" value={formData.icon} onChange={handleInputChange} placeholder="🎉"/></div>
              <div><Label htmlFor="eventDescription">Descrição</Label><Textarea id="eventDescription" name="description" value={formData.description} onChange={handleInputChange} rows={2}/></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><Label htmlFor="eventStartDate">Data de Início *</Label><Input id="eventStartDate" name="startDate" type="date" value={formData.startDate} onChange={handleInputChange} required /></div>
                <div><Label htmlFor="eventEndDate">Data de Fim *</Label><Input id="eventEndDate" name="endDate" type="date" value={formData.endDate} onChange={handleInputChange} required /></div>
              </div>
              <div className="flex items-center space-x-2"><Switch id="eventActive" checked={formData.active} onCheckedChange={(checked) => setFormData(prev => ({...prev, active: checked}))} /><Label htmlFor="eventActive">Ativar Evento</Label></div>
              
              <Card className="mt-4">
                <CardHeader className="pb-2"><CardTitle className="text-base flex items-center"><Palette className="mr-2 h-4 w-4"/>Configurações do Tema do Evento</CardTitle></CardHeader>
                <CardContent className="space-y-3 pt-2">
                   <div><Label htmlFor="themeBannerText">Texto do Banner</Label><Input id="themeBannerText" name="bannerText" value={formData.theme.bannerText} onChange={handleThemeChange} /></div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><Label htmlFor="themePrimaryColor">Cor Primária</Label><Input id="themePrimaryColor" name="primaryColor" type="color" value={formData.theme.primaryColor} onChange={handleThemeChange} /></div>
                    <div><Label htmlFor="themeSecondaryColor">Cor Secundária</Label><Input id="themeSecondaryColor" name="secondaryColor" type="color" value={formData.theme.secondaryColor} onChange={handleThemeChange} /></div>
                   </div>
                   <div>
                     <Label htmlFor="themeSiteBackground">URL Imagem de Fundo do Site (Opcional)</Label>
                     <Input id="themeSiteBackground" name="siteBackground" value={formData.theme.siteBackground} onChange={handleThemeChange} placeholder="https://exemplo.com/fundo.png"/>
                   </div>
                   <div>
                    <Label htmlFor="themeLogoOverride">Logo Específico do Evento (Opcional)</Label>
                    <Input id="themeLogoOverride" name="logoOverride" type="file" accept="image/*" onChange={handleLogoUpload} className="file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"/>
                    {formData.theme.logoOverride && <img src={formData.theme.logoOverride} alt="preview logo" className="h-10 mt-1"/>}
                   </div>
                   <div><Label htmlFor="themeCustomCSS">CSS Personalizado (Avançado)</Label><Textarea id="themeCustomCSS" name="customCSS" value={formData.theme.customCSS} onChange={handleThemeChange} rows={3} placeholder=".classe-especial { font-weight: bold; }"/></div>
                </CardContent>
              </Card>
            </form>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline">Cancelar</Button></DialogClose>
              <Button type="submit" onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700">Salvar Evento</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {inaugurationDate && (
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="pt-4 text-center">
            <p className="text-purple-700 font-semibold">🎉 Loja inaugurada há {daysSinceInauguration} dias! 🎉</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base flex items-center"><Sparkles className="mr-2 h-5 w-5 text-yellow-500" /> Adicionar Eventos Pré-definidos</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-3">
          {predefinedEventsList.filter(pe => !events.some(e => e.id === pe.id)).map(pde => (
            <Button key={pde.id} variant="outline" size="sm" onClick={() => addPredefinedEvent(pde)} className="flex items-center justify-start text-left h-auto py-1.5 px-2">
              <span className="text-lg mr-2">{pde.icon}</span>
              <span className="text-xs">{pde.name}</span>
            </Button>
          ))}
          {predefinedEventsList.filter(pe => !events.some(e => e.id === pe.id)).length === 0 && <p className="text-sm text-gray-500 col-span-full">Todos os eventos pré-definidos já foram adicionados.</p>}
        </CardContent>
      </Card>


      <div className="overflow-x-auto">
        <table className="min-w-full bg-white shadow-md rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Período</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tema Aplicado</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {events.length === 0 && (
              <tr><td colSpan="5" className="px-4 py-4 text-center text-sm text-gray-500">Nenhum evento cadastrado.</td></tr>
            )}
            {events.sort((a,b) => (b.priority || 0) - (a.priority || 0) || new Date(a.startDate) - new Date(b.startDate)).map(event => (
              <tr key={event.id} className={`${!event.active ? 'opacity-70 bg-gray-50' : ''}`}>
                <td className="px-4 py-2 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 flex items-center">{event.icon && <span className="mr-2 text-lg">{event.icon}</span>}{event.name}</div>
                  <div className="text-xs text-gray-500">{event.description.substring(0,30)}{event.description.length > 30 ? '...' : ''}</div>
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                  {new Date(event.startDate + 'T00:00:00').toLocaleDateString()} - {new Date(event.endDate + 'T00:00:00').toLocaleDateString()}
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-sm">
                    {event.theme?.bannerText && <div className="text-xs bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded-full inline-block mb-0.5">Banner</div>}
                    {event.theme?.primaryColor !== visualSettings.colors.primary && <div style={{backgroundColor: event.theme?.primaryColor}} className="w-3 h-3 rounded-full inline-block ml-1 border border-gray-300"></div>}
                    {event.theme?.logoOverride && <ImageIcon className="inline h-3 w-3 ml-1 text-blue-500" />}
                    <Button variant="ghost" size="icon" className="h-6 w-6 ml-1" onClick={() => handlePreviewTheme(event.theme)}><Eye className="h-3 w-3 text-gray-500"/></Button>
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-center">
                  <Button variant="ghost" size="sm" onClick={() => handleToggleActive(event)}>
                    {event.active ? <ToggleRight className="h-6 w-6 text-green-500"/> : <ToggleLeft className="h-6 w-6 text-red-500"/>}
                  </Button>
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-center text-sm font-medium">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(event)}><Edit className="h-4 w-4 text-blue-500"/></Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(event.id)}><Trash2 className="h-4 w-4 text-red-500"/></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       {events.length > 0 && (
        <p className="text-xs text-gray-500 mt-2">
            <AlertTriangle className="inline h-3 w-3 mr-1 text-orange-400"/>A prioridade de evento mais alta será aplicada caso haja sobreposição de datas.
        </p>
       )}

      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Pré-visualização do Tema</DialogTitle></DialogHeader>
          {previewTheme && (
            <div className="p-4 rounded-lg" style={{
              backgroundColor: previewTheme.primaryColor || visualSettings.colors.primary,
              color: previewTheme.primaryColor && (getLuminance(previewTheme.primaryColor) > 0.5 ? '#000' : '#FFF')
            }}>
              <h3 className="text-xl font-bold mb-2" style={{color: previewTheme.secondaryColor || visualSettings.colors.secondary}}>
                {previewTheme.bannerText || "Título do Banner"}
              </h3>
              {previewTheme.logoOverride && <img src={previewTheme.logoOverride} alt="logo preview" className="h-12 mb-2"/>}
              <p className="text-sm">Este é um exemplo de como o tema pode aparecer.</p>
              <Button className="mt-2" style={{backgroundColor: previewTheme.secondaryColor || visualSettings.colors.secondary, color: previewTheme.secondaryColor && (getLuminance(previewTheme.secondaryColor) > 0.5 ? '#000' : '#FFF')}}>Botão Exemplo</Button>
              {previewTheme.siteBackground && <p className="text-xs mt-2">Imagem de fundo: <a href={previewTheme.siteBackground} target="_blank" rel="noopener noreferrer" className="underline">Ver Imagem</a></p>}
            </div>
          )}
        </DialogContent>
      </Dialog>

    </motion.div>
  );
}

function getLuminance(hexColor) {
  if (!hexColor || hexColor.length < 7) return 0.5; 
  const rgb = parseInt(hexColor.slice(1), 16);
  const r = (rgb >> 16) & 0xff;
  const g = (rgb >>  8) & 0xff;
  const b = (rgb >>  0) & 0xff;
  const a = [r, g, b].map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
}