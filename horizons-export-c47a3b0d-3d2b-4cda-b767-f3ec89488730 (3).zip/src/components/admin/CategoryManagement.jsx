import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, ListOrdered, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function CategoryManagement() {
  const { state, dispatch } = useApp();
  const { categories, products, beverages, sides } = state.productState;
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formData, setFormData] = useState({ id: '', name: '', order: 0 });

  const resetForm = () => {
    setFormData({ id: '', name: '', order: 0 });
    setEditingCategory(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({ title: "Nome da categoria é obrigatório", variant: "destructive" });
      return;
    }

    const categoryData = {
      id: formData.id.trim() || formData.name.toLowerCase().replace(/\s+/g, '-'),
      name: formData.name.trim(),
      order: parseInt(formData.order, 10) || 0,
    };

    let updatedCategories;
    if (editingCategory) {
      updatedCategories = categories.map(cat => cat.id === editingCategory.id ? categoryData : cat);
      toast({ title: "Categoria atualizada!" });
    } else {
      if (categories.some(cat => cat.id === categoryData.id)) {
        toast({ title: "ID da categoria já existe", variant: "destructive" });
        return;
      }
      updatedCategories = [...categories, categoryData];
      toast({ title: "Categoria adicionada!" });
    }
    dispatch({ type: 'UPDATE_CATEGORIES', payload: updatedCategories });
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (category) => {
    setEditingCategory(category);
    setFormData({ id: category.id, name: category.name, order: category.order });
    setIsDialogOpen(true);
  };

  const handleDelete = (categoryId) => {
    const allProducts = [...products, ...beverages, ...sides];
    const isInUse = allProducts.some(product => product.category === categoryId);

    if (isInUse) {
        toast({ title: "Erro ao excluir", description: "Categoria está em uso por produtos.", variant: "destructive"});
        return;
    }
    const updatedCategories = categories.filter(cat => cat.id !== categoryId);
    dispatch({ type: 'UPDATE_CATEGORIES', payload: updatedCategories });
    toast({ title: "Categoria removida!" });
  };

  const handleReorder = (categoryId, direction) => {
    const list = [...categories].sort((a,b) => a.order - b.order);
    const catIndex = list.findIndex(c => c.id === categoryId);
    if (catIndex === -1) return;

    const newIndex = direction === 'up' ? catIndex - 1 : catIndex + 1;
    if (newIndex < 0 || newIndex >= list.length) return;
    
    [list[catIndex].order, list[newIndex].order] = [list[newIndex].order, list[catIndex].order];
    
    dispatch({ type: 'UPDATE_CATEGORIES', payload: list });
    toast({ title: "Ordem das categorias atualizada!" });
  };
  
  const sortedCategories = [...categories].sort((a,b) => a.order - b.order);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Categorias</h2>
          <p className="text-gray-600">Adicione, edite ou remova categorias de produtos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCategory(null)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" /> Nova Categoria
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editingCategory ? 'Editar' : 'Nova'} Categoria</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nome da Categoria *</label>
                <Input value={formData.name} onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">ID da Categoria (opcional, auto-gerado se vazio)</label>
                <Input value={formData.id} onChange={(e) => setFormData(prev => ({ ...prev, id: e.target.value }))} disabled={!!editingCategory} placeholder="Ex: quentinhas, bebidas"/>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Ordem de Exibição</label>
                <Input type="number" value={formData.order} onChange={(e) => setFormData(prev => ({ ...prev, order: e.target.value }))} />
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">Salvar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {sortedCategories.map((category, index) => (
          <Card key={category.id}>
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <ListOrdered className="h-5 w-5 text-purple-600" />
                <div>
                  <h3 className="font-semibold">{category.name} <span className="text-xs text-gray-500">(ID: {category.id})</span></h3>
                  <p className="text-xs text-gray-500">Ordem: {category.order}</p>
                </div>
              </div>
              <div className="flex items-center space-x-1">
                <Button variant="ghost" size="sm" onClick={() => handleReorder(category.id, 'up')} disabled={index === 0}><ChevronUp className="h-4 w-4"/></Button>
                <Button variant="ghost" size="sm" onClick={() => handleReorder(category.id, 'down')} disabled={index === sortedCategories.length - 1}><ChevronDown className="h-4 w-4"/></Button>
                <Button variant="outline" size="sm" onClick={() => handleEdit(category)}><Edit className="h-4 w-4 mr-1" /> Editar</Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(category.id)}><Trash2 className="h-4 w-4 mr-1" /> Excluir</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {sortedCategories.length === 0 && (
        <Card className="p-12 text-center text-gray-500">
            <ListOrdered className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Nenhuma categoria cadastrada</h3>
        </Card>
      )}
    </motion.div>
  );
}