import React, { useState } from 'react';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { toast } from '@/components/ui/use-toast';
import { Trash2, Info } from 'lucide-react';

export function OrderHistory() {
  const { state, dispatch } = useApp();
  const { orders } = state.salesState;
  const [orderToDelete, setOrderToDelete] = useState(null);
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false);

  const finalizedOrders = orders.filter(order => order.status === 'delivered' || order.status === 'cancelled').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const handleDeleteClick = (order) => {
    setOrderToDelete(order);
    setIsConfirmDeleteDialogOpen(true);
  };

  const confirmDeleteOrder = () => {
    if (orderToDelete) {
      dispatch({ type: 'DELETE_ORDER', payload: orderToDelete.id });
      toast({
        title: "Pedido Excluído",
        description: `O pedido #${orderToDelete.id} foi excluído com sucesso.`,
      });
      setIsConfirmDeleteDialogOpen(false);
      setOrderToDelete(null);
    }
  };
  
  const getStatusColorText = (status) => {
    switch (status) {
      case 'delivered': return 'text-green-600';
      case 'cancelled': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusText = (status) => {
    const map = { delivered: 'Entregue', cancelled: 'Cancelado' };
    return map[status] || status;
  };


  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Histórico de Pedidos</h2>
      {finalizedOrders.length === 0 ? (
        <Card className="p-12 text-center text-gray-500">
          <Info className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <h3 className="text-lg font-medium mb-2">Nenhum pedido finalizado ainda</h3>
          <p className="text-sm">Pedidos entregues ou cancelados aparecerão aqui.</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {finalizedOrders.map(order => (
            <Card key={order.id} className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg text-slate-700">Pedido #{order.id}</CardTitle>
                    <CardDescription className="text-xs text-gray-500">
                      {new Date(order.createdAt).toLocaleString()} - <span className={`font-semibold ${getStatusColorText(order.status)}`}>{getStatusText(order.status)}</span>
                    </CardDescription>
                  </div>
                  <Button variant="destructive" size="sm" onClick={() => handleDeleteClick(order)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Excluir
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="text-sm space-y-1">
                <p><strong>Cliente:</strong> {order.customerName} {order.customerPhone && `(${order.customerPhone})`}</p>
                <p><strong>Total:</strong> R$ {order.total.toFixed(2)}</p>
                <p><strong>Itens:</strong> {order.items.map(item => `${item.quantity}x ${item.name}`).join(', ')}</p>
                {order.status === 'cancelled' && order.cancellationReason && (
                  <p className="text-xs text-red-500"><strong>Motivo Cancel.:</strong> {order.cancellationReason}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir o pedido #{orderToDelete?.id}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" onClick={() => setOrderToDelete(null)}>Cancelar</Button>
            </DialogClose>
            <Button variant="destructive" onClick={confirmDeleteOrder}>Excluir Pedido</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}