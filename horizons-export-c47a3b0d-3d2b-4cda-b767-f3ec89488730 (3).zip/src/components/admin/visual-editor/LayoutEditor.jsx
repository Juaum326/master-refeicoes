import React from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch.jsx';
import { Label } from '@/components/ui/label.jsx';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { LayoutDashboard, GripVertical, Eye, EyeOff } from 'lucide-react';

export function LayoutEditor() {
  const { state, dispatch } = useApp();
  const { layout } = state.visualState.visualSettings;

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(layout);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { layout: items } });
  };

  const toggleVisibility = (sectionId) => {
    const updatedLayout = layout.map(section =>
      section.id === sectionId ? { ...section, visible: !section.visible } : section
    );
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { layout: updatedLayout } });
  };

  const handleSubmit = () => {
    toast({ title: "Layout salvo!", description: "A ordem e visibilidade das seções foram atualizadas." });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><LayoutDashboard className="mr-2 h-5 w-5" />Editor de Layout das Seções</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-4">
            Arraste e solte as seções para reordená-las na página principal. Use o interruptor para mostrar ou ocultar uma seção.
          </p>
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="sections">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-3">
                  {layout.map((section, index) => (
                    <Draggable key={section.id} draggableId={section.id} index={index}>
                      {(providedDraggable, snapshot) => (
                        <div
                          ref={providedDraggable.innerRef}
                          {...providedDraggable.draggableProps}
                          className={`p-4 border rounded-lg flex items-center justify-between bg-white shadow-sm ${snapshot.isDragging ? 'ring-2 ring-purple-500 shadow-lg' : ''}`}
                        >
                          <div className="flex items-center">
                            <button {...providedDraggable.dragHandleProps} className="mr-3 p-1 text-gray-500 hover:text-gray-700">
                              <GripVertical className="h-5 w-5" />
                            </button>
                            <span className="font-medium">{section.name}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Label htmlFor={`visibility-${section.id}`} className="text-sm">
                              {section.visible ? <Eye className="h-4 w-4 text-green-500" /> : <EyeOff className="h-4 w-4 text-red-500" />}
                            </Label>
                            <Switch
                              id={`visibility-${section.id}`}
                              checked={section.visible}
                              onCheckedChange={() => toggleVisibility(section.id)}
                            />
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}>Salvar Layout</Button>
      </div>
    </div>
  );
}