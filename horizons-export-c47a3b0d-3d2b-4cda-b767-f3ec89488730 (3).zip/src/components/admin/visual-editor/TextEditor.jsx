import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { MessageSquare, Save } from 'lucide-react';

export function TextEditor() {
  const { state, dispatch } = useApp();
  const [texts, setTexts] = useState(state.visualState.visualSettings.texts);

  useEffect(() => {
    setTexts(state.visualState.visualSettings.texts);
  }, [state.visualState.visualSettings.texts]);

  const handleTextChange = (fieldName, value) => {
    setTexts(prev => ({ ...prev, [fieldName]: value }));
  };

  const handleSubmit = () => {
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { texts } });
    toast({ title: "Textos atualizados!", description: "Todos os textos do site foram salvos." });
  };

  const textFields = [
    { label: 'Título do Banner Principal', name: 'bannerTitle', placeholder: 'Ex: Sabor que Conquista!', type: 'input' },
    { label: 'Subtítulo do Banner', name: 'bannerSubtitle', placeholder: 'Ex: As melhores quentinhas da cidade...', type: 'textarea' },
    { label: 'Texto do Botão "Pedir Agora" (se aplicável)', name: 'buttonOrderNow', placeholder: 'Ex: Peça já!', type: 'input' },
    { label: 'Texto do Botão "Ver Cardápio" (se aplicável)', name: 'buttonViewMenu', placeholder: 'Ex: Nosso Cardápio', type: 'input' },
    { label: 'Informações do Rodapé (após o © Ano NomeEmpresa)', name: 'footerInfo', placeholder: 'Ex: Todos os direitos reservados.', type: 'input' },
    { label: 'Slogan/Tagline do Rodapé', name: 'footerTagline', placeholder: 'Ex: Feito com ❤️ para você!', type: 'input' },
    { label: 'Mensagem de Boas-Vindas (Opcional)', name: 'welcomeMessage', placeholder: 'Ex: Bem-vindo à Master Refeições!', type: 'textarea' },
    { label: 'Mensagem Promocional (Opcional)', name: 'promoMessage', placeholder: 'Ex: Peça 2, leve 3 nas quartas!', type: 'textarea' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><MessageSquare className="mr-2 h-5 w-5" />Editor de Textos e Labels</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {textFields.map(field => (
            <div key={field.name} className="space-y-1">
              <label className="text-sm font-medium">{field.label}</label>
              {field.type === 'input' ? (
                <Input
                  value={texts[field.name] || ''}
                  onChange={(e) => handleTextChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                />
              ) : (
                <Textarea
                  value={texts[field.name] || ''}
                  onChange={(e) => handleTextChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  rows={3}
                />
              )}
            </div>
          ))}
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}><Save className="mr-2 h-4 w-4" />Salvar Textos</Button>
      </div>
    </div>
  );
}