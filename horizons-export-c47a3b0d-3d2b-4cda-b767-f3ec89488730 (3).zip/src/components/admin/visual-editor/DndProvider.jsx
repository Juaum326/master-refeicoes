import React from 'react';
import { DragDropContext } from 'react-beautiful-dnd';

export function DndProvider({ children }) {
  const onDragEnd = (result) => {
    if (process.env.NODE_ENV === 'development') {
      console.log("Drag ended (DndProvider):", result);
    }
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      {children}
    </DragDropContext>
  );
}