import React from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Palette, Type, LayoutDashboard, Image as ImageIcon, Sparkles, MessageSquare, SlidersHorizontal } from 'lucide-react';
import { ColorCustomizer } from './ColorCustomizer.jsx';
import { FontCustomizer } from './FontCustomizer.jsx';
import { LayoutEditor } from './LayoutEditor.jsx';
import { MediaManager } from './MediaManager.jsx';
import { ThemeManager } from './ThemeManager.jsx';
import { TextEditor } from './TextEditor.jsx';
import { ElementEditor } from './ElementEditor.jsx';

export function VisualEditor() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Editor Visual Avançado</h2>
        <p className="text-gray-600">Personalize cada detalhe da aparência do seu site.</p>
      </div>

      <Tabs defaultValue="colors" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2">
          <TabsTrigger value="colors" className="flex items-center space-x-2"><Palette className="h-4 w-4" /><span>Cores</span></TabsTrigger>
          <TabsTrigger value="fonts" className="flex items-center space-x-2"><Type className="h-4 w-4" /><span>Fontes</span></TabsTrigger>
          <TabsTrigger value="layout" className="flex items-center space-x-2"><LayoutDashboard className="h-4 w-4" /><span>Layout</span></TabsTrigger>
          <TabsTrigger value="media" className="flex items-center space-x-2"><ImageIcon className="h-4 w-4" /><span>Mídias</span></TabsTrigger>
          <TabsTrigger value="themes" className="flex items-center space-x-2"><Sparkles className="h-4 w-4" /><span>Temas</span></TabsTrigger>
          <TabsTrigger value="texts" className="flex items-center space-x-2"><MessageSquare className="h-4 w-4" /><span>Textos</span></TabsTrigger>
          <TabsTrigger value="elements" className="flex items-center space-x-2"><SlidersHorizontal className="h-4 w-4" /><span>Elementos</span></TabsTrigger>
        </TabsList>

        <TabsContent value="colors" className="mt-6">
          <ColorCustomizer />
        </TabsContent>
        <TabsContent value="fonts" className="mt-6">
          <FontCustomizer />
        </TabsContent>
        <TabsContent value="layout" className="mt-6">
          <LayoutEditor />
        </TabsContent>
        <TabsContent value="media" className="mt-6">
          <MediaManager />
        </TabsContent>
        <TabsContent value="themes" className="mt-6">
          <ThemeManager />
        </TabsContent>
        <TabsContent value="texts" className="mt-6">
          <TextEditor />
        </TabsContent>
        <TabsContent value="elements" className="mt-6">
          <ElementEditor />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}