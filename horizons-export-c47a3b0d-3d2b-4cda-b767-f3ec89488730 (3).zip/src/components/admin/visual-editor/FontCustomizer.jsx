import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { Type, AlertTriangle } from 'lucide-react';

const googleFonts = [
  "Roboto", "Open Sans", "Lato", "Montserrat", "Poppins", "Nunito", "Merriweather", "Playfair Display", "Inter"
];

export function FontCustomizer() {
  const { state, dispatch } = useApp();
  const [fonts, setFonts] = useState(state.visualState.visualSettings.fonts);

  useEffect(() => {
    setFonts(state.visualState.visualSettings.fonts);
  }, [state.visualState.visualSettings.fonts]);

  const handleFontChange = (element, property, value) => {
    setFonts(prev => ({
      ...prev,
      [element]: {
        ...prev[element],
        [property]: property === 'size' ? parseInt(value, 10) : value
      }
    }));
  };

  const handleSubmit = () => {
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { fonts } });
    toast({ title: "Fontes atualizadas!", description: "As novas fontes e tamanhos foram aplicados." });
  };

  const fontElements = [
    { label: 'Títulos (H1, H2, etc.)', name: 'titles' },
    { label: 'Corpo do Texto (Parágrafos, descrições)', name: 'body' },
    { label: 'Botões', name: 'buttons' },
  ];

  const getFontRecommendation = (elementName) => {
    if (elementName === 'titles' && fonts.titles.size < 18) {
      return "Títulos geralmente ficam melhores com tamanhos maiores (ex: 24px+).";
    }
    if (elementName === 'body' && (fonts.body.size < 14 || fonts.body.size > 20)) {
      return "Para corpo de texto, tamanhos entre 14px e 18px são ideais para legibilidade.";
    }
    if (elementName === 'buttons' && fonts.buttons.size < 12) {
      return "Texto de botão muito pequeno pode ser difícil de ler e clicar.";
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Type className="mr-2 h-5 w-5" />Personalizador de Fontes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {fontElements.map(element => (
            <div key={element.name} className="p-4 border rounded-lg space-y-3">
              <h3 className="font-medium text-lg">{element.label}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Família da Fonte</label>
                  <Select
                    value={fonts[element.name].family}
                    onValueChange={(value) => handleFontChange(element.name, 'family', value)}
                  >
                    <SelectTrigger><SelectValue placeholder="Selecione uma fonte" /></SelectTrigger>
                    <SelectContent>
                      {googleFonts.map(font => (
                        <SelectItem key={font} value={`${font}, sans-serif`}>{font}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Tamanho da Fonte (px)</label>
                  <Input
                    type="number"
                    value={fonts[element.name].size}
                    onChange={(e) => handleFontChange(element.name, 'size', e.target.value)}
                    min="8"
                    max="72"
                  />
                </div>
              </div>
              {getFontRecommendation(element.name) && (
                <p className="text-xs text-blue-600 flex items-center mt-1">
                  <AlertTriangle className="h-3 w-3 mr-1 text-blue-500" />
                  {getFontRecommendation(element.name)}
                </p>
              )}
              <p className="mt-2 text-sm" style={{ fontFamily: fonts[element.name].family, fontSize: `${fonts[element.name].size}px` }}>
                Pré-visualização: O sabor que conquista paladares exigentes.
              </p>
            </div>
          ))}
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}>Salvar Fontes</Button>
      </div>
    </div>
  );
}