import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { Image as ImageIcon, Upload, Trash2 } from 'lucide-react';

export function MediaManager() {
  const { state, dispatch } = useApp();
  const [images, setImages] = useState(state.visualState.visualSettings.images);
  const [previews, setPreviews] = useState({});

  useEffect(() => {
    setImages(state.visualState.visualSettings.images);
    const initialPreviews = {};
    Object.keys(state.visualState.visualSettings.images).forEach(key => {
      if (state.visualState.visualSettings.images[key]) {
        initialPreviews[key] = state.visualState.visualSettings.images[key];
      }
    });
    setPreviews(initialPreviews);
  }, [state.visualState.visualSettings.images]);

  const handleImageUpload = (imageName, e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImages(prev => ({ ...prev, [imageName]: event.target.result }));
        setPreviews(prev => ({ ...prev, [imageName]: event.target.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = (imageName) => {
    setImages(prev => ({ ...prev, [imageName]: '' }));
    setPreviews(prev => ({ ...prev, [imageName]: null }));
  };
  
  const handleUrlChange = (imageName, url) => {
     setImages(prev => ({ ...prev, [imageName]: url }));
     setPreviews(prev => ({ ...prev, [imageName]: url }));
  };


  const handleSubmit = () => {
    const finalImages = {
      ...images,
      logo: images.logo || state.settingsState.settings.logo || '', 
    };
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { images: finalImages } });
    
    if (finalImages.logo && finalImages.logo !== state.settingsState.settings.logo) {
        dispatch({ type: 'UPDATE_SETTINGS', payload: { logo: finalImages.logo } });
    }

    toast({ title: "Mídias atualizadas!", description: "As imagens foram salvas." });
  };

  const imageFields = [
    { label: 'Logo da Empresa (Cabeçalho)', name: 'logo' },
    { label: 'Imagem do Banner Principal', name: 'banner' },
    { label: 'Imagem de Fundo do Site (Opcional)', name: 'siteBackground' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ImageIcon className="mr-2 h-5 w-5" />Gerenciador de Imagens e Mídias</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {imageFields.map(field => (
            <div key={field.name} className="p-4 border rounded-lg space-y-3">
              <h3 className="font-medium">{field.label}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Fazer upload do computador:</label>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(field.name, e)}
                    className="file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
                  />
                </div>
                 <div>
                  <label className="text-xs text-gray-500 block mb-1">Ou colar URL da imagem:</label>
                  <Input
                    type="text"
                    placeholder="https://exemplo.com/imagem.png"
                    value={images[field.name]?.startsWith('data:') ? '' : images[field.name] || ''}
                    onChange={(e) => handleUrlChange(field.name, e.target.value)}
                  />
                </div>
              </div>
              {previews[field.name] && (
                <div className="mt-3 flex flex-col items-start">
                  <p className="text-sm mb-1">Pré-visualização:</p>
                  <img src={previews[field.name]} alt={`${field.label} preview`} className="max-h-32 max-w-full object-contain rounded border bg-gray-100 p-1" />
                  <Button variant="ghost" size="sm" onClick={() => handleRemoveImage(field.name)} className="mt-2 text-red-600 hover:text-red-700">
                    <Trash2 className="h-4 w-4 mr-1" /> Remover Imagem
                  </Button>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}>Salvar Imagens</Button>
      </div>
    </div>
  );
}