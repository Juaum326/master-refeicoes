import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { SlidersHorizontal, Save, Eye, EyeOff, Zap } from 'lucide-react';

export function ElementEditor() {
  const { state, dispatch } = useApp();
  const [animationsEnabled, setAnimationsEnabled] = useState(state.visualState.visualSettings.animations.enabled);
  const [sectionsVisibility, setSectionsVisibility] = useState(
    state.visualState.visualSettings.layout.reduce((acc, section) => {
      acc[section.id] = section.visible;
      return acc;
    }, {})
  );

  useEffect(() => {
    setAnimationsEnabled(state.visualState.visualSettings.animations.enabled);
    setSectionsVisibility(
      state.visualState.visualSettings.layout.reduce((acc, section) => {
        acc[section.id] = section.visible;
        return acc;
      }, {})
    );
  }, [state.visualState.visualSettings.animations, state.visualState.visualSettings.layout]);

  const handleAnimationToggle = (checked) => {
    setAnimationsEnabled(checked);
  };

  const handleSectionVisibilityToggle = (sectionId, checked) => {
    setSectionsVisibility(prev => ({ ...prev, [sectionId]: checked }));
  };

  const handleSubmit = () => {
    const updatedLayout = state.visualState.visualSettings.layout.map(section => ({
      ...section,
      visible: sectionsVisibility[section.id] !== undefined ? sectionsVisibility[section.id] : section.visible,
    }));

    dispatch({
      type: 'UPDATE_VISUAL_SETTINGS',
      payload: {
        animations: { enabled: animationsEnabled },
        layout: updatedLayout,
      }
    });
    toast({ title: "Configurações de Elementos Salvas!", description: "As alterações foram aplicadas." });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><SlidersHorizontal className="mr-2 h-5 w-5" />Editor de Elementos Dinâmicos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor="animations-toggle" className="font-medium flex items-center">
                <Zap className="mr-2 h-4 w-4 text-purple-500" />
                Ativar Animações Visuais
              </Label>
              <Switch
                id="animations-toggle"
                checked={animationsEnabled}
                onCheckedChange={handleAnimationToggle}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">Ativa/desativa animações sutis em todo o site.</p>
          </div>

          <div>
            <h3 className="font-medium mb-2">Visibilidade das Seções</h3>
            <div className="space-y-3">
              {state.visualState.visualSettings.layout.map(section => (
                <div key={section.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor={`section-visibility-${section.id}`} className="font-medium">
                    {section.name}
                  </Label>
                  <div className="flex items-center space-x-2">
                    {sectionsVisibility[section.id] ? <Eye className="h-4 w-4 text-green-500" /> : <EyeOff className="h-4 w-4 text-red-500" />}
                    <Switch
                      id={`section-visibility-${section.id}`}
                      checked={sectionsVisibility[section.id] === undefined ? section.visible : sectionsVisibility[section.id]}
                      onCheckedChange={(checked) => handleSectionVisibilityToggle(section.id, checked)}
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Seções ocultas aqui não aparecerão para os clientes. A ordem das seções é gerenciada na aba "Layout".
            </p>
          </div>
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}><Save className="mr-2 h-4 w-4" />Salvar Configurações de Elementos</Button>
      </div>
    </div>
  );
}