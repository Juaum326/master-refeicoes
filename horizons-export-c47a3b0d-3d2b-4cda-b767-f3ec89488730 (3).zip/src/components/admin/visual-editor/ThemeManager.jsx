import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { Sparkles, Save, Trash2, RotateCcw } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.jsx";

export function ThemeManager() {
  const { state, dispatch } = useApp();
  const { themes, activeTheme } = state.visualState.visualSettings;
  const [newThemeName, setNewThemeName] = useState('');

  const handleSaveCurrentTheme = () => {
    if (!newThemeName.trim()) {
      toast({ title: "Erro", description: "Por favor, dê um nome ao tema.", variant: "destructive" });
      return;
    }
    const currentSettingsToSave = {
      colors: state.visualState.visualSettings.colors,
      fonts: state.visualState.visualSettings.fonts,
    };
    dispatch({ type: 'SAVE_THEME', payload: { name: newThemeName, settings: currentSettingsToSave } });
    toast({ title: "Tema salvo!", description: `O tema "${newThemeName}" foi salvo com sucesso.` });
    setNewThemeName('');
  };

  const handleLoadTheme = (themeId) => {
    dispatch({ type: 'LOAD_THEME', payload: themeId });
    toast({ title: "Tema carregado!", description: "O tema selecionado foi aplicado." });
  };

  const handleResetDefault = () => {
    dispatch({ type: 'RESET_DEFAULT_THEME', payload: { currentLogo: state.settingsState.settings.logo } });
    toast({ title: "Tema Padrão Restaurado!", description: "As configurações visuais foram redefinidas para o padrão." });
  };
  
  const handleDeleteTheme = (themeId) => {
    toast({ title: "Funcionalidade Pendente", description: "Remover temas ainda será implementado.", variant: "destructive" });
  };


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Sparkles className="mr-2 h-5 w-5" />Gerenciador de Temas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Salvar Tema Atual</h3>
            <div className="flex space-x-2">
              <Input
                placeholder="Nome do novo tema (ex: Natal, Verão)"
                value={newThemeName}
                onChange={(e) => setNewThemeName(e.target.value)}
              />
              <Button onClick={handleSaveCurrentTheme}><Save className="mr-2 h-4 w-4" />Salvar</Button>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-2">Temas Salvos</h3>
            {themes.length === 0 ? (
              <p className="text-sm text-gray-500">Nenhum tema salvo ainda.</p>
            ) : (
              <div className="space-y-2">
                {themes.map(theme => (
                  <div key={theme.id} className="flex justify-between items-center p-3 border rounded-lg">
                    <span>{theme.name}</span>
                    <div className="space-x-2">
                      <Button
                        variant={activeTheme === theme.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleLoadTheme(theme.id)}
                        disabled={activeTheme === theme.id}
                      >
                        {activeTheme === theme.id ? "Ativo" : "Aplicar"}
                      </Button>
                       <AlertDialog>
                        <AlertDialogTrigger asChild>
                           <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700"><Trash2 className="h-4 w-4" /></Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja excluir o tema "{theme.name}"? Esta ação não pode ser desfeita.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteTheme(theme.id)} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
           <div>
            <h3 className="font-medium mb-2">Restaurar Padrão</h3>
             <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full md:w-auto">
                    <RotateCcw className="mr-2 h-4 w-4" /> Restaurar Tema Padrão
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Restaurar Tema Padrão?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Isso redefinirá todas as cores, fontes e outras configurações visuais para os valores padrão. Seus temas salvos não serão afetados. Deseja continuar?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleResetDefault} className="bg-orange-500 hover:bg-orange-600">Restaurar Padrão</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}