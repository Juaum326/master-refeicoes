import React, { useState, useEffect } from 'react';
import { HexColorPicker } from 'react-colorful';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { Palette, AlertTriangle } from 'lucide-react';

const colorSuggestions = [
  { name: 'Roxo Vibrante', primary: '#8B5CF6', secondary: '#A855F7', background: '#F3E8FF', textPrimary: '#3730A3', textSecondary: '#5B21B6', buttonBackground: '#7C3AED', buttonText: '#FFFFFF' },
  { name: 'Verde Natural', primary: '#10B981', secondary: '#34D399', background: '#F0FDFA', textPrimary: '#065F46', textSecondary: '#047857', buttonBackground: '#059669', buttonText: '#FFFFFF' },
  { name: 'Azul Corporativo', primary: '#3B82F6', secondary: '#60A5FA', background: '#EFF6FF', textPrimary: '#1E40AF', textSecondary: '#1D4ED8', buttonBackground: '#2563EB', buttonText: '#FFFFFF' },
  { name: 'Laranja Aconchegante', primary: '#F97316', secondary: '#FB923C', background: '#FFF7ED', textPrimary: '#9A3412', textSecondary: '#C2410C', buttonBackground: '#EA580C', buttonText: '#FFFFFF' },
];

const getLuminance = (hexColor) => {
  const rgb = parseInt(hexColor.slice(1), 16);
  const r = (rgb >> 16) & 0xff;
  const g = (rgb >>  8) & 0xff;
  const b = (rgb >>  0) & 0xff;
  const a = [r, g, b].map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
};

const getContrastRatio = (color1, color2) => {
  const lum1 = getLuminance(color1);
  const lum2 = getLuminance(color2);
  const brightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);
  return (brightest + 0.05) / (darkest + 0.05);
};


export function ColorCustomizer() {
  const { state, dispatch } = useApp();
  const [colors, setColors] = useState(state.visualState.visualSettings.colors);
  const [activePicker, setActivePicker] = useState(null);

  useEffect(() => {
    setColors(state.visualState.visualSettings.colors);
  }, [state.visualState.visualSettings.colors]);

  const handleColorChange = (colorName, value) => {
    setColors(prev => ({ ...prev, [colorName]: value }));
  };

  const handleApplySuggestion = (suggestion) => {
    setColors(suggestion);
  };

  const handleSubmit = () => {
    dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { colors } });
    toast({ title: "Cores atualizadas!", description: "As novas cores foram aplicadas ao site." });
    setActivePicker(null);
  };

  const colorFields = [
    { label: 'Cor Primária', name: 'primary' },
    { label: 'Cor Secundária', name: 'secondary' },
    { label: 'Cor de Fundo do Site', name: 'background' },
    { label: 'Cor do Texto Principal', name: 'textPrimary' },
    { label: 'Cor do Texto Secundário', name: 'textSecondary' },
    { label: 'Cor de Fundo dos Botões', name: 'buttonBackground' },
    { label: 'Cor do Texto dos Botões', name: 'buttonText' },
  ];

  const checkContrast = (fg, bg) => {
    const ratio = getContrastRatio(fg, bg);
    if (ratio < 4.5) { 
      return {
        warning: true,
        message: `Baixo contraste (${ratio.toFixed(1)}:1). Pode ser difícil de ler.`,
        ratio: ratio.toFixed(1)
      };
    }
    return { warning: false, ratio: ratio.toFixed(1) };
  };

  const textPrimaryOnBackground = checkContrast(colors.textPrimary, colors.background);
  const textSecondaryOnBackground = checkContrast(colors.textSecondary, colors.background);
  const buttonTextOnButtonBackground = checkContrast(colors.buttonText, colors.buttonBackground);


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Palette className="mr-2 h-5 w-5" />Personalizador de Cores</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            {colorFields.map(field => (
              <div key={field.name} className="space-y-1">
                <label className="text-sm font-medium">{field.label}</label>
                <div className="flex items-center space-x-2">
                  <div
                    className="w-10 h-10 rounded border cursor-pointer"
                    style={{ backgroundColor: colors[field.name] }}
                    onClick={() => setActivePicker(activePicker === field.name ? null : field.name)}
                  />
                  <Input
                    type="text"
                    value={colors[field.name]}
                    onChange={(e) => handleColorChange(field.name, e.target.value)}
                    placeholder="#RRGGBB"
                  />
                </div>
                {activePicker === field.name && (
                  <div className="relative z-10 mt-2">
                     <div className="absolute" style={{left: '50%', transform: 'translateX(-50%)'}}>
                        <HexColorPicker color={colors[field.name]} onChange={(newColor) => handleColorChange(field.name, newColor)} />
                     </div>
                  </div>
                )}
                {field.name === 'textPrimary' && textPrimaryOnBackground.warning && (
                  <p className="text-xs text-orange-600 flex items-center mt-1"><AlertTriangle className="h-3 w-3 mr-1" />{textPrimaryOnBackground.message}</p>
                )}
                {field.name === 'textSecondary' && textSecondaryOnBackground.warning && (
                  <p className="text-xs text-orange-600 flex items-center mt-1"><AlertTriangle className="h-3 w-3 mr-1" />{textSecondaryOnBackground.message}</p>
                )}
                {field.name === 'buttonText' && buttonTextOnButtonBackground.warning && (
                  <p className="text-xs text-orange-600 flex items-center mt-1"><AlertTriangle className="h-3 w-3 mr-1" />{buttonTextOnButtonBackground.message}</p>
                )}
              </div>
            ))}
          </div>
          <div className="space-y-4">
            <h3 className="text-md font-medium">Sugestões de Paletas</h3>
            <div className="grid grid-cols-2 gap-2">
              {colorSuggestions.map(suggestion => (
                <Button key={suggestion.name} variant="outline" onClick={() => handleApplySuggestion(suggestion)} className="h-auto py-2 flex flex-col items-start">
                  <span className="font-semibold text-sm">{suggestion.name}</span>
                  <div className="flex mt-1 space-x-1">
                    <div className="w-4 h-4 rounded-sm" style={{backgroundColor: suggestion.primary}}></div>
                    <div className="w-4 h-4 rounded-sm" style={{backgroundColor: suggestion.secondary}}></div>
                    <div className="w-4 h-4 rounded-sm" style={{backgroundColor: suggestion.background}}></div>
                    <div className="w-4 h-4 rounded-sm" style={{backgroundColor: suggestion.textPrimary}}></div>
                  </div>
                </Button>
              ))}
            </div>
             <Card className="mt-4">
                <CardHeader className="pb-2"><CardTitle className="text-base">Verificador de Contraste</CardTitle></CardHeader>
                <CardContent className="text-sm space-y-1">
                    <p>Texto Principal / Fundo: <span className={textPrimaryOnBackground.warning ? 'text-orange-600 font-semibold' : 'text-green-600 font-semibold'}>{textPrimaryOnBackground.ratio}:1</span></p>
                    <p>Texto Secundário / Fundo: <span className={textSecondaryOnBackground.warning ? 'text-orange-600 font-semibold' : 'text-green-600 font-semibold'}>{textSecondaryOnBackground.ratio}:1</span></p>
                    <p>Texto Botão / Fundo Botão: <span className={buttonTextOnButtonBackground.warning ? 'text-orange-600 font-semibold' : 'text-green-600 font-semibold'}>{buttonTextOnButtonBackground.ratio}:1</span></p>
                    <p className="text-xs text-gray-500 mt-1">Mínimo recomendado: 4.5:1 para texto normal.</p>
                </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
      <div className="flex justify-end">
        <Button onClick={handleSubmit}>Salvar Cores</Button>
      </div>
    </div>
  );
}