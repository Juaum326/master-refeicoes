import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function DeliveryManagement() {
  const { state, dispatch } = useApp();
  const { neighborhoods } = state.settingsState; 
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingNeighborhood, setEditingNeighborhood] = useState(null);
  const [formData, setFormData] = useState({ name: '', fee: '' });

  const resetForm = () => {
    setFormData({ name: '', fee: '' });
    setEditingNeighborhood(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.fee) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos.",
        variant: "destructive"
      });
      return;
    }

    const neighborhoodData = {
      name: formData.name,
      fee: parseFloat(formData.fee)
    };

    let updatedNeighborhoodsPayload;
    
    if (editingNeighborhood) {
      updatedNeighborhoodsPayload = neighborhoods.map(n => 
        n.name === editingNeighborhood.name ? neighborhoodData : n
      );
      toast({
        title: "Bairro atualizado!",
        description: "As alterações foram salvas com sucesso.",
      });
    } else {
      if (neighborhoods.some(n => n.name.toLowerCase() === formData.name.toLowerCase())) {
        toast({
          title: "Bairro já existe",
          description: "Este bairro já está cadastrado.",
          variant: "destructive"
        });
        return;
      }
      
      updatedNeighborhoodsPayload = [...neighborhoods, neighborhoodData];
      toast({
        title: "Bairro adicionado!",
        description: "Novo bairro foi criado com sucesso.",
      });
    }

    dispatch({ type: 'UPDATE_NEIGHBORHOODS', payload: updatedNeighborhoodsPayload });
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (neighborhood) => {
    setEditingNeighborhood(neighborhood);
    setFormData({
      name: neighborhood.name,
      fee: neighborhood.fee.toString()
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (neighborhoodName) => {
    const updatedNeighborhoodsPayload = neighborhoods.filter(n => n.name !== neighborhoodName);
    dispatch({ type: 'UPDATE_NEIGHBORHOODS', payload: updatedNeighborhoodsPayload });
    toast({
      title: "Bairro removido!",
      description: "O bairro foi excluído com sucesso.",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Entrega</h2>
          <p className="text-gray-600">Configure bairros e taxas de entrega</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" />
              Novo Bairro
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingNeighborhood ? 'Editar Bairro' : 'Novo Bairro'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nome do Bairro *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ex: Centro, Vila Nova..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Taxa de Entrega (R$) *</label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.fee}
                  onChange={(e) => setFormData(prev => ({ ...prev, fee: e.target.value }))}
                  placeholder="0.00"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  {editingNeighborhood ? 'Atualizar' : 'Criar'} Bairro
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {neighborhoods.map((neighborhood) => (
          <motion.div
            key={neighborhood.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-purple-600" />
                    <h3 className="font-semibold">{neighborhood.name}</h3>
                  </div>
                  <span className="text-lg font-bold text-purple-600">
                    R$ {neighborhood.fee.toFixed(2)}
                  </span>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(neighborhood)}
                    className="flex-1"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Editar
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(neighborhood.name)}
                    className="flex-1"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {neighborhoods.length === 0 && (
        <Card className="p-12 text-center">
          <div className="text-gray-500">
            <MapPin className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Nenhum bairro cadastrado</h3>
            <p className="text-sm">Adicione bairros para configurar as taxas de entrega</p>
          </div>
        </Card>
      )}
    </motion.div>
  );
}