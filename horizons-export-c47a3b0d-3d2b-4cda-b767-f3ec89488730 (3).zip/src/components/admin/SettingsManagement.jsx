import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Building, Clock, ToggleLeft, ToggleRight, Palette, Moon, Sun, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function SettingsManagement() {
  const { state, dispatch } = useApp();
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;
  const [formData, setFormData] = useState(settings);
  const [visualData, setVisualData] = useState(visualSettings);

  useEffect(() => {
    setFormData(state.settingsState.settings);
  }, [state.settingsState.settings]);

  useEffect(() => {
    setVisualData(state.visualState.visualSettings);
  }, [state.visualState.visualSettings]);


  const handleSettingsSubmit = (e) => {
    e.preventDefault();
    dispatch({ type: 'UPDATE_SETTINGS', payload: formData });
    dispatch({ 
      type: 'UPDATE_VISUAL_SETTINGS', 
      payload: { 
        images: { siteBackground: visualData.images.siteBackground },
      } 
    });
    toast({
      title: "Configurações salvas!",
      description: "Todas as alterações foram aplicadas com sucesso.",
    });
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({ ...prev, logo: event.target.result }));
        dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { images: { ...visualData.images, logo: event.target.result } } });
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSiteBackgroundUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setVisualData(prev => ({ ...prev, images: { ...prev.images, siteBackground: event.target.result } }));
      };
      reader.readAsDataURL(file);
    }
  };


  const handleAddressChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      address: { ...prev.address, [field]: value }
    }));
  };

  const handleOpeningHoursChange = (day, field, value) => {
    setFormData(prev => ({
      ...prev,
      openingHours: {
        ...prev.openingHours,
        [day]: {
          ...prev.openingHours[day],
          [field]: field === 'enabled' ? value : value
        }
      }
    }));
  };
  
  const daysOfWeek = {
    monday: "Segunda",
    tuesday: "Terça",
    wednesday: "Quarta",
    thursday: "Quinta",
    friday: "Sexta",
    saturday: "Sábado",
    sunday: "Domingo"
  };

  const handleManualOpenToggle = (status) => {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { ...formData, manualOpen: status } });
    toast({ title: `Loja ${status === true ? 'Aberta' : status === false ? 'Fechada' : 'em Horário Automático'} Manualmente` });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Configurações Gerais e Visuais</h2>
        <p className="text-gray-600">Personalize informações da sua empresa, horários e aparência do site</p>
      </div>

      <form onSubmit={handleSettingsSubmit} className="space-y-6">
        <Card>
          <CardHeader><CardTitle className="flex items-center"><Building className="h-5 w-5 mr-2" />Informações da Empresa</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nome da Empresa</label>
              <Input value={formData.companyName} onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))} placeholder="Nome da sua empresa" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Logo da Empresa</label>
              <div className="space-y-3">
                <Input type="file" accept="image/*" onChange={handleLogoUpload} className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100" />
                {formData.logo && (
                  <div className="flex items-center space-x-3">
                    <img src={formData.logo} alt="Logo preview" className="h-16 w-16 object-cover rounded-lg border" />
                    <Button type="button" variant="outline" size="sm" onClick={() => {
                      setFormData(prev => ({ ...prev, logo: '' }));
                      dispatch({ type: 'UPDATE_VISUAL_SETTINGS', payload: { images: { ...visualData.images, logo: '' } } });
                    }}>Remover Logo</Button>
                  </div>
                )}
              </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Telefone</label>
                <Input value={formData.phone} onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))} placeholder="(11) 99999-9999" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">WhatsApp (apenas números)</label>
                <Input value={formData.whatsapp} onChange={(e) => setFormData(prev => ({ ...prev, whatsapp: e.target.value }))} placeholder="5511999999999" />
              </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><label className="block text-sm font-medium mb-1">Rua</label><Input value={formData.address.street} onChange={(e) => handleAddressChange('street', e.target.value)} placeholder="Rua das Flores, 123" /></div>
              <div><label className="block text-sm font-medium mb-1">Bairro</label><Input value={formData.address.neighborhood} onChange={(e) => handleAddressChange('neighborhood', e.target.value)} placeholder="Centro" /></div>
              <div><label className="block text-sm font-medium mb-1">Cidade</label><Input value={formData.address.city} onChange={(e) => handleAddressChange('city', e.target.value)} placeholder="São Paulo" /></div>
              <div><label className="block text-sm font-medium mb-1">Estado</label><Input value={formData.address.state} onChange={(e) => handleAddressChange('state', e.target.value)} placeholder="SP" /></div>
              <div><label className="block text-sm font-medium mb-1">CEP</label><Input value={formData.address.zipCode} onChange={(e) => handleAddressChange('zipCode', e.target.value)} placeholder="01234-567" /></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center"><Clock className="h-5 w-5 mr-2" />Horários de Funcionamento</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="mb-4 space-x-2">
                <Button type="button" variant={settings.manualOpen === true ? "default" : "outline"} onClick={() => handleManualOpenToggle(true)} className={settings.manualOpen === true ? "bg-green-500 hover:bg-green-600" : ""}>Abrir Manualmente</Button>
                <Button type="button" variant={settings.manualOpen === false ? "default" : "outline"} onClick={() => handleManualOpenToggle(false)} className={settings.manualOpen === false ? "bg-red-500 hover:bg-red-600" : ""}>Fechar Manualmente</Button>
                <Button type="button" variant={settings.manualOpen === null ? "default" : "outline"} onClick={() => handleManualOpenToggle(null)} className={settings.manualOpen === null ? "bg-blue-500 hover:bg-blue-600" : ""}>Horário Automático</Button>
            </div>
            {Object.entries(daysOfWeek).map(([dayKey, dayName]) => (
              <div key={dayKey} className="grid grid-cols-[100px_1fr_1fr_auto] gap-2 items-center">
                <span className="font-medium text-sm">{dayName}:</span>
                <Input type="time" value={formData.openingHours[dayKey]?.open || "08:00"} onChange={(e) => handleOpeningHoursChange(dayKey, 'open', e.target.value)} disabled={!formData.openingHours[dayKey]?.enabled} />
                <Input type="time" value={formData.openingHours[dayKey]?.close || "18:00"} onChange={(e) => handleOpeningHoursChange(dayKey, 'close', e.target.value)} disabled={!formData.openingHours[dayKey]?.enabled} />
                <Button type="button" variant="outline" size="sm" onClick={() => handleOpeningHoursChange(dayKey, 'enabled', !formData.openingHours[dayKey]?.enabled)}>
                  {formData.openingHours[dayKey]?.enabled ? <ToggleRight className="h-5 w-5 text-green-500" /> : <ToggleLeft className="h-5 w-5 text-red-500" />}
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center"><Palette className="h-5 w-5 mr-2" />Aparência do Site</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Tema do Site</label>
                <Select value={formData.siteTheme || 'light'} onValueChange={(value) => setFormData(prev => ({ ...prev, siteTheme: value }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light"><Sun className="inline h-4 w-4 mr-2"/> Claro</SelectItem>
                    <SelectItem value="dark"><Moon className="inline h-4 w-4 mr-2"/> Escuro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Imagem de Fundo do Site (Banner)</label>
                 <div className="space-y-3">
                    <Input type="file" accept="image/*" onChange={handleSiteBackgroundUpload} className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100" />
                    {visualData.images.siteBackground && (
                    <div className="flex items-center space-x-3">
                        <img src={visualData.images.siteBackground} alt="Site background preview" className="h-16 w-auto object-contain rounded-lg border" />
                        <Button type="button" variant="outline" size="sm" onClick={() => setVisualData(prev => ({...prev, images: {...prev.images, siteBackground: ''}}))}>Remover Imagem</Button>
                    </div>
                    )}
                </div>
              </div>
            </div>
             <p className="text-sm text-gray-600">Cores principais, fontes e outros detalhes visuais são gerenciados no <strong className="text-purple-600">Editor Visual Avançado</strong>.</p>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
            <Save className="h-4 w-4 mr-2" />Salvar Configurações
          </Button>
        </div>
      </form>
    </motion.div>
  );
}