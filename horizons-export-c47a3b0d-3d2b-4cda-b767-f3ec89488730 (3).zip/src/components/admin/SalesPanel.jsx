import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Printer, MessageSquare, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

import { CouponManagement } from '@/components/sales/CouponManagement.jsx';
import { SalesAnalytics } from '@/components/sales/SalesAnalytics.jsx';
import { SalesBooster } from '@/components/sales/SalesBooster.jsx';
import { IntelligentManager } from '@/components/sales/IntelligentManager.jsx';
import { OrderHistory } from './OrderHistory.jsx';

export function SalesPanel({ activeSubTab, setActiveSubTab }) {
  const { state, dispatch } = useApp();
  const { settings } = state.settingsState;
  const { orders } = state.salesState;

  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancellationReason, setCancellationReason] = useState('');

  const activeOrders = orders.filter(order => order.status !== 'delivered' && order.status !== 'cancelled');

  const handleUpdateOrderStatus = (orderId, status) => {
    dispatch({ type: 'UPDATE_ORDER_STATUS', payload: { orderId, status } });
    const order = orders.find(o => o.id === orderId);
    if (order && settings.whatsappIntegrationEnabled && settings.notificationPreferences.allEnabled && settings.notificationPreferences.newOrder) {
      let statusMessage = '';
      switch (status) {
        case 'confirmed': statusMessage = `✅ Seu pedido #${orderId} foi confirmado e está em produção!`; break;
        case 'out_for_delivery': statusMessage = `📦 Seu pedido #${orderId} saiu para entrega!`; break;
        case 'delivered': statusMessage = `✔️ Seu pedido #${orderId} foi entregue! Bom apetite!`; break;
        default: break;
      }
      if (statusMessage && order.customerPhone) {
        const whatsappUrl = `https://wa.me/${order.customerPhone}?text=${encodeURIComponent(statusMessage)}`;
        window.open(whatsappUrl, '_blank');
      } else if (statusMessage && !order.customerPhone) {
         toast({ title: "Aviso", description: `Pedido ${orderId} atualizado. Cliente sem telefone para notificação via WhatsApp.`});
      }
    }
    toast({ title: "Status do Pedido Atualizado!", description: `Pedido #${orderId} agora está: ${getStatusText(status)}` });
  };

  const openOrderCancelModal = (order) => {
    setSelectedOrder(order);
    setIsCancelModalOpen(true);
    setCancellationReason('');
  };

  const handleCancelOrder = () => {
    if (!selectedOrder || !cancellationReason.trim()) {
      toast({ title: "Motivo obrigatório", description: "Por favor, informe o motivo do cancelamento.", variant: "destructive" });
      return;
    }
    dispatch({ type: 'CANCEL_ORDER', payload: { orderId: selectedOrder.id, reason: cancellationReason } });
    if (settings.whatsappIntegrationEnabled && selectedOrder.customerPhone && settings.notificationPreferences.allEnabled && settings.notificationPreferences.newOrder) {
      const cancelMessage = `❌ Seu pedido #${selectedOrder.id} foi cancelado.\nMotivo: ${cancellationReason}`;
      const whatsappUrl = `https://wa.me/${selectedOrder.customerPhone}?text=${encodeURIComponent(cancelMessage)}`;
      window.open(whatsappUrl, '_blank');
    } else if (settings.whatsappIntegrationEnabled && !selectedOrder.customerPhone) {
        toast({ title: "Aviso", description: `Pedido ${selectedOrder.id} cancelado. Cliente sem telefone para notificação via WhatsApp.`});
    }
    toast({ title: "Pedido Cancelado", description: `Pedido #${selectedOrder.id} foi cancelado.` });
    setIsCancelModalOpen(false);
    setSelectedOrder(null);
  };
  
  const handlePrintOrder = (order) => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Pedido Master Refeições</title>');
    printWindow.document.write('<style>body{font-family:monospace;margin:20px;font-size:12px;} h1{text-align:center;font-size:16px;margin-bottom:5px;} .item{margin-bottom:3px;} .total{font-weight:bold;margin-top:10px;border-top:1px dashed #000;padding-top:5px;} table{width:100%;font-size:12px;} td{vertical-align:top;}</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(`<h1>${settings.companyName}</h1>`);
    printWindow.document.write(`<p style="text-align:center;font-size:10px;">${settings.address.street}, ${settings.address.neighborhood} - ${settings.phone}</p>`);
    printWindow.document.write(`<p><strong>Pedido #${order.id}</strong> - ${new Date(order.createdAt).toLocaleString()}</p>`);
    printWindow.document.write(`<p><strong>Cliente:</strong> ${order.customerName} ${order.customerPhone ? `(${order.customerPhone})` : ''}</p>`);
    
    if (order.deliveryType === 'delivery') {
      printWindow.document.write(`<p><strong>Entrega:</strong> ${order.deliveryAddress.street}, ${order.deliveryAddress.number} ${order.deliveryAddress.complement || ''} - ${order.deliveryAddress.neighborhood}</p>`);
    } else {
      printWindow.document.write(`<p><strong>Retirada no Local</strong></p>`);
    }
    printWindow.document.write('<hr>');
    
    printWindow.document.write('<h3>Itens:</h3>');
    order.items.forEach(item => {
      printWindow.document.write(`<div class="item">${item.quantity}x ${item.name} - R$ ${(item.price * item.quantity).toFixed(2)}</div>`);
      if (item.selectedAdditionals && item.selectedAdditionals.length > 0) {
        item.selectedAdditionals.forEach(add => {
          printWindow.document.write(`<div style="padding-left:15px;font-size:10px;">&nbsp;&nbsp;+ ${add.name} (R$ ${add.price.toFixed(2)})</div>`);
        });
      }
      if (item.observations) {
        printWindow.document.write(`<div style="padding-left:15px;font-size:10px;">&nbsp;&nbsp;Obs: ${item.observations}</div>`);
      }
    });
    printWindow.document.write('<hr>');

    if (order.orderObservations) {
      printWindow.document.write(`<p><strong>Obs. Gerais:</strong> ${order.orderObservations}</p>`);
    }
    
    printWindow.document.write(`<table>`);
    printWindow.document.write(`<tr><td>Subtotal:</td><td style="text-align:right;">R$ ${order.subtotal.toFixed(2)}</td></tr>`);
    if (order.discount > 0) {
      printWindow.document.write(`<tr><td>Desconto (${order.appliedCoupon || 'N/A'}):</td><td style="text-align:right;">- R$ ${order.discount.toFixed(2)}</td></tr>`);
    }
    if (order.deliveryType === 'delivery' && order.deliveryFee > 0) {
      printWindow.document.write(`<tr><td>Taxa Entrega:</td><td style="text-align:right;">R$ ${order.deliveryFee.toFixed(2)}</td></tr>`);
    }
    printWindow.document.write(`<tr><td class="total">TOTAL:</td><td class="total" style="text-align:right;">R$ ${order.total.toFixed(2)}</td></tr>`);
    printWindow.document.write(`</table>`);

    printWindow.document.write(`<p><strong>Pagamento:</strong> ${order.paymentMethod}`);
    if (order.paymentMethod === 'Dinheiro' && order.changeFor) {
      printWindow.document.write(` (Troco para R$ ${parseFloat(order.changeFor).toFixed(2)})`);
    }
    printWindow.document.write('</p>');
    printWindow.document.write(`<p style="text-align:center;margin-top:20px;">Obrigado pela preferência!</p>`);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    setTimeout(() => {
        printWindow.print();
    }, 500);
    toast({ title: "Imprimindo Pedido...", description: `Preparando pedido #${order.id} para impressão.` });
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-400';
      case 'confirmed': return 'bg-blue-500';
      case 'out_for_delivery': return 'bg-orange-500';
      case 'delivered': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-400';
    }
  };
  
  const getStatusText = (status) => {
    const map = { pending: 'Pendente', confirmed: 'Confirmado', out_for_delivery: 'Saiu para Entrega', delivered: 'Entregue', cancelled: 'Cancelado' };
    return map[status] || status;
  };

  const renderSalesContent = () => {
    switch (activeSubTab) {
      case 'orders':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Pedidos Ativos</h2>
            {activeOrders.length === 0 ? (
              <Card className="p-12 text-center text-gray-500">
                <ShoppingCart className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">Nenhum pedido ativo</h3>
                <p className="text-sm">Novos pedidos ou pedidos pendentes aparecerão aqui.</p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeOrders.map(order => (
                  <Card key={order.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg text-slate-700">Pedido #{order.id}</CardTitle>
                        <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${getStatusColor(order.status)}`}>
                          {getStatusText(order.status)}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleString()}</p>
                    </CardHeader>
                    <CardContent className="space-y-3 text-sm">
                      <p><strong>Cliente:</strong> {order.customerName} {order.customerPhone && `(${order.customerPhone})`}</p>
                      <p><strong>Total:</strong> R$ {order.total.toFixed(2)}</p>
                      <p><strong>Pagamento:</strong> {order.paymentMethod} {order.paymentMethod === 'Dinheiro' && order.changeFor ? `(Troco p/ R$ ${parseFloat(order.changeFor).toFixed(2)})` : ''}</p>
                      <p><strong>Entrega:</strong> {order.deliveryType === 'delivery' ? `${order.deliveryAddress.street}, ${order.deliveryAddress.number}` : 'Retirada'}</p>
                      <details className="text-xs">
                        <summary className="cursor-pointer text-slate-600 hover:text-slate-800">Ver Itens ({order.items.length})</summary>
                        <ul className="list-disc pl-5 mt-1 bg-slate-50 p-2 rounded">
                          {order.items.map(item => ( <li key={item.cartId}>{item.quantity}x {item.name}</li> ))}
                        </ul>
                      </details>
                      {order.orderObservations && <p className="text-xs italic"><strong>Obs:</strong> {order.orderObservations}</p>}
                      {order.cancellationReason && <p className="text-xs text-red-600"><strong>Motivo Cancel.:</strong> {order.cancellationReason}</p>}
                      <div className="pt-3 border-t space-y-2">
                        {order.status === 'pending' && (<Button onClick={() => handleUpdateOrderStatus(order.id, 'confirmed')} className="w-full bg-blue-500 hover:bg-blue-600">Confirmar Produção</Button>)}
                        {order.status === 'confirmed' && (<Button onClick={() => handleUpdateOrderStatus(order.id, 'out_for_delivery')} className="w-full bg-orange-500 hover:bg-orange-600">Saiu para Entrega</Button>)}
                        {order.status === 'out_for_delivery' && (<Button onClick={() => handleUpdateOrderStatus(order.id, 'delivered')} className="w-full bg-green-500 hover:bg-green-600">Pedido Entregue</Button>)}
                        <div className="flex space-x-2">
                          <Button onClick={() => handlePrintOrder(order)} variant="outline" className="flex-1"><Printer className="h-4 w-4 mr-1"/> Imprimir</Button>
                          {order.status !== 'delivered' && order.status !== 'cancelled' && (<Button onClick={() => openOrderCancelModal(order)} variant="destructive" className="flex-1"><MessageSquare className="h-4 w-4 mr-1"/> Cancelar</Button>)}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        );
      case 'history':
        return <OrderHistory />;
      case 'coupons':
        return <CouponManagement />;
      case 'analytics':
        return <SalesAnalytics />;
      case 'booster':
        return <SalesBooster />;
      case 'manager':
        return <IntelligentManager />;
      default:
        return <div>Selecione uma aba</div>;
    }
  };

  return (
    <>
      {renderSalesContent()}
      <Dialog open={isCancelModalOpen} onOpenChange={setIsCancelModalOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Cancelar Pedido #{selectedOrder?.id}</DialogTitle></DialogHeader>
          <div className="py-4">
            <label htmlFor="cancellationReason" className="block text-sm font-medium text-gray-700 mb-1">Motivo do Cancelamento (será enviado ao cliente):</label>
            <Textarea id="cancellationReason" value={cancellationReason} onChange={(e) => setCancellationReason(e.target.value)} placeholder="Ex: Item indisponível, problema na entrega, etc." rows={3}/>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Voltar</Button></DialogClose>
            <Button onClick={handleCancelOrder} variant="destructive" disabled={!cancellationReason.trim()}>Confirmar Cancelamento</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}