import React, { useState, useEffect } from 'react';
import { Plus, X, Upload, ToggleLeft, ToggleRight, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function ProductForm({ product, onSubmit, onCancel }) {
  const { state } = useApp();
  const { categories, additionals: globalAdditionalsList } = state.productState;
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: categories[0]?.id || 'quentinhas',
    image: '',
    additionals: [],
    available: true,
    order: 0,
  });
  const [newAdditional, setNewAdditional] = useState({ id: '', name: '', price: '', available: true });

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || '',
        description: product.description || '',
        price: product.price?.toString() || '',
        category: product.category || (categories[0]?.id || 'quentinhas'),
        image: product.image || '',
        additionals: product.additionals?.map(add => ({...add, available: add.available !== undefined ? add.available : true })) || [],
        available: product.available !== undefined ? product.available : true,
        order: product.order || 0,
      });
    } else {
      setFormData({
        name: '',
        description: '',
        price: '',
        category: categories[0]?.id || 'quentinhas',
        image: '',
        additionals: [],
        available: true,
        order: 0,
      });
    }
  }, [product, categories]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        handleChange('image', e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const addProductAdditional = () => {
    if (!newAdditional.id || !newAdditional.price) {
      toast({
        title: "Campos obrigatórios",
        description: "Selecione um adicional e defina um preço.",
        variant: "destructive"
      });
      return;
    }
    const selectedGlobalAdditional = globalAdditionalsList.find(ga => ga.id.toString() === newAdditional.id);
    if (!selectedGlobalAdditional) {
        toast({ title: "Adicional inválido", variant: "destructive"});
        return;
    }

    const additionalToAdd = {
      id: parseInt(newAdditional.id, 10),
      name: selectedGlobalAdditional.name,
      price: parseFloat(newAdditional.price),
      available: newAdditional.available,
    };

    setFormData(prev => ({
      ...prev,
      additionals: [...prev.additionals, additionalToAdd]
    }));
    setNewAdditional({ id: '', name: '', price: '', available: true });
  };

  const removeProductAdditional = (additionalId) => {
    setFormData(prev => ({
      ...prev,
      additionals: prev.additionals.filter(add => add.id !== additionalId)
    }));
  };

  const toggleProductAdditionalAvailability = (additionalId) => {
    setFormData(prev => ({
      ...prev,
      additionals: prev.additionals.map(add => 
        add.id === additionalId ? { ...add, available: !add.available } : add
      )
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.description || !formData.price) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha nome, descrição e preço.",
        variant: "destructive"
      });
      return;
    }
    onSubmit({ 
      ...formData, 
      price: parseFloat(formData.price),
      order: parseInt(formData.order, 10) || 0,
      additionals: formData.additionals.map(add => ({...add, price: parseFloat(add.price)}))
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Nome *</label>
          <Input
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            placeholder="Nome do produto"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Categoria *</label>
          <Select
            value={formData.category}
            onValueChange={(value) => handleChange('category', value)}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Descrição *</label>
        <Textarea
          value={formData.description}
          onChange={(e) => handleChange('description', e.target.value)}
          placeholder="Descrição do produto"
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Preço *</label>
          <Input
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => handleChange('price', e.target.value)}
            placeholder="0.00"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Ordem de Exibição</label>
          <Input
            type="number"
            value={formData.order}
            onChange={(e) => handleChange('order', e.target.value)}
            placeholder="0"
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">Disponibilidade do Produto</label>
        <Button 
          type="button" 
          variant="outline"
          onClick={() => handleChange('available', !formData.available)}
          className="w-full flex justify-between items-center"
        >
          {formData.available ? "Disponível" : "Indisponível"}
          {formData.available ? <ToggleRight className="h-5 w-5 text-green-500" /> : <ToggleLeft className="h-5 w-5 text-red-500" />}
        </Button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Imagem</label>
        <div className="space-y-2">
          <Input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
          />
          {formData.image && (
            <div className="relative w-32 h-32">
              <img src={formData.image} alt="Preview" className="w-full h-full object-cover rounded-lg" />
              <Button type="button" variant="destructive" size="sm" onClick={() => handleChange('image', '')} className="absolute -top-2 -right-2 h-6 w-6 p-0">
                <X className="h-3 w-3" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {formData.category === 'quentinhas' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Adicionais do Produto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto_auto] gap-2 items-end">
              <div className="flex-grow">
                <label className="text-xs">Adicional Global</label>
                <Select value={newAdditional.id} onValueChange={(value) => setNewAdditional(prev => ({ ...prev, id: value, name: globalAdditionalsList.find(ga => ga.id.toString() === value)?.name || '' }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {globalAdditionalsList.filter(ga => ga.available).map(ga => (
                      <SelectItem key={ga.id} value={ga.id.toString()}>{ga.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full sm:w-24">
                <label className="text-xs">Preço (R$)</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="Preço"
                  value={newAdditional.price}
                  onChange={(e) => setNewAdditional(prev => ({ ...prev, price: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-xs invisible">Disponível</label>
                 <Button 
                    type="button" 
                    variant="outline"
                    size="sm"
                    onClick={() => setNewAdditional(prev => ({...prev, available: !prev.available}))}
                    className="w-full"
                  >
                    {newAdditional.available ? <Eye className="h-4 w-4 text-green-500"/> : <EyeOff className="h-4 w-4 text-red-500"/>}
                  </Button>
              </div>
              <Button type="button" onClick={addProductAdditional} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {formData.additionals.length > 0 && (
              <div className="space-y-2 pt-2 border-t">
                {formData.additionals.map((additional) => (
                  <div key={additional.id} className="flex items-center justify-between bg-gray-50 p-2 rounded text-sm">
                    <div className="flex items-center gap-2">
                       <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        className="h-6 w-6"
                        onClick={() => toggleProductAdditionalAvailability(additional.id)}
                      >
                        {additional.available ? <Eye className="h-4 w-4 text-green-500"/> : <EyeOff className="h-4 w-4 text-red-500"/>}
                      </Button>
                      <span>{additional.name} - R$ {parseFloat(additional.price).toFixed(2)}</span>
                    </div>
                    <Button type="button" variant="ghost" size="sm" onClick={() => removeProductAdditional(additional.id)} className="text-red-500 hover:text-red-700">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
          {product ? 'Atualizar' : 'Criar'} Produto
        </Button>
      </div>
    </form>
  );
}