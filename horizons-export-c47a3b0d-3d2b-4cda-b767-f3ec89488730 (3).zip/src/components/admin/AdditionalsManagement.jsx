import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Utensils as CookingPot, Eye, EyeOff, ToggleLeft, ToggleRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function AdditionalsManagement() {
  const { state, dispatch } = useApp();
  const { additionals, products, beverages, sides } = state.productState;
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAdditional, setEditingAdditional] = useState(null);
  const [formData, setFormData] = useState({ name: '', price: '', available: true });

  const resetForm = () => {
    setFormData({ name: '', price: '', available: true });
    setEditingAdditional(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.price) {
      toast({ title: "Nome e preço são obrigatórios", variant: "destructive" });
      return;
    }
    const additionalData = {
      id: editingAdditional ? editingAdditional.id : Date.now(),
      name: formData.name.trim(),
      price: parseFloat(formData.price),
      available: formData.available,
    };

    let updatedAdditionalsPayload;
    if (editingAdditional) {
      updatedAdditionalsPayload = additionals.map(add => add.id === editingAdditional.id ? additionalData : add);
      toast({ title: "Adicional atualizado!" });
    } else {
      updatedAdditionalsPayload = [...additionals, additionalData];
      toast({ title: "Adicional adicionado!" });
    }
    dispatch({ type: 'UPDATE_ADDITIONALS', payload: updatedAdditionalsPayload });
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (additional) => {
    setEditingAdditional(additional);
    setFormData({ 
      name: additional.name, 
      price: additional.price.toString(),
      available: additional.available !== undefined ? additional.available : true 
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (additionalId) => {
    const allProducts = [...products, ...beverages, ...sides];
    const isInUse = allProducts.some(product => product.additionals?.some(pa => pa.id === additionalId));
    
    if (isInUse) {
        toast({ title: "Erro ao excluir", description: "Adicional está em uso por produtos.", variant: "destructive"});
        return;
    }
    const updatedAdditionalsPayload = additionals.filter(add => add.id !== additionalId);
    dispatch({ type: 'UPDATE_ADDITIONALS', payload: updatedAdditionalsPayload });
    toast({ title: "Adicional removido!" });
  };

  const handleToggleAvailability = (additionalId) => {
    dispatch({ type: 'TOGGLE_GLOBAL_ADDITIONAL_AVAILABILITY', payload: additionalId });
    const additional = additionals.find(add => add.id === additionalId);
    toast({
      title: `Adicional ${additional?.available ? 'desativado' : 'ativado'}!`,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Adicionais Globais</h2>
          <p className="text-gray-600">Crie itens adicionais que podem ser vinculados aos produtos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingAdditional(null)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" /> Novo Adicional
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editingAdditional ? 'Editar' : 'Novo'} Adicional Global</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nome do Adicional *</label>
                <Input value={formData.name} onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Preço Padrão (R$) *</label>
                <Input type="number" step="0.01" value={formData.price} onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Disponibilidade</label>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setFormData(prev => ({...prev, available: !prev.available}))}
                  className="w-full flex justify-between items-center"
                >
                  {formData.available ? "Disponível" : "Indisponível"}
                  {formData.available ? <ToggleRight className="h-5 w-5 text-green-500" /> : <ToggleLeft className="h-5 w-5 text-red-500" />}
                </Button>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">Salvar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {additionals.map((additional) => (
          <Card key={additional.id} className={`${!additional.available ? 'opacity-60 border-red-300' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <CookingPot className="h-5 w-5 text-purple-600" />
                  <h3 className="font-semibold">{additional.name}</h3>
                </div>
                <span className="text-lg font-bold text-purple-600">R$ {additional.price.toFixed(2)}</span>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={() => handleEdit(additional)} className="flex-1">
                  <Edit className="h-4 w-4 mr-1" /> Editar
                </Button>
                 <Button 
                    variant={additional.available ? "outline" : "default"} 
                    size="sm" 
                    onClick={() => handleToggleAvailability(additional.id)} 
                    className={`flex-1 ${additional.available ? 'border-yellow-500 text-yellow-700 hover:bg-yellow-50' : 'bg-green-500 hover:bg-green-600'}`}
                >
                    {additional.available ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
                    {additional.available ? 'Desativar' : 'Ativar'}
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(additional.id)} className="flex-1">
                  <Trash2 className="h-4 w-4 mr-1" /> Excluir
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {additionals.length === 0 && (
         <Card className="p-12 text-center text-gray-500">
            <CookingPot className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Nenhum adicional global cadastrado</h3>
        </Card>
      )}
    </motion.div>
  );
}