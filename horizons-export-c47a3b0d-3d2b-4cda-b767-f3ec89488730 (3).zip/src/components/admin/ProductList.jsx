import React from 'react';
import { motion } from 'framer-motion';
import { Edit, Trash2, Package, Eye, EyeOff, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function ProductList({ products, onEdit, onDelete, onToggleAvailability, onReorder }) {
  if (!products || products.length === 0) {
    return (
      <Card className="p-12 text-center">
        <div className="text-gray-500">
          <Package className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <h3 className="text-lg font-medium mb-2">Nenhum produto cadastrado</h3>
          <p className="text-sm">Comece adicionando seu primeiro produto ao cardápio.</p>
        </div>
      </Card>
    );
  }
  
  const sortedProducts = [...products].sort((a,b) => (a.order || 0) - (b.order || 0));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sortedProducts.map((product, index) => (
        <motion.div
          key={product.id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Card className={`overflow-hidden ${!product.available ? 'opacity-70 border-red-300' : ''}`}>
            <div className="relative">
              {product.image ? (
                <div className="h-48 overflow-hidden">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="h-48 bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                  <span className="text-white text-lg font-medium">Sem imagem</span>
                </div>
              )}
              {!product.available && (
                <div className="absolute inset-0 bg-red-500/50 flex items-center justify-center">
                  <Badge variant="destructive" className="text-sm px-3 py-1">Indisponível</Badge>
                </div>
              )}
            </div>
            
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-lg">{product.name}</h3>
                <Badge variant="secondary">{product.category}</Badge>
              </div>
              
              <p className="text-gray-600 text-sm mb-3 h-10 overflow-hidden text-ellipsis">{product.description}</p>
              
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg font-bold text-purple-600">R$ {product.price.toFixed(2)}</span>
                {product.additionals && product.additionals.length > 0 && (
                  <span className="text-xs text-gray-500">{product.additionals.length} adicionais</span>
                )}
              </div>

              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-gray-500">Ordem: {product.order || 0}</span>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="sm" onClick={() => onReorder(product.id, product.category, 'up')} disabled={index === 0}><ChevronUp className="h-4 w-4"/></Button>
                  <Button variant="ghost" size="sm" onClick={() => onReorder(product.id, product.category, 'down')} disabled={index === sortedProducts.length -1}><ChevronDown className="h-4 w-4"/></Button>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={() => onEdit(product)} className="flex-1">
                  <Edit className="h-4 w-4 mr-1" /> Editar
                </Button>
                <Button 
                    variant={product.available ? "outline" : "default"} 
                    size="sm" 
                    onClick={() => onToggleAvailability(product.id, product.category)} 
                    className={`flex-1 ${product.available ? 'border-yellow-500 text-yellow-700 hover:bg-yellow-50' : 'bg-green-500 hover:bg-green-600'}`}
                >
                    {product.available ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
                    {product.available ? 'Desativar' : 'Ativar'}
                </Button>
                <Button variant="destructive" size="sm" onClick={() => onDelete(product.id, product.category)} className="flex-1">
                  <Trash2 className="h-4 w-4 mr-1" /> Excluir
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}