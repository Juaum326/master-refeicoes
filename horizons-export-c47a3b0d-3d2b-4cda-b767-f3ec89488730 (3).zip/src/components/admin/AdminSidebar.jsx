import React from 'react';
import { motion } from 'framer-motion';
import { LogOut, LayoutGrid, ShoppingCart, ChevronDown, ChevronUp, Tag, BarChart2, Lightbulb, Brain, WifiOff, Wifi, Archive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BackToCustomerViewButton } from '@/components/BackToCustomerViewButton';
import { useApp } from '@/contexts/AppContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

export function AdminSidebar({ menuItems, activeTab, onMenuClick, isSalesSectionOpen, onSalesPanelToggle, activeSalesSubTab, onSalesSubMenuClick, companyName, openStatus }) {
  const { state, dispatch } = useApp();
  const { settings } = state.settingsState;
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT_ADMIN' });
    navigate('/login/admin');
  };

  const toggleWhatsAppIntegration = () => {
    dispatch({ type: 'TOGGLE_WHATSAPP_INTEGRATION' });
    toast({ title: `Integração WhatsApp ${settings.whatsappIntegrationEnabled ? 'Desativada' : 'Ativada'}` });
  };

  const salesMenuItems = [
    { value: "orders", label: "Pedidos Ativos", icon: ShoppingCart },
    { value: "history", label: "Histórico", icon: Archive },
    { value: "analytics", label: "Gráficos", icon: BarChart2 },
    { value: "booster", label: "Impulsionador 🚀", icon: Lightbulb },
    { value: "manager", label: "Gestor Inteligente 🤖", icon: Brain },
    { value: "coupons", label: "Cupons", icon: Tag },
  ];

  return (
    <aside className="w-full md:w-72 bg-gradient-to-br from-purple-700 to-indigo-800 text-white p-4 space-y-4 md:space-y-6 shadow-lg md:min-h-screen flex flex-col">
      <div>
        <div className="text-center mb-4 md:mb-8">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <LayoutGrid className="h-8 w-8" />
            <h1 className="text-2xl font-bold">Admin</h1>
          </div>
          <p className="text-xs text-purple-200">{companyName}</p>
        </div>
        <nav className="space-y-1">
          {menuItems.map(item => {
            const Icon = item.icon;
            return (
              <Button
                key={item.value}
                variant={(activeTab === item.value && !isSalesSectionOpen) ? "secondary" : "ghost"}
                className={`w-full justify-start text-left h-12 text-base 
                            ${(activeTab === item.value && !isSalesSectionOpen)
                              ? 'bg-white/20 text-white' 
                              : 'text-purple-200 hover:bg-white/10 hover:text-white'
                            }`}
                onClick={() => onMenuClick(item.value)}
              >
                <Icon className="h-5 w-5 mr-3" />{item.label}
              </Button>
            );
          })}

          <Button
            variant={isSalesSectionOpen ? "secondary" : "ghost"}
            className={`w-full justify-between items-center text-left h-12 text-base 
                        ${isSalesSectionOpen
                          ? 'bg-white/20 text-white' 
                          : 'text-purple-200 hover:bg-white/10 hover:text-white'
                        }`}
            onClick={onSalesPanelToggle}
          >
            <span className="flex items-center"><ShoppingCart className="h-5 w-5 mr-3" /> Painel de Vendas</span>
            {isSalesSectionOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </Button>
          {isSalesSectionOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="pl-4 space-y-1 mt-1 border-l-2 border-purple-500/50 ml-3"
            >
              {salesMenuItems.map(item => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.value}
                    variant={activeSalesSubTab === item.value ? "secondary" : "ghost"}
                    className={`w-full justify-start text-left h-10 text-sm
                                ${activeSalesSubTab === item.value 
                                  ? 'bg-white/15 text-white' 
                                  : 'text-purple-200 hover:bg-white/10 hover:text-white'
                                }`}
                    onClick={() => onSalesSubMenuClick(item.value)}
                  >
                    <Icon className="h-4 w-4 mr-2" />{item.label}
                  </Button>
                );
              })}
               <Button
                  variant="ghost"
                  className="w-full justify-start text-left h-10 text-sm text-purple-200 hover:bg-white/10 hover:text-white"
                  onClick={toggleWhatsAppIntegration}
                >
                  {settings.whatsappIntegrationEnabled ? <Wifi className="h-4 w-4 mr-2 text-green-300" /> : <WifiOff className="h-4 w-4 mr-2 text-red-300" />}
                  WhatsApp {settings.whatsappIntegrationEnabled ? 'Ativo' : 'Inativo'}
                </Button>
            </motion.div>
          )}
        </nav>
      </div>
      <div className="pt-4 mt-auto border-t border-purple-600 space-y-2">
        <BackToCustomerViewButton className="text-purple-200 border-purple-500 hover:bg-white/10 hover:text-white hover:border-purple-400" />
        <Button variant="ghost" className="w-full justify-start text-left h-12 text-base text-purple-200 hover:bg-white/10 hover:text-white" onClick={handleLogout}>
          <LogOut className="h-5 w-5 mr-3" />Sair
        </Button>
      </div>
       <div className="text-center mt-4 text-xs text-purple-300">
          <p>© {new Date().getFullYear()} Master Refeições</p>
          <div className="flex items-center justify-center space-x-1 mt-1">
              <span className={`text-xs font-semibold px-1.5 py-0.5 rounded-full ${openStatus.color === 'text-green-500' ? 'bg-green-200 text-green-700' : openStatus.color === 'text-red-500' ? 'bg-red-200 text-red-700' : 'bg-orange-200 text-orange-700'}`}>
                {openStatus.text}
              </span>
          </div>
      </div>
    </aside>
  );
}