import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { ProductForm } from './ProductForm';
import { ProductList } from './ProductList';

export function ProductManagement() {
  const { state, dispatch } = useApp();
  const { products, beverages, sides } = state.productState;
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  const allProducts = [...products, ...beverages, ...sides];

  const resetFormAndCloseDialog = () => {
    setEditingProduct(null);
    setIsDialogOpen(false);
  };

  const handleSubmit = (productData) => {
    const productPayload = { 
        ...productData, 
        category: productData.category, 
        ...(editingProduct && { oldCategory: editingProduct.category }) 
      };

    if (editingProduct) {
      dispatch({ 
        type: 'UPDATE_PRODUCT', 
        payload: { ...productPayload, id: editingProduct.id }
      });
      toast({
        title: "Produto atualizado!",
        description: "As alterações foram salvas com sucesso.",
      });
    } else {
      dispatch({ type: 'ADD_PRODUCT', payload: productPayload });
      toast({
        title: "Produto adicionado!",
        description: "Novo produto foi criado com sucesso.",
      });
    }
    resetFormAndCloseDialog();
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setIsDialogOpen(true);
  };

  const handleDelete = (productId, productCategory) => {
    dispatch({ type: 'DELETE_PRODUCT', payload: { productId, productCategory } });
    toast({
      title: "Produto removido!",
      description: "O produto foi excluído com sucesso.",
    });
  };

  const handleToggleAvailability = (productId, productCategory) => {
    dispatch({ type: 'TOGGLE_PRODUCT_AVAILABILITY', payload: { id: productId, category: productCategory } });
    const productList = productCategory === 'quentinhas' ? products : productCategory === 'bebidas' ? beverages : sides;
    const product = productList.find(p => p.id === productId);
    toast({
      title: `Produto ${product?.available ? 'desativado' : 'ativado'}!`,
      description: `O produto ${product?.name} foi ${product?.available ? 'desativado' : 'ativado'}.`,
    });
  };

  const handleReorder = (productId, productCategory, direction) => {
    const targetArrayName = productCategory === 'quentinhas' ? 'products' : 
                           productCategory === 'bebidas' ? 'beverages' : 'sides';
    
    const list = [...state.productState[targetArrayName]];
    const productIndex = list.findIndex(p => p.id === productId);

    if (productIndex === -1) return;

    const newIndex = direction === 'up' ? productIndex - 1 : productIndex + 1;

    if (newIndex < 0 || newIndex >= list.length) return;
    
    const tempOrder = list[productIndex].order;
    list[productIndex].order = list[newIndex].order;
    list[newIndex].order = tempOrder;
    
    const updatedProduct = { ...list[productIndex] };
    const swappedProduct = { ...list[newIndex] };

    list[productIndex] = swappedProduct; 
    list[newIndex] = updatedProduct; 

    dispatch({ type: 'UPDATE_PRODUCT', payload: { ...list[productIndex], oldCategory: productCategory, category: productCategory } });
    dispatch({ type: 'UPDATE_PRODUCT', payload: { ...list[newIndex], oldCategory: productCategory, category: productCategory } });

    toast({ title: "Ordem atualizada!", description: "A ordem dos produtos foi alterada."});
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Produtos</h2>
          <p className="text-gray-600">Adicione, edite ou remova produtos do cardápio</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingProduct(null)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" />
              Novo Produto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto custom-scrollbar">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Editar Produto' : 'Novo Produto'}
              </DialogTitle>
            </DialogHeader>
            <ProductForm 
              product={editingProduct}
              onSubmit={handleSubmit}
              onCancel={resetFormAndCloseDialog}
            />
          </DialogContent>
        </Dialog>
      </div>

      <ProductList
        products={allProducts}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onToggleAvailability={handleToggleAvailability}
        onReorder={handleReorder}
      />
    </motion.div>
  );
}