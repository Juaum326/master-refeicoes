import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings, Package, MapPin, BarChart3, ListOrdered, Utensils as CookingPot, 
  Brush, LayoutGrid, CalendarHeart
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';

import { AdminSidebar } from './AdminSidebar';
import { AdminOverview } from './AdminOverview';
import { ProductManagement } from './ProductManagement';
import { SettingsManagement } from './SettingsManagement';
import { DeliveryManagement } from './DeliveryManagement';
import { CategoryManagement } from './CategoryManagement';
import { AdditionalsManagement } from './AdditionalsManagement';
import { VisualEditor } from '@/components/admin/visual-editor/VisualEditor.jsx';
import { EventsManagement } from './EventsManagement.jsx';
import { SalesPanel } from './SalesPanel';


export function AdminDashboard() {
  const { state } = useApp();
  const { settings } = state.settingsState;
  
  const [activeTab, setActiveTab] = useState('overview');
  const [activeSalesSubTab, setActiveSalesSubTab] = useState('orders');
  const [isSalesSectionOpen, setIsSalesSectionOpen] = useState(false);

  const menuItems = [
    { value: "overview", label: "Visão Geral", icon: BarChart3 },
    { value: "products", label: "Produtos", icon: Package },
    { value: "categories", label: "Categorias", icon: ListOrdered },
    { value: "additionals", label: "Adicionais", icon: CookingPot },
    { value: "delivery", label: "Entrega", icon: MapPin },
    { value: "events", label: "Eventos 🎉", icon: CalendarHeart },
    { value: "visualEditor", label: "Editor Visual", icon: Brush },
    { value: "settings", label: "Configurações", icon: Settings },
  ];

  const handleMenuClick = (tab) => {
    setActiveTab(tab);
    setIsSalesSectionOpen(false);
  };

  const handleSalesPanelToggle = () => {
    setIsSalesSectionOpen(!isSalesSectionOpen);
    if (!isSalesSectionOpen) {
      setActiveTab('salesPanel'); 
      setActiveSalesSubTab('orders'); 
    } else if (activeTab === 'salesPanel') {
      setActiveTab('overview'); 
    }
  };
  
  const handleSalesSubMenuClick = (subTab) => {
    setActiveTab('salesPanel');
    setActiveSalesSubTab(subTab);
    if (!isSalesSectionOpen) setIsSalesSectionOpen(true);
  };

  const renderContent = () => {
    if (isSalesSectionOpen && activeTab === 'salesPanel') {
      return <SalesPanel activeSubTab={activeSalesSubTab} setActiveSubTab={setActiveSalesSubTab} />;
    }

    switch (activeTab) {
      case 'overview':
        return <AdminOverview />;
      case 'products':
        return <ProductManagement />;
      case 'categories':
        return <CategoryManagement />;
      case 'additionals':
        return <AdditionalsManagement />;
      case 'delivery':
        return <DeliveryManagement />;
      case 'events':
        return <EventsManagement />;
      case 'settings':
        return <SettingsManagement />;
      case 'visualEditor':
        return <VisualEditor />;
      default:
        return <AdminOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col md:flex-row">
      <AdminSidebar 
        menuItems={menuItems}
        activeTab={activeTab}
        onMenuClick={handleMenuClick}
        isSalesSectionOpen={isSalesSectionOpen}
        onSalesPanelToggle={handleSalesPanelToggle}
        activeSalesSubTab={activeSalesSubTab}
        onSalesSubMenuClick={handleSalesSubMenuClick}
        companyName={settings.companyName}
        openStatus={getOpenStatus(settings)}
      />
      <main className="flex-1 p-6 overflow-y-auto">
        <motion.div 
          key={isSalesSectionOpen ? `sales-${activeSalesSubTab}` : activeTab}
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.5 }} 
          className="space-y-6"
        >
          {renderContent()}
        </motion.div>
      </main>
    </div>
  );
}

function getOpenStatus(settings) {
  if (!settings || !settings.openingHours) {
    return { text: "Status Indisponível", color: "text-gray-500" };
  }
  if(settings.manualOpen !== null) {
      return settings.manualOpen ? 
          { text: "Aberto Manualmente", color: "text-green-500" } : 
          { text: "Fechado Manualmente", color: "text-red-500" };
  }
  const now = new Date();
  const dayOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][now.getDay()];
  const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const todayHours = settings.openingHours[dayOfWeek];

  if (!todayHours || !todayHours.enabled) return { text: "Fechado Hoje", color: "text-red-500" };
  if (currentTime >= todayHours.open && currentTime <= todayHours.close) return { text: `Aberto até ${todayHours.close}`, color: "text-green-500" };
  return { text: "Fechado Agora", color: "text-orange-500" };
}