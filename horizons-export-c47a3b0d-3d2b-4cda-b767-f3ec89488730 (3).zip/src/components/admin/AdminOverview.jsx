import React from 'react';
import { motion } from 'framer-motion';
import { Package, BarChart3, Utensils as CookingPot, Brush, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useApp } from '@/contexts/AppContext';

export function AdminOverview() {
  const { state } = useApp();
  const { products, beverages, sides, categories } = state.productState;
  const { settings } = state.settingsState;

  const totalProducts = products.length + beverages.length + sides.length;
  const totalRevenue = state.salesState.orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = state.salesState.orders.length;
  const avgOrderValue = totalOrdersCount > 0 ? totalRevenue / totalOrdersCount : 0;

  const stats = [
    { title: 'Total de Produtos', value: totalProducts, icon: Package, color: 'bg-blue-500' },
    { title: 'Pedidos Hoje (Todos)', value: totalOrdersCount, icon: BarChart3, color: 'bg-green-500' },
    { title: 'Receita (Entregues)', value: `R$ ${totalRevenue.toFixed(2)}`, icon: CookingPot, color: 'bg-purple-500' },
    { title: 'Ticket Médio (Entregues)', value: `R$ ${avgOrderValue.toFixed(2)}`, icon: Brush, color: 'bg-orange-500' }
  ];

  const daysOfWeekMap = { monday: "Seg", tuesday: "Ter", wednesday: "Qua", thursday: "Qui", friday: "Sex", saturday: "Sáb", sunday: "Dom" };
  
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Visão Geral</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div 
              key={stat.title} 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                      <p className="text-3xl font-bold text-gray-800">{stat.value}</p>
                    </div>
                    <div className={`p-3.5 rounded-full ${stat.color} shadow-md`}>
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 shadow-md">
          <CardHeader><CardTitle className="text-xl text-gray-700">Itens por Categoria</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {categories.map(cat => {
              let count = 0;
              if (cat.id === 'quentinhas') count = products.length;
              else if (cat.id === 'bebidas') count = beverages.length;
              else if (cat.id === 'acompanhamentos') count = sides.length;
              return (
                <div key={cat.id} className="flex justify-between items-center text-sm text-gray-600 py-1 border-b last:border-b-0">
                  <span>{cat.name}</span>
                  <span className="font-medium text-gray-800">{count} itens</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
        <Card className="lg:col-span-1 shadow-md">
          <CardHeader><CardTitle className="text-xl text-gray-700 flex items-center"><Clock className="h-5 w-5 mr-2 text-purple-600"/> Horários</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-sm text-gray-600">
            {Object.entries(settings.openingHours).map(([day, hours]) => (
              <div key={day} className={`flex justify-between py-1 border-b last:border-b-0 ${!hours.enabled ? 'text-gray-400 italic' : ''}`}>
                <span>{daysOfWeekMap[day]}:</span>
                <span className="font-medium text-gray-800">{hours.enabled ? `${hours.open} - ${hours.close}` : 'Fechado'}</span>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card className="lg:col-span-1 shadow-md">
          <CardHeader><CardTitle className="text-xl text-gray-700">Atividade Recente</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {[
              {text: "Novo pedido recebido", time: "2 min atrás", color: "bg-green-500"},
              {text: "Produto 'Quentinha Vegana' atualizado", time: "15 min atrás", color: "bg-blue-500"},
              {text: "Taxa de entrega do bairro 'Centro' alterada", time: "1 hora atrás", color: "bg-purple-500"}
            ].map((activity, i) => (
              <div key={i} className="flex items-center space-x-2 text-sm py-1 border-b last:border-b-0">
                <div className={`w-2.5 h-2.5 rounded-full ${activity.color}`}></div>
                <span className="text-gray-700">{activity.text}</span>
                <span className="text-xs text-gray-400 ml-auto whitespace-nowrap">{activity.time}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}