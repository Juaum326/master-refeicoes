import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart2, Calendar, TrendingUp, TrendingDown, DollarSign, ShoppingBag, Users } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend, TimeScale } from 'chart.js';
import 'chartjs-adapter-date-fns';
import { subDays, format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, eachDayOfInterval, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend, TimeScale);

const initialDate = new Date().toISOString().split('T')[0];

export function SalesAnalytics() {
  const { state } = useApp();
  const { orders } = state.salesState; 

  const [period1, setPeriod1] = useState({ type: 'month', date: initialDate });
  const [period2, setPeriod2] = useState({ type: 'month', date: initialDate });
  const [analyticsData, setAnalyticsData] = useState(null);

  const calculateDateRange = (periodType, dateStr) => {
    const date = parseISO(dateStr);
    switch (periodType) {
      case 'day': return { start: date, end: date };
      case 'week': return { start: startOfWeek(date, { locale: ptBR }), end: endOfWeek(date, { locale: ptBR }) };
      case 'month': return { start: startOfMonth(date), end: endOfMonth(date) };
      case 'year': return { start: startOfYear(date), end: endOfYear(date) };
      default: return { start: date, end: date };
    }
  };

  const processOrdersForPeriod = (range) => {
    const filteredOrders = orders.filter(order => {
      const orderDate = parseISO(order.createdAt);
      return orderDate >= range.start && orderDate <= range.end && order.status === 'delivered';
    });

    const dailyData = {};
    eachDayOfInterval(range).forEach(day => {
      dailyData[format(day, 'yyyy-MM-dd')] = { revenue: 0, count: 0, items: {} };
    });

    filteredOrders.forEach(order => {
      const dayStr = format(parseISO(order.createdAt), 'yyyy-MM-dd');
      if (dailyData[dayStr]) {
        dailyData[dayStr].revenue += order.total;
        dailyData[dayStr].count += 1;
        order.items.forEach(item => {
          dailyData[dayStr].items[item.name] = (dailyData[dayStr].items[item.name] || 0) + item.quantity;
        });
      }
    });
    
    const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
    const totalOrdersCount = filteredOrders.length;
    const ticketMedium = totalOrdersCount > 0 ? totalRevenue / totalOrdersCount : 0;

    let productSales = {};
    filteredOrders.forEach(order => {
        order.items.forEach(item => {
            productSales[item.name] = (productSales[item.name] || 0) + item.quantity;
        });
    });
    const mostSoldProduct = Object.entries(productSales).sort(([,a],[,b]) => b-a)[0] || ['N/A', 0];

    let salesByDayOfWeek = { 'Dom': 0, 'Seg': 0, 'Ter': 0, 'Qua': 0, 'Qui': 0, 'Sex': 0, 'Sáb': 0 };
    const dayMap = { 0: 'Dom', 1: 'Seg', 2: 'Ter', 3: 'Qua', 4: 'Qui', 5: 'Sex', 6: 'Sáb' };
    filteredOrders.forEach(order => {
        const dayIndex = parseISO(order.createdAt).getDay();
        salesByDayOfWeek[dayMap[dayIndex]] += order.total;
    });
     const bestDayOfWeek = Object.entries(salesByDayOfWeek).sort(([,a],[,b]) => b-a)[0] || ['N/A', 0];


    return {
      totalRevenue,
      totalOrdersCount,
      ticketMedium,
      mostSoldProduct: { name: mostSoldProduct[0], count: mostSoldProduct[1] },
      bestDayOfWeek: { name: bestDayOfWeek[0], revenue: bestDayOfWeek[1] },
      dailyData: Object.entries(dailyData).map(([date, data]) => ({date, ...data})).sort((a,b) => new Date(a.date) - new Date(b.date)),
      salesByDayOfWeek: salesByDayOfWeek
    };
  };
  
  const handleCompare = () => {
    const range1 = calculateDateRange(period1.type, period1.date);
    const range2 = calculateDateRange(period2.type, period2.date);
    
    const data1 = processOrdersForPeriod(range1);
    const data2 = processOrdersForPeriod(range2);

    setAnalyticsData({ period1: data1, period2: data2 });
  };

  useEffect(() => {
    handleCompare(); 
  }, []);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: 'top' }, title: { display: true, text: 'Comparativo de Receita' } },
    scales: { x: { type: 'time', time: { unit: 'day', tooltipFormat: 'dd/MM/yy', displayFormats: { day: 'dd/MM' } }, title: { display: true, text: 'Data'} }, y: { title: {display: true, text: 'Receita (R$)'}}}
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: 'top' }, title: { display: true, text: 'Performance Dia da Semana (Receita)' } },
    scales: { y: { title: {display: true, text: 'Receita (R$)'}}}
  };

  const lineChartData = analyticsData ? {
    labels: analyticsData.period1.dailyData.map(d => d.date), 
    datasets: [
      { label: `Período 1 Receita`, data: analyticsData.period1.dailyData.map(d => d.revenue), borderColor: 'rgb(75, 192, 192)', backgroundColor: 'rgba(75, 192, 192, 0.5)', tension: 0.1 },
      ...(analyticsData.period2.dailyData.length === analyticsData.period1.dailyData.length || period1.type !== 'day' ? 
        [{ label: `Período 2 Receita`, data: analyticsData.period2.dailyData.map(d => d.revenue), borderColor: 'rgb(255, 99, 132)', backgroundColor: 'rgba(255, 99, 132, 0.5)', tension: 0.1 }] 
        : [] 
      )
    ]
  } : { labels: [], datasets: []};
  
  const dayOfWeekChartData = analyticsData ? {
    labels: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
    datasets: [
        { label: 'Período 1', data: Object.values(analyticsData.period1.salesByDayOfWeek), backgroundColor: 'rgba(75, 192, 192, 0.7)' },
        { label: 'Período 2', data: Object.values(analyticsData.period2.salesByDayOfWeek), backgroundColor: 'rgba(255, 99, 132, 0.7)' },
    ]
  } : { labels: [], datasets: []};


  const renderStatCard = (title, value, comparisonValue, icon, unit = '', positiveIsGood = true) => {
    const Icon = icon;
    let diff = 0;
    let trendIcon = null;
    let diffColor = 'text-gray-500';

    if (comparisonValue !== undefined && comparisonValue !== 0) {
      diff = ((value - comparisonValue) / comparisonValue) * 100;
      if (diff > 0) {
        trendIcon = <TrendingUp className={`h-5 w-5 ${positiveIsGood ? 'text-green-500' : 'text-red-500'}`}/>;
        diffColor = positiveIsGood ? 'text-green-600' : 'text-red-600';
      } else if (diff < 0) {
        trendIcon = <TrendingDown className={`h-5 w-5 ${positiveIsGood ? 'text-red-500' : 'text-green-500'}`}/>;
        diffColor = positiveIsGood ? 'text-red-600' : 'text-green-600';
      }
    } else if (comparisonValue === 0 && value > 0) {
        diff = Infinity; 
        trendIcon = <TrendingUp className={`h-5 w-5 ${positiveIsGood ? 'text-green-500' : 'text-red-500'}`}/>;
        diffColor = positiveIsGood ? 'text-green-600' : 'text-red-600';
    }


    return (
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
          <Icon className="h-5 w-5 text-purple-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-gray-800">{unit}{typeof value === 'number' ? value.toFixed(2) : value}</div>
          {comparisonValue !== undefined && (
            <p className={`text-xs ${diffColor} flex items-center`}>
              {trendIcon}
              <span className="ml-1">
                {diff === Infinity ? '+∞' : diff.toFixed(1)}%
              </span>
              &nbsp;vs Período 2 ({unit}{typeof comparisonValue === 'number' ? comparisonValue.toFixed(2) : comparisonValue})
            </p>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-xl text-gray-700"><BarChart2 className="mr-2 h-6 w-6 text-purple-600"/>Análise Comparativa de Vendas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end p-4 border rounded-lg bg-gray-50">
            {[period1, period2].map((p, index) => (
              <div key={index} className="space-y-2 p-3 border rounded-md bg-white shadow-sm">
                <Label htmlFor={`periodType${index+1}`} className="font-semibold text-gray-700">Período {index + 1}</Label>
                <div className="flex space-x-2">
                  <Select 
                    id={`periodType${index+1}`}
                    value={p.type} 
                    onValueChange={(val) => (index === 0 ? setPeriod1(prev => ({...prev, type: val})) : setPeriod2(prev => ({...prev, type: val})))}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">Dia</SelectItem>
                      <SelectItem value="week">Semana</SelectItem>
                      <SelectItem value="month">Mês</SelectItem>
                      <SelectItem value="year">Ano</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input 
                    type="date" 
                    value={p.date} 
                    onChange={(e) => (index === 0 ? setPeriod1(prev => ({...prev, date: e.target.value})) : setPeriod2(prev => ({...prev, date: e.target.value})))} 
                  />
                </div>
              </div>
            ))}
            <Button onClick={handleCompare} className="md:self-end h-10 bg-purple-600 hover:bg-purple-700 text-base"><Calendar className="mr-2 h-5 w-5"/> Comparar</Button>
          </div>

          {analyticsData && (
            <div className="space-y-6 mt-6">
              <h3 className="text-lg font-semibold text-gray-700 mb-2 border-b pb-2">Resultados da Comparação:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {renderStatCard("Receita Total", analyticsData.period1.totalRevenue, analyticsData.period2.totalRevenue, DollarSign, "R$ ")}
                {renderStatCard("Ticket Médio", analyticsData.period1.ticketMedium, analyticsData.period2.ticketMedium, DollarSign, "R$ ")}
                {renderStatCard("Total de Pedidos", analyticsData.period1.totalOrdersCount, analyticsData.period2.totalOrdersCount, ShoppingBag, "")}
                {renderStatCard("Produto Mais Vendido", `${analyticsData.period1.mostSoldProduct.name} (${analyticsData.period1.mostSoldProduct.count})`, `${analyticsData.period2.mostSoldProduct.name} (${analyticsData.period2.mostSoldProduct.count})`, Users, "", false)}
                {renderStatCard("Melhor Dia (Receita)", `${analyticsData.period1.bestDayOfWeek.name} (R$${analyticsData.period1.bestDayOfWeek.revenue.toFixed(2)})`, `${analyticsData.period2.bestDayOfWeek.name} (R$${analyticsData.period2.bestDayOfWeek.revenue.toFixed(2)})`, TrendingUp, "", false)}
              </div>
              
              <Card className="shadow-lg">
                <CardHeader><CardTitle className="text-base text-gray-700">Comparativo de Receita Diária</CardTitle></CardHeader>
                <CardContent className="h-72 md:h-96"><Line options={chartOptions} data={lineChartData} /></CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader><CardTitle className="text-base text-gray-700">Performance por Dia da Semana (Receita)</CardTitle></CardHeader>
                <CardContent className="h-72 md:h-96"><Bar options={barChartOptions} data={dayOfWeekChartData} /></CardContent>
              </Card>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}