import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Brain, TrendingUp, TrendingDown, Package, DollarSign, CalendarDays, Zap, AlertTriangle } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { subDays, parseISO, format } from 'date-fns';
import { toast } from '@/components/ui/use-toast';

export function IntelligentManager() {
  const { state, dispatch } = useApp();
  const { orders } = state.salesState;
  const { products, beverages, sides } = state.productState;
  const allItems = [...products, ...beverages, ...sides];
  const { settings } = state.settingsState;

  const [analysis, setAnalysis] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const performAnalysis = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      if (orders.length < 10) {
        setAnalysis({
          summary: "Dados insuficientes para uma análise profunda.",
          suggestions: [
            { title: "Continue Vendendo!", text: "Precisamos de mais dados de pedidos para fornecer insights valiosos.", icon: TrendingUp, type: 'info' }
          ]
        });
        setIsLoading(false);
        return;
      }

      const last30DaysOrders = orders.filter(order => {
        const orderDate = parseISO(order.createdAt);
        return orderDate >= subDays(new Date(), 30) && order.status === 'delivered';
      });

      let productPerformance = {};
      allItems.forEach(item => {
        productPerformance[item.name] = { sales: 0, revenue: 0, price: item.price, category: item.category, available: item.available };
      });

      last30DaysOrders.forEach(order => {
        order.items.forEach(item => {
          if (productPerformance[item.name]) {
            productPerformance[item.name].sales += item.quantity;
            productPerformance[item.name].revenue += item.price * item.quantity;
          }
        });
      });

      const sortedBySales = Object.entries(productPerformance).sort(([,a],[,b]) => b.sales - a.sales);
      const sortedByRevenue = Object.entries(productPerformance).sort(([,a],[,b]) => b.revenue - a.revenue);
      
      const lowPerformingItems = sortedBySales.filter(([,data]) => data.sales < 5 && data.available).slice(0,3);
      const highPerformingItems = sortedBySales.filter(([,data]) => data.sales > 0).slice(0,3);

      let suggestions = [];

      if (lowPerformingItems.length > 0) {
        lowPerformingItems.forEach(item => {
          suggestions.push({
            title: `Oportunidade: ${item[0]}`,
            text: `Este item teve ${item[1].sales} vendas. Considere uma promoção, combo ou revisar o preço (R$ ${item[1].price.toFixed(2)}).`,
            icon: Package,
            type: 'opportunity'
          });
        });
      }

      if (highPerformingItems.length > 1) {
        const top1 = highPerformingItems[0];
        const top2 = highPerformingItems[1];
        if (top1[1].category !== top2[1].category) {
           suggestions.push({
            title: `Combo Sugerido: ${top1[0]} + ${top2[0]}`,
            text: `Combine seus campeões de vendas de categorias diferentes para aumentar o ticket médio.`,
            icon: Zap,
            type: 'combo'
          });
        }
      }
      
      const avgPriceQuentinhas = productPerformance['Quentinha Tradicional']?.price || 15;
      const expensiveItems = sortedBySales.filter(([,data]) => data.price > avgPriceQuentinhas * 1.5 && data.sales < 5 && data.category === 'quentinhas');
      if (expensiveItems.length > 0) {
         suggestions.push({
            title: `Revisão de Preço: ${expensiveItems[0][0]}`,
            text: `O item ${expensiveItems[0][0]} (R$ ${expensiveItems[0][1].price.toFixed(2)}) está acima da média de preço e com poucas vendas. Avalie um ajuste.`,
            icon: DollarSign,
            type: 'pricing'
          });
      }

      const today = new Date();
      const activeEvents = settings.events.filter(event => {
          const startDate = parseISO(event.startDate);
          const endDate = parseISO(event.endDate);
          return event.active && today >= startDate && today <= endDate;
      }).sort((a,b) => b.priority - a.priority);

      if (activeEvents.length > 0) {
          const currentEvent = activeEvents[0];
           suggestions.push({
              title: `Aproveite o Evento: ${currentEvent.name}!`,
              text: `Com o evento "${currentEvent.name}" ativo, crie um produto temático ou uma oferta especial para impulsionar as vendas.`,
              icon: CalendarDays,
              type: 'event'
          });
      }


      setAnalysis({
        summary: `Análise baseada em ${last30DaysOrders.length} pedidos dos últimos 30 dias.`,
        suggestions: suggestions.length > 0 ? suggestions : [{ title: "Tudo Certo!", text: "Nenhuma sugestão crítica no momento. Continue o bom trabalho!", icon: TrendingUp, type: 'info' }]
      });
      setIsLoading(false);
      if (settings.notificationPreferences.allEnabled && settings.notificationPreferences.intelligentManager) {
        toast({ title: "🤖 Nova Análise Inteligente!", description: "Confira as sugestões do Gestor Inteligente." });
      }
    }, 1500); 
  };

  useEffect(() => {
    performAnalysis();
  }, []);

  const getSuggestionCardStyle = (type) => {
    switch(type) {
      case 'opportunity': return 'border-blue-500 bg-blue-50';
      case 'combo': return 'border-green-500 bg-green-50';
      case 'pricing': return 'border-yellow-500 bg-yellow-50';
      case 'event': return 'border-purple-500 bg-purple-50';
      default: return 'border-gray-300 bg-gray-50';
    }
  };
  
  const getSuggestionIconColor = (type) => {
     switch(type) {
      case 'opportunity': return 'text-blue-600';
      case 'combo': return 'text-green-600';
      case 'pricing': return 'text-yellow-600';
      case 'event': return 'text-purple-600';
      default: return 'text-gray-600';
    }
  }


  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-xl text-gray-700">
            <Brain className="mr-2 h-6 w-6 text-purple-600" />
            Gestor Inteligente (Beta IA 🧠)
          </CardTitle>
          <p className="text-sm text-gray-500">Análises e sugestões estratégicas para o seu negócio.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={performAnalysis} disabled={isLoading} className="bg-purple-600 hover:bg-purple-700">
            {isLoading ? 'Analisando...' : 'Realizar Nova Análise Estratégica'}
          </Button>

          {analysis && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600 italic">{analysis.summary}</p>
              {analysis.suggestions.map((suggestion, index) => {
                const Icon = suggestion.icon || AlertTriangle;
                return (
                  <Card key={index} className={`shadow-md ${getSuggestionCardStyle(suggestion.type)}`}>
                    <CardHeader className="pb-2">
                      <CardTitle className={`text-base flex items-center ${getSuggestionIconColor(suggestion.type)}`}>
                        <Icon className="h-5 w-5 mr-2"/>
                        {suggestion.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p className="text-gray-700">{suggestion.text}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}