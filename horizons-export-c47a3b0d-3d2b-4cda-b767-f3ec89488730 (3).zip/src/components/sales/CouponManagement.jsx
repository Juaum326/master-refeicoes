import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Tag, Percent, DollarSign, CalendarDays, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function CouponManagement() {
  const { state, dispatch } = useApp();
  const { coupons } = state.salesState;
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'percentage',
    value: '',
    limit: '',
    singleUsePerCustomer: true,
    validUntil: '',
    minValue: '',
    active: true,
  });

  useEffect(() => {
    if (editingCoupon) {
      setFormData({
        name: editingCoupon.name,
        type: editingCoupon.type,
        value: editingCoupon.value.toString(),
        limit: editingCoupon.limit.toString(),
        singleUsePerCustomer: editingCoupon.singleUsePerCustomer,
        validUntil: editingCoupon.validUntil,
        minValue: editingCoupon.minValue ? editingCoupon.minValue.toString() : '',
        active: editingCoupon.active,
      });
    } else {
      resetForm();
    }
  }, [editingCoupon]);

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'percentage',
      value: '',
      limit: '',
      singleUsePerCustomer: true,
      validUntil: '',
      minValue: '',
      active: true,
    });
    setEditingCoupon(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.value || !formData.limit || !formData.validUntil) {
      toast({ title: "Campos obrigatórios", description: "Nome, valor, limite de uso e data de validade são obrigatórios.", variant: "destructive" });
      return;
    }

    const couponData = {
      ...formData,
      name: formData.name.trim().toUpperCase(),
      value: parseFloat(formData.value),
      limit: parseInt(formData.limit, 10),
      minValue: formData.minValue ? parseFloat(formData.minValue) : 0,
    };

    if (editingCoupon) {
      dispatch({ type: 'UPDATE_COUPON', payload: { ...couponData, id: editingCoupon.id } });
      toast({ title: "Cupom atualizado!" });
    } else {
      if (coupons.some(c => c.name.toUpperCase() === couponData.name)) {
        toast({ title: "Nome de cupom já existe", variant: "destructive" });
        return;
      }
      dispatch({ type: 'ADD_COUPON', payload: couponData });
      toast({ title: "Cupom adicionado!" });
    }
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (coupon) => {
    setEditingCoupon(coupon);
    setIsDialogOpen(true);
  };

  const handleDelete = (couponId) => {
    dispatch({ type: 'DELETE_COUPON', payload: couponId });
    toast({ title: "Cupom removido!" });
  };

  const handleToggleActive = (coupon) => {
    dispatch({ type: 'UPDATE_COUPON', payload: { ...coupon, active: !coupon.active } });
    toast({ title: `Cupom ${!coupon.active ? 'ativado' : 'desativado'}!` });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Cupons de Desconto</h2>
          <p className="text-gray-600">Crie e gerencie cupons para seus clientes</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCoupon(null)} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" /> Novo Cupom
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editingCoupon ? 'Editar' : 'Novo'} Cupom</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
              <div>
                <Label htmlFor="couponName">Nome do Cupom (Ex: PRIMEIRA10) *</Label>
                <Input id="couponName" value={formData.name} onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value.toUpperCase() }))} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="couponType">Tipo *</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger id="couponType"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Porcentagem (%)</SelectItem>
                      <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="couponValue">Valor *</Label>
                  <Input id="couponValue" type="number" step="0.01" value={formData.value} onChange={(e) => setFormData(prev => ({ ...prev, value: e.target.value }))} required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="couponLimit">Limite de Uso Total *</Label>
                  <Input id="couponLimit" type="number" value={formData.limit} onChange={(e) => setFormData(prev => ({ ...prev, limit: e.target.value }))} required />
                </div>
                <div>
                  <Label htmlFor="couponValidUntil">Válido Até *</Label>
                  <Input id="couponValidUntil" type="date" value={formData.validUntil} onChange={(e) => setFormData(prev => ({ ...prev, validUntil: e.target.value }))} required />
                </div>
              </div>
              <div>
                <Label htmlFor="couponMinValue">Valor Mínimo do Pedido (Opcional)</Label>
                <Input id="couponMinValue" type="number" step="0.01" value={formData.minValue} onChange={(e) => setFormData(prev => ({ ...prev, minValue: e.target.value }))} placeholder="Deixe em branco se não houver" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="singleUse" checked={formData.singleUsePerCustomer} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, singleUsePerCustomer: checked }))} />
                <Label htmlFor="singleUse">Uso único por cliente</Label>
              </div>
               <div className="flex items-center space-x-2">
                <Switch id="couponActive" checked={formData.active} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, active: checked }))} />
                <Label htmlFor="couponActive">Ativo</Label>
              </div>
            </form>
            <DialogFooter>
              <DialogClose asChild><Button type="button" variant="outline">Cancelar</Button></DialogClose>
              <Button type="submit" onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">Salvar Cupom</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map((coupon) => (
          <Card key={coupon.id} className={`${!coupon.active ? 'opacity-60 border-red-300' : ''}`}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg flex items-center">
                  <Tag className="h-5 w-5 mr-2 text-green-600" /> {coupon.name}
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleToggleActive(coupon)}>
                  {coupon.active ? <CheckCircle className="h-5 w-5 text-green-500" /> : <XCircle className="h-5 w-5 text-red-500" />}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="text-sm space-y-1">
              <p><strong>Tipo:</strong> {coupon.type === 'percentage' ? <Percent className="inline h-4 w-4 mr-1"/> : <DollarSign className="inline h-4 w-4 mr-1"/>} {coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`}</p>
              <p><strong>Uso:</strong> {coupon.usedCount} / {coupon.limit}</p>
              <p><strong>Válido até:</strong> {new Date(coupon.validUntil + 'T00:00:00').toLocaleDateString()}</p>
              {coupon.minValue > 0 && <p><strong>Mínimo:</strong> R$ {coupon.minValue.toFixed(2)}</p>}
              <p><strong>Uso único/cliente:</strong> {coupon.singleUsePerCustomer ? 'Sim' : 'Não'}</p>
              <div className="flex space-x-2 pt-2 border-t mt-2">
                <Button variant="outline" size="sm" onClick={() => handleEdit(coupon)} className="flex-1">
                  <Edit className="h-4 w-4 mr-1" /> Editar
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(coupon.id)} className="flex-1">
                  <Trash2 className="h-4 w-4 mr-1" /> Excluir
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {coupons.length === 0 && (
         <Card className="p-12 text-center text-gray-500">
            <Tag className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Nenhum cupom cadastrado</h3>
        </Card>
      )}
    </motion.div>
  );
}