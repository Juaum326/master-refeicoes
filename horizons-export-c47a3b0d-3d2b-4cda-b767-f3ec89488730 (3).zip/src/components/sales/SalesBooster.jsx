import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, TrendingUp, TrendingDown, AlertTriangle, ShoppingBag, Percent, Gift, Tag } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { subDays, format, parseISO, getDay } from 'date-fns';

export function SalesBooster() {
  const { state } = useApp();
  const { orders } = state.salesState; 
  const { products, beverages, sides } = state.productState;
  const allItems = [...products, ...beverages, ...sides];

  const [insights, setInsights] = useState([]);

  useEffect(() => {
    generateInsights();
  }, [orders, products, beverages, sides]);

  const generateInsights = () => {
    if (orders.length === 0) {
      setInsights([{ type: 'info', message: "Ainda não há dados de vendas suficientes para gerar insights." }]);
      return;
    }

    const last30DaysOrders = orders.filter(order => {
      const orderDate = parseISO(order.createdAt);
      return orderDate >= subDays(new Date(), 30) && order.status === 'delivered';
    });

    if (last30DaysOrders.length < 5) {
      setInsights([{ type: 'info', message: "Poucos pedidos nos últimos 30 dias. Continue vendendo para obter insights!" }]);
      return;
    }

    let productSalesCount = {};
    let productRevenue = {};
    last30DaysOrders.forEach(order => {
      order.items.forEach(item => {
        productSalesCount[item.name] = (productSalesCount[item.name] || 0) + item.quantity;
        productRevenue[item.name] = (productRevenue[item.name] || 0) + (item.price * item.quantity);
      });
    });

    const sortedBySales = Object.entries(productSalesCount).sort(([,a],[,b]) => b-a);
    const sortedByRevenue = Object.entries(productRevenue).sort(([,a],[,b]) => b-a);
    
    const topSelling = sortedBySales.slice(0, 3);
    const leastSellingAvailable = allItems
      .filter(item => item.available && !productSalesCount[item.name]) // available but not sold
      .slice(0,3);

    const newInsights = [];

    if (topSelling.length > 0) {
      const topProduct = topSelling[0];
      newInsights.push({
        type: 'highlight',
        icon: TrendingUp,
        title: `🔥 Produto Campeão: ${topProduct[0]}`,
        message: `Vendeu ${topProduct[1]} unidades nos últimos 30 dias.`,
        suggestion: `Considere criar um combo com ${topProduct[0]} ou destacá-lo no cardápio.`
      });
    }
    
    if (topSelling.length > 1) {
        const secondTop = topSelling[1];
        const topOriginal = allItems.find(p => p.name === topSelling[0][0]);
        const secondOriginal = allItems.find(p => p.name === secondTop[0]);

        if (topOriginal && secondOriginal && topOriginal.category !== secondOriginal.category) {
             newInsights.push({
                type: 'combo',
                icon: ShoppingBag,
                title: `💡 Combo Estratégico: ${topSelling[0][0]} + ${secondTop[0]}`,
                message: `Estes são seus dois produtos mais populares de categorias diferentes.`,
                suggestion: `Crie um combo promocional com ${topSelling[0][0]} e ${secondTop[0]} por um preço especial.`
            });
        }
    }


    if (leastSellingAvailable.length > 0) {
      const slowProduct = leastSellingAvailable[0];
      newInsights.push({
        type: 'warning',
        icon: TrendingDown,
        title: `🧊 Produto Encalhado: ${slowProduct.name}`,
        message: `Não teve vendas nos últimos 30 dias, mas está disponível.`,
        suggestion: `Ofereça ${slowProduct.name} como brinde em pedidos acima de R$50 ou crie uma promoção de "leve 2 pague 1".`
      });
    }
    
    const weekendOrders = last30DaysOrders.filter(o => [0,6].includes(getDay(parseISO(o.createdAt)))).length; // Dom, Sab
    const weekdayOrders = last30DaysOrders.length - weekendOrders;

    if (weekendOrders > weekdayOrders * 1.2) { // 20% more orders on weekends
        newInsights.push({
            type: 'timing',
            icon: Gift,
            title: `🚀 Fim de Semana Bombando!`,
            message: `Você tem significativamente mais pedidos nos finais de semana.`,
            suggestion: `Crie promoções exclusivas para Sábado e Domingo ou ofereça itens especiais nesses dias.`
        });
    } else if (weekdayOrders > weekendOrders * 1.2) {
         newInsights.push({
            type: 'timing',
            icon: Percent,
            title: ` weekdayOrders > weekendOrders * 1.2`,
            message: `Seus dias de semana são mais movimentados.`,
            suggestion: `Considere "happy hour" com descontos ou combos executivos durante a semana.`
        });
    }


    const today = new Date();
    const activeEvents = state.settingsState.events.filter(event => {
        const startDate = parseISO(event.startDate);
        const endDate = parseISO(event.endDate);
        return event.active && today >= startDate && today <= endDate;
    }).sort((a,b) => b.priority - a.priority);

    if (activeEvents.length > 0) {
        const currentEvent = activeEvents[0];
         newInsights.push({
            type: 'event',
            icon: Tag,
            title: `🎉 Evento Ativo: ${currentEvent.name}!`,
            message: `${currentEvent.description}`,
            suggestion: `Crie um cupom especial para o evento ou destaque produtos temáticos.`
        });
    }


    setInsights(newInsights.length > 0 ? newInsights : [{ type: 'info', message: "Nenhum insight específico no momento. Continue vendendo!" }]);
  };

  const getInsightCardStyle = (type) => {
    switch(type) {
      case 'highlight': return 'border-green-500 bg-green-50';
      case 'warning': return 'border-red-500 bg-red-50';
      case 'combo': return 'border-blue-500 bg-blue-50';
      case 'timing': return 'border-yellow-500 bg-yellow-50';
      case 'event': return 'border-purple-500 bg-purple-50';
      default: return 'border-gray-300 bg-gray-50';
    }
  };
  
  const getInsightIconColor = (type) => {
     switch(type) {
      case 'highlight': return 'text-green-600';
      case 'warning': return 'text-red-600';
      case 'combo': return 'text-blue-600';
      case 'timing': return 'text-yellow-600';
      case 'event': return 'text-purple-600';
      default: return 'text-gray-600';
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-xl text-gray-700">
            <Lightbulb className="mr-2 h-6 w-6 text-yellow-500" />
            Impulsionador de Vendas (Beta IA 🧠)
          </CardTitle>
           <p className="text-sm text-gray-500">Sugestões automáticas para aumentar seu faturamento.</p>
        </CardHeader>
        <CardContent className="space-y-4">
            <Button onClick={generateInsights} className="mb-4 bg-purple-600 hover:bg-purple-700">Analisar e Gerar Novas Sugestões</Button>
          {insights.length === 0 ? (
            <p className="text-gray-500">Clique no botão para gerar insights.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {insights.map((insight, index) => {
                const Icon = insight.icon || AlertTriangle;
                return (
                  <Card key={index} className={`shadow-md ${getInsightCardStyle(insight.type)}`}>
                    <CardHeader className="pb-2">
                      <CardTitle className={`text-base flex items-center ${getInsightIconColor(insight.type)}`}>
                        <Icon className="h-5 w-5 mr-2"/>
                        {insight.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm">
                      <p className="text-gray-700">{insight.message}</p>
                      {insight.suggestion && <p className="mt-2 pt-2 border-t font-medium text-purple-700">{insight.suggestion}</p>}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}