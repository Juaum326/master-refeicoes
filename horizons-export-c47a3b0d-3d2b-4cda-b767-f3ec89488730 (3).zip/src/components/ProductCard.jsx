import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus, ShoppingCart, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

export function ProductCard({ product, categoryType, storeOpen }) {
  const { dispatch, state } = useApp();
  const { settings } = state.settingsState;
  const { visualSettings } = state.visualState;
  const { additionals: globalAdditionals } = state.productState;

  const [quantity, setQuantity] = useState(1);
  const [selectedAdditionals, setSelectedAdditionals] = useState([]);
  const [observations, setObservations] = useState('');
  const [showDetails, setShowDetails] = useState(false);

  const availableProductAdditionals = product.additionals || [];

  const availableAdditionals = globalAdditionals.filter(globalAdd => 
    availableProductAdditionals.some(prodAdd => prodAdd.id === globalAdd.id && prodAdd.available && globalAdd.available)
  ).map(globalAdd => {
    const prodAddInfo = availableProductAdditionals.find(p => p.id === globalAdd.id);
    return { ...globalAdd, price: prodAddInfo?.price ?? globalAdd.price };
  });


  const handleAdditionalToggle = (additional) => {
    setSelectedAdditionals(prev => {
      const exists = prev.find(item => item.id === additional.id);
      if (exists) {
        return prev.filter(item => item.id !== additional.id);
      } else {
        return [...prev, additional];
      }
    });
  };

  const calculateTotal = () => {
    const basePrice = product.price * quantity;
    const additionalsPrice = selectedAdditionals.reduce((total, additional) => 
      total + (additional.price * quantity), 0
    );
    return basePrice + additionalsPrice;
  };

  const handleAddToCart = () => {
    if (!storeOpen || !product.available) {
      toast({
        title: "Produto Indisponível",
        description: `${product.name} não está disponível no momento.`,
        variant: "destructive"
      });
      return;
    }

    const cartItem = {
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity,
      selectedAdditionals,
      observations,
      category: categoryType 
    };

    dispatch({ type: 'ADD_TO_CART', payload: cartItem });
    
    toast({
      title: "Adicionado ao carrinho!",
      description: `${product.name} foi adicionado com sucesso.`,
    });

    setQuantity(1);
    setSelectedAdditionals([]);
    setObservations('');
    setShowDetails(false);
  };

  const cardClasses = `h-full overflow-hidden transition-all duration-300 ${
    (storeOpen && product.available) ? 'hover:border-dynamic-primary' : 'opacity-60 border-gray-300'
  }`;
  const buttonClasses = `w-full dynamic-button ${
    (!storeOpen || !product.available) && 'bg-gray-400 cursor-not-allowed hover:bg-gray-400'
  }`;

  return (
    <motion.div
      className={`food-card ${(!storeOpen || !product.available) ? 'pointer-events-none' : ''}`}
      style={{ borderColor: visualSettings.colors.primary+'33' }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={(storeOpen && product.available) ? { scale: 1.02 } : {}}
    >
      <Card className={cardClasses}>
        <div className="relative">
          {product.image ? (
            <div className="relative h-48 overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${visualSettings.colors.primary} 0%, ${visualSettings.colors.secondary} 100%)`}}>
              <img   className="w-full h-full object-cover" alt={`Deliciosa ${product.name}`} src="https://images.unsplash.com/photo-1681415722537-e0a220ee0530" />
            </div>
          )}
          {(!storeOpen || !product.available) && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Badge variant="destructive" className="text-sm px-3 py-1">{!storeOpen ? "Loja Fechada" : "Indisponível"}</Badge>
            </div>
          )}
        </div>
        

        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg" style={{color: visualSettings.colors.primary}}>{product.name}</CardTitle>
            <Badge className="dynamic-badge">
              R$ {product.price.toFixed(2)}
            </Badge>
          </div>
          <p className="text-sm" style={{color: visualSettings.colors.textSecondary}}>{product.description}</p>
        </CardHeader>

        <CardContent className="space-y-4">
          {!showDetails ? (
            <Button
              onClick={() => (storeOpen && product.available) && setShowDetails(true)}
              className={buttonClasses}
              disabled={!storeOpen || !product.available}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Personalizar e Adicionar
            </Button>
          ) : (
            <motion.div
              className="space-y-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium" style={{color: visualSettings.colors.primary}}>Quantidade:</span>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="h-8 w-8 p-0 dynamic-button-outline"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="font-medium w-8 text-center" style={{color: visualSettings.colors.textSecondary}}>{quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                    className="h-8 w-8 p-0 dynamic-button-outline"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {availableAdditionals && availableAdditionals.length > 0 && (
                <div className="space-y-2">
                  <span className="font-medium" style={{color: visualSettings.colors.primary}}>Adicionais:</span>
                  {availableAdditionals.map((additional) => (
                    <label
                      key={additional.id}
                      className={`flex items-center justify-between p-2 border rounded-lg cursor-pointer hover-dynamic-primary-bg-light ${!additional.available ? 'opacity-50 cursor-not-allowed' : ''}`}
                      style={{borderColor: visualSettings.colors.primary+'55'}}
                    >
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={selectedAdditionals.some(item => item.id === additional.id)}
                          onChange={() => additional.available && handleAdditionalToggle(additional)}
                          className="rounded focus:ring-dynamic-primary"
                          style={{borderColor: visualSettings.colors.primary+'55', color: visualSettings.colors.primary}}
                          disabled={!additional.available}
                        />
                        <span className={`text-sm ${!additional.available ? 'line-through' : ''}`} style={{color: visualSettings.colors.textSecondary}}>{additional.name}</span>
                      </div>
                      <span className={`text-sm font-medium ${!additional.available ? 'line-through' : ''}`} style={{color: visualSettings.colors.primary}}>
                        +R$ {additional.price.toFixed(2)}
                      </span>
                    </label>
                  ))}
                </div>
              )}

              <div className="space-y-2">
                <label className="font-medium" style={{color: visualSettings.colors.primary}}>Observações:</label>
                <Textarea
                  placeholder="Ex: sem cebola, sem sal, bem passado..."
                  value={observations}
                  onChange={(e) => setObservations(e.target.value)}
                  className="resize-none"
                  style={{borderColor: visualSettings.colors.primary+'55'}}
                  rows={2}
                />
              </div>

              <div className="space-y-3 pt-2 border-t" style={{borderColor: visualSettings.colors.primary+'33'}}>
                <div className="flex justify-between items-center">
                  <span className="font-bold" style={{color: visualSettings.colors.primary}}>Total:</span>
                  <span className="font-bold text-lg" style={{color: visualSettings.colors.primary}}>
                    R$ {calculateTotal().toFixed(2)}
                  </span>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setShowDetails(false)}
                    className="flex-1 dynamic-button-outline hover-dynamic-primary-bg-light"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleAddToCart}
                    className="flex-1 dynamic-button"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}