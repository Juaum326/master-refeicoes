export const initialEventsState = {
  events: [],
  inaugurationDate: null,
};

export function eventsReducer(state, action) {
  switch (action.type) {
    case 'ADD_EVENT':
      const newEvent = { ...action.payload };
      if (newEvent.id === 'inauguracao' && newEvent.active && newEvent.startDate) {
        return {
          ...state,
          inaugurationDate: newEvent.startDate,
          events: [...state.events, newEvent]
        };
      }
      return {
        ...state,
        events: [...state.events, newEvent]
      };
    case 'UPDATE_EVENT':
      const updatedEvent = action.payload;
      let newInaugurationDate = state.inaugurationDate;
      if (updatedEvent.id === 'inauguracao') {
        if (updatedEvent.active && updatedEvent.startDate) {
          newInaugurationDate = updatedEvent.startDate;
        } else if (!updatedEvent.active && state.inaugurationDate === updatedEvent.startDate) {
          newInaugurationDate = null;
        }
      }
      return {
        ...state,
        inaugurationDate: newInaugurationDate,
        events: state.events.map(event => event.id === updatedEvent.id ? updatedEvent : event)
      };
    case 'DELETE_EVENT':
      const eventToDelete = state.events.find(event => event.id === action.payload);
      let resetInaugurationDate = state.inaugurationDate;
      if (eventToDelete && eventToDelete.id === 'inauguracao' && state.inaugurationDate === eventToDelete.startDate) {
        resetInaugurationDate = null;
      }
      return {
        ...state,
        inaugurationDate: resetInaugurationDate,
        events: state.events.filter(event => event.id !== action.payload)
      };
    case 'LOAD_STATE':
      return action.payload.eventsState ? { ...state, ...action.payload.eventsState } : state;
    default:
      return state;
  }
}