export const initialSalesState = {
  orders: [],
  coupons: [
    {
      id: 'PRIMEIRA10',
      name: 'PRIMEIRA10',
      type: 'percentage',
      value: 10,
      limit: 100,
      usedCount: 0,
      singleUsePerCustomer: true,
      usedByCustomers: [],
      validUntil: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split('T')[0], 
      minValue: 20,
      active: true,
    },
    {
      id: 'OFF5',
      name: 'OFF5',
      type: 'fixed',
      value: 5,
      limit: 50,
      usedCount: 0,
      singleUsePerCustomer: false,
      usedByCustomers: [],
      validUntil: new Date(new Date().setDate(new Date().getDate() + 15)).toISOString().split('T')[0], 
      minValue: 0,
      active: true,
    }
  ],
};

export function salesReducer(state, action) {
  switch (action.type) {
    case 'ADD_ORDER':
      return {
        ...state,
        orders: [{ ...action.payload, id: Date.now(), status: 'pending', createdAt: new Date().toISOString() }, ...state.orders]
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.orderId ? { ...order, status: action.payload.status } : order
        )
      };
    case 'CANCEL_ORDER':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.orderId ? { ...order, status: 'cancelled', cancellationReason: action.payload.reason } : order
        )
      };
    case 'DELETE_ORDER':
      return {
        ...state,
        orders: state.orders.filter(order => order.id !== action.payload)
      };
    case 'ADD_COUPON':
      return {
        ...state,
        coupons: [...state.coupons, { ...action.payload, id: action.payload.name.toUpperCase(), usedCount: 0, usedByCustomers: [], active: true }]
      };
    case 'UPDATE_COUPON':
      return {
        ...state,
        coupons: state.coupons.map(coupon =>
          coupon.id === action.payload.id ? { ...coupon, ...action.payload } : coupon
        )
      };
    case 'DELETE_COUPON':
      return {
        ...state,
        coupons: state.coupons.filter(coupon => coupon.id !== action.payload)
      };
    case 'INCREMENT_COUPON_USAGE':
      return {
        ...state,
        coupons: state.coupons.map(coupon =>
          coupon.id === action.payload.couponId
            ? {
                ...coupon,
                usedCount: coupon.usedCount + 1,
                usedByCustomers: coupon.singleUsePerCustomer && action.payload.customerIdentifier
                  ? [...coupon.usedByCustomers, action.payload.customerIdentifier]
                  : coupon.usedByCustomers,
                active: (coupon.usedCount + 1) >= coupon.limit ? false : coupon.active,
              }
            : coupon
        )
      };
    case 'LOAD_STATE':
      return action.payload.salesState ? { ...state, ...action.payload.salesState } : state;
    default:
      return state;
  }
}