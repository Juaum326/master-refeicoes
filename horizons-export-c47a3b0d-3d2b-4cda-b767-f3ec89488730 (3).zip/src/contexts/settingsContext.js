export const initialSettingsState = {
  settings: {
    companyName: 'Master Refeições',
    logo: '',
    phone: '(11) 99999-9999',
    whatsapp: '5511999999999',
    whatsappIntegrationEnabled: true,
    address: {
      street: 'Rua das Flores, 123',
      neighborhood: 'Centro',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01234-567'
    },
    openingHours: {
      monday: { open: "08:00", close: "18:00", enabled: true },
      tuesday: { open: "08:00", close: "18:00", enabled: true },
      wednesday: { open: "08:00", close: "18:00", enabled: true },
      thursday: { open: "08:00", close: "18:00", enabled: true },
      friday: { open: "08:00", close: "18:00", enabled: true },
      saturday: { open: "09:00", close: "14:00", enabled: false },
      sunday: { open: "09:00", close: "14:00", enabled: false },
    },
    manualOpen: null, 
    siteTheme: 'light', 
    notificationPreferences: {
      allEnabled: true,
      newOrder: true,
      salesBooster: true,
      intelligentManager: true,
    },
  },
  neighborhoods: [
    { name: 'Centro', fee: 3.00 },
    { name: 'Vila Nova', fee: 4.00 },
    { name: 'Jardim das Flores', fee: 5.00 },
    { name: 'Bairro Alto', fee: 6.00 }
  ],
};

export function settingsReducer(state, action) {
  switch (action.type) {
    case 'UPDATE_SETTINGS':
      return {
        ...state,
        settings: { ...state.settings, ...action.payload }
      };
    case 'UPDATE_NEIGHBORHOODS':
      return {
        ...state,
        neighborhoods: action.payload
      };
    case 'TOGGLE_WHATSAPP_INTEGRATION':
      return {
        ...state,
        settings: {
          ...state.settings,
          whatsappIntegrationEnabled: !state.settings.whatsappIntegrationEnabled,
        },
      };
    case 'UPDATE_NOTIFICATION_PREFERENCES':
      return {
        ...state,
        settings: {
          ...state.settings,
          notificationPreferences: {
            ...state.settings.notificationPreferences,
            ...action.payload,
          }
        }
      };
    case 'LOAD_STATE':
      return action.payload.settingsState ? { ...state, ...action.payload.settingsState } : state;
    default:
      return state;
  }
}