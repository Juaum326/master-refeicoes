export const initialAuthState = {
  isAdminAuthenticated: false,
};

export function authReducer(state, action) {
  switch (action.type) {
    case 'SET_ADMIN_AUTHENTICATED':
      return { ...state, isAdminAuthenticated: action.payload };
    case 'LOGOUT_ADMIN':
      return { ...state, isAdminAuthenticated: false };
    case 'LOAD_STATE':
      return action.payload.authState ? { ...state, ...action.payload.authState } : state;
    default:
      return state;
  }
}