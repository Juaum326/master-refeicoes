export const initialCartState = {
  cart: [],
  customerName: '',
  customerPhone: '', 
  deliveryType: 'delivery',
  deliveryAddress: {
    neighborhood: '',
    street: '',
    number: '',
    complement: '',
    zipCode: '',
  },
  orderObservations: '',
  deliveryFee: 0,
  paymentMethod: '',
  changeFor: '',
  appliedCoupon: null,
};

export function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD_TO_CART':
      const existingItem = state.cart.find(item => 
        item.id === action.payload.id && 
        JSON.stringify(item.selectedAdditionals) === JSON.stringify(action.payload.selectedAdditionals) &&
        item.observations === action.payload.observations
      );
      
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item.id === action.payload.id && 
            JSON.stringify(item.selectedAdditionals) === JSON.stringify(action.payload.selectedAdditionals) &&
            item.observations === action.payload.observations
              ? { ...item, quantity: item.quantity + action.payload.quantity }
              : item
          )
        };
      }
      
      return {
        ...state,
        cart: [...state.cart, { ...action.payload, cartId: Date.now() }]
      };

    case 'REMOVE_FROM_CART':
      return {
        ...state,
        cart: state.cart.filter(item => item.cartId !== action.payload)
      };

    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.cartId === action.payload.cartId
            ? { ...item, quantity: action.payload.quantity }
            : item
        )
      };

    case 'CLEAR_CART':
      return {
        ...state,
        cart: [],
        customerName: '',
        customerPhone: '',
        deliveryAddress: initialCartState.deliveryAddress,
        orderObservations: '',
        paymentMethod: '',
        changeFor: '',
        appliedCoupon: null,
      };

    case 'SET_CUSTOMER_NAME':
      return { ...state, customerName: action.payload };
    
    case 'SET_CUSTOMER_PHONE':
      return { ...state, customerPhone: action.payload };

    case 'SET_ORDER_OBSERVATIONS':
      return { ...state, orderObservations: action.payload };

    case 'SET_DELIVERY_TYPE':
      return {
        ...state,
        deliveryType: action.payload,
        deliveryFee: action.payload === 'pickup' ? 0 : state.deliveryFee,
        deliveryAddress: action.payload === 'pickup' ? initialCartState.deliveryAddress : state.deliveryAddress
      };

    case 'SET_DELIVERY_ADDRESS':
      return {
        ...state,
        deliveryAddress: action.payload.address,
        deliveryFee: action.payload.fee
      };
    
    case 'SET_PAYMENT_METHOD':
      return { ...state, paymentMethod: action.payload };

    case 'SET_CHANGE_FOR':
      return { ...state, changeFor: action.payload };

    case 'APPLY_COUPON':
      return { ...state, appliedCoupon: action.payload };

    case 'REMOVE_COUPON':
      return { ...state, appliedCoupon: null };
      
    case 'LOAD_STATE':
      return action.payload.cartState ? { ...state, ...action.payload.cartState } : state;

    default:
      return state;
  }
}