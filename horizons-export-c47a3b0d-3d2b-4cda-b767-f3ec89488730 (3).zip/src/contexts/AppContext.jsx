import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { cartReducer, initialCartState } from './cartContext';
import { settingsReducer, initialSettingsState } from './settingsContext';
import { productReducer, initialProductState } from './productContext';
import { visualReducer, initialVisualState } from './visualContext';
import { authReducer, initialAuthState } from './authContext';
import { salesReducer, initialSalesState } from './salesContext';
import { eventsReducer, initialEventsState } from './eventsContext';

const AppContext = createContext();

function mainReducer(state, action) {
  const nextState = {
    cartState: cartReducer(state.cartState, action),
    settingsState: settingsReducer(state.settingsState, action),
    productState: productReducer(state.productState, action),
    visualState: visualReducer(state.visualState, action),
    authState: authReducer(state.authState, action),
    salesState: salesReducer(state.salesState, action),
    eventsState: eventsReducer(state.eventsState, action),
  };

  if (action.type === 'LOAD_STATE' && action.payload) {
    return {
      cartState: cartReducer(action.payload.cartState || initialCartState, action),
      settingsState: settingsReducer(action.payload.settingsState || initialSettingsState, action),
      productState: productReducer(action.payload.productState || initialProductState, action),
      visualState: visualReducer(action.payload.visualState || initialVisualState, action),
      authState: authReducer(action.payload.authState || initialAuthState, action),
      salesState: salesReducer(action.payload.salesState || initialSalesState, action),
      eventsState: eventsReducer(action.payload.eventsState || initialEventsState, action),
    };
  }
  
  if (action.type === 'LOGOUT_ADMIN' || action.type === 'LOGOUT_SALES_MANAGER') {
    const freshAuthState = authReducer(state.authState, action);
    return { ...nextState, authState: freshAuthState };
  }

  return nextState;
}

const combinedInitialState = {
  cartState: initialCartState,
  settingsState: initialSettingsState,
  productState: initialProductState,
  visualState: initialVisualState,
  authState: initialAuthState,
  salesState: initialSalesState,
  eventsState: initialEventsState,
};

export function AppProvider({ children }) {
  const [persistedState, setPersistedState] = useLocalStorage('masterRefeicoesV2_RefactoredEvents', combinedInitialState); 
  
  const [state, dispatch] = useReducer(mainReducer, persistedState || combinedInitialState);

  useEffect(() => {
    dispatch({ type: 'LOAD_STATE', payload: persistedState || combinedInitialState });
  }, []);

  useEffect(() => {
    if (state !== persistedState) {
      setPersistedState(state);
    }
  }, [state, setPersistedState, persistedState]);
  
  useEffect(() => {
    if (state.settingsState && state.settingsState.settings && state.visualState && state.visualState.visualSettings && state.visualState.visualSettings.images) {
      const currentSettingsLogo = state.settingsState.settings.logo;
      const currentVisualLogo = state.visualState.visualSettings.images.logo;

      if (currentSettingsLogo !== currentVisualLogo && currentVisualLogo !== undefined && currentSettingsLogo !== undefined) {
         dispatch({
          type: 'UPDATE_VISUAL_SETTINGS',
          payload: {
            images: { logo: currentSettingsLogo }
          }
        });
      }
    }
  }, [state.settingsState, state.visualState]);


  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}