export const initialProductState = {
  products: [
    {
      id: 1,
      name: 'Quentinha Tradicional',
      description: 'Arroz, feijão, carne, salada e farofa',
      price: 15.90,
      image: '',
      category: 'quentinhas',
      available: true,
      order: 0,
      additionals: [
        { id: 1, name: 'Arroz Extra', price: 2.00, available: true },
        { id: 2, name: 'Feijão Extra', price: 2.00, available: true },
        { id: 3, name: 'Salada Extra', price: 3.00, available: true }
      ]
    },
    {
      id: 2,
      name: 'Quentinha Premium',
      description: 'Arroz, feijão, picanha, salada gourmet e farofa especial',
      price: 22.90,
      image: '',
      category: 'quentinhas',
      available: true,
      order: 1,
      additionals: [
        { id: 1, name: 'Arroz Extra', price: 2.00, available: true },
        { id: 2, name: 'Feijão Extra', price: 2.00, available: true },
        { id: 3, name: 'Salada Extra', price: 3.00, available: true }
      ]
    }
  ],
  beverages: [
    {
      id: 3,
      name: 'Refrigerante Lata',
      description: 'Coca-Cola, Pepsi, Guaraná',
      price: 4.50,
      image: '',
      category: 'bebidas',
      available: true,
      order: 0,
    },
    {
      id: 4,
      name: 'Suco Natural',
      description: 'Laranja, limão, maracujá',
      price: 6.00,
      image: '',
      category: 'bebidas',
      available: true,
      order: 1,
    }
  ],
  sides: [
    {
      id: 5,
      name: 'Batata Frita',
      description: 'Porção individual de batata frita crocante',
      price: 8.00,
      image: '',
      category: 'acompanhamentos',
      available: true,
      order: 0,
    },
    {
      id: 6,
      name: 'Mandioca Frita',
      description: 'Porção individual de mandioca frita',
      price: 7.00,
      image: '',
      category: 'acompanhamentos',
      available: true,
      order: 1,
    }
  ],
  categories: [
    { id: 'quentinhas', name: 'Quentinhas', order: 0 },
    { id: 'bebidas', name: 'Bebidas', order: 1 },
    { id: 'acompanhamentos', name: 'Acompanhamentos', order: 2 }
  ],
  additionals: [
    { id: 1, name: 'Arroz Extra', price: 2.00, available: true },
    { id: 2, name: 'Feijão Extra', price: 2.00, available: true },
    { id: 3, name: 'Salada Extra', price: 3.00, available: true },
    { id: 4, name: 'Carne Extra', price: 5.00, available: true },
  ],
  neighborhoods: [
    { name: 'Centro', fee: 3.00 },
    { name: 'Vila Nova', fee: 4.00 },
    { name: 'Jardim das Flores', fee: 5.00 },
    { name: 'Bairro Alto', fee: 6.00 }
  ],
};

export function productReducer(state, action) {
  switch (action.type) {
    case 'ADD_PRODUCT':
      const newProduct = { ...action.payload, id: Date.now(), available: true, order: state[action.payload.category === 'quentinhas' ? 'products' : action.payload.category === 'bebidas' ? 'beverages' : 'sides'].length };
      const targetArray = action.payload.category === 'quentinhas' ? 'products' : 
                         action.payload.category === 'bebidas' ? 'beverages' : 'sides';
      return {
        ...state,
        [targetArray]: [...state[targetArray], newProduct]
      };

    case 'UPDATE_PRODUCT':
      const { category: oldCategory, ...productToUpdate } = action.payload;
      const updateTargetArray = productToUpdate.category === 'quentinhas' ? 'products' : 
                               productToUpdate.category === 'bebidas' ? 'beverages' : 'sides';
      
      let newState = { ...state };
      
      if (oldCategory && oldCategory !== productToUpdate.category) {
        const oldTargetArray = oldCategory === 'quentinhas' ? 'products' : 
                               oldCategory === 'bebidas' ? 'beverages' : 'sides';
        newState[oldTargetArray] = newState[oldTargetArray].filter(item => item.id !== productToUpdate.id);
        newState[updateTargetArray] = [...newState[updateTargetArray], productToUpdate];
      } else {
        newState[updateTargetArray] = newState[updateTargetArray].map(item =>
          item.id === productToUpdate.id ? productToUpdate : item
        );
      }
      return newState;

    case 'DELETE_PRODUCT':
      const { productId, productCategory } = action.payload;
      const deleteTargetArray = productCategory === 'quentinhas' ? 'products' :
                               productCategory === 'bebidas' ? 'beverages' : 'sides';
      return {
        ...state,
        [deleteTargetArray]: state[deleteTargetArray].filter(item => item.id !== productId)
      };
    
    case 'TOGGLE_PRODUCT_AVAILABILITY':
      const { id: toggleId, category: toggleCategory } = action.payload;
      const toggleTargetArray = toggleCategory === 'quentinhas' ? 'products' : 
                                toggleCategory === 'bebidas' ? 'beverages' : 'sides';
      return {
        ...state,
        [toggleTargetArray]: state[toggleTargetArray].map(p => 
          p.id === toggleId ? { ...p, available: !p.available } : p
        )
      };
    
    case 'TOGGLE_PRODUCT_ADDITIONAL_AVAILABILITY':
      const { productId: prodId, productCategory: prodCat, additionalId: addId } = action.payload;
      const targetProdArray = prodCat === 'quentinhas' ? 'products' :
                              prodCat === 'bebidas' ? 'beverages' : 'sides';
      return {
        ...state,
        [targetProdArray]: state[targetProdArray].map(p =>
          p.id === prodId ? {
            ...p,
            additionals: p.additionals?.map(add =>
              add.id === addId ? { ...add, available: !add.available } : add
            )
          } : p
        )
      };

    case 'UPDATE_CATEGORIES':
      return { ...state, categories: action.payload };

    case 'UPDATE_ADDITIONALS':
      return { ...state, additionals: action.payload };
    
    case 'TOGGLE_GLOBAL_ADDITIONAL_AVAILABILITY':
      return {
        ...state,
        additionals: state.additionals.map(add => 
          add.id === action.payload ? { ...add, available: !add.available } : add
        )
      };

    case 'UPDATE_NEIGHBORHOODS':
      return {
        ...state,
        neighborhoods: action.payload
      };
    case 'LOAD_STATE':
      return action.payload.productState ? { ...state, ...action.payload.productState } : state;
    default:
      return state;
  }
}