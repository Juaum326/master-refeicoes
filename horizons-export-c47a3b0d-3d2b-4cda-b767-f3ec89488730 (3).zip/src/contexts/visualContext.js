export const initialVisualState = {
  visualSettings: {
    colors: {
      primary: '#8b5cf6', 
      secondary: '#a855f7', 
      background: '#f8fafc', 
      textPrimary: '#1e293b', 
      textSecondary: '#475569', 
      buttonBackground: '#8b5cf6',
      buttonText: '#ffffff',
    },
    fonts: {
      titles: { family: 'Inter, sans-serif', size: 24 }, 
      body: { family: 'Inter, sans-serif', size: 16 },
      buttons: { family: 'Inter, sans-serif', size: 14 },
    },
    layout: [ 
      { id: 'header', name: 'Cabeçalho', visible: true },
      { id: 'banner', name: 'Banner Principal', visible: true },
      { id: 'deliverySelector', name: 'Seleção de Entrega/Retirada', visible: true },
      { id: 'menu', name: 'Cardápio', visible: true },
      { id: 'footer', name: 'Rodapé', visible: true },
    ],
    images: {
      logo: '', 
      banner: 'https://images.unsplash.com/photo-1603247117933-b74e87c5fdb7', 
      bannerAlt: 'Pratos deliciosos servidos em embalagens para delivery',
      siteBackground: '',
    },
    texts: {
      bannerTitle: '', 
      bannerSubtitle: 'As melhores quentinhas da região com entrega rápida e sabor incomparável.',
      buttonOrderNow: 'Fazer Pedido',
      buttonViewMenu: 'Ver Cardápio',
      footerInfo: 'Todos os direitos reservados.',
      footerTagline: 'Feito com ❤️ para levar sabor até você!',
      welcomeMessage: '',
      promoMessage: '',
    },
    animations: {
      enabled: true,
    },
    themes: [], 
    activeTheme: null, 
  }
};

export function visualReducer(state, action) {
  switch (action.type) {
    case 'UPDATE_VISUAL_SETTINGS':
      return {
        ...state,
        visualSettings: {
          ...state.visualSettings,
          ...action.payload,
          colors: { ...state.visualSettings.colors, ...action.payload.colors },
          fonts: { ...state.visualSettings.fonts, ...action.payload.fonts },
          images: { ...state.visualSettings.images, ...action.payload.images },
          texts: { ...state.visualSettings.texts, ...action.payload.texts },
          animations: { ...state.visualSettings.animations, ...action.payload.animations },
        }
      };
    
    case 'SAVE_THEME':
      const newTheme = { id: Date.now(), name: action.payload.name, settings: action.payload.settings };
      return {
        ...state,
        visualSettings: {
          ...state.visualSettings,
          themes: [...state.visualSettings.themes, newTheme],
          activeTheme: newTheme.id,
        }
      };

    case 'LOAD_THEME':
      const themeToLoad = state.visualSettings.themes.find(t => t.id === action.payload);
      if (themeToLoad) {
        return {
          ...state,
          visualSettings: {
            ...state.visualSettings,
            ...themeToLoad.settings,
            activeTheme: themeToLoad.id,
          }
        };
      }
      return state;
    
    case 'RESET_DEFAULT_THEME':
      return {
        ...state,
        visualSettings: {
          ...initialVisualState.visualSettings, 
          themes: state.visualSettings.themes, 
          activeTheme: null, 
          images: {
            ...initialVisualState.visualSettings.images,
            logo: action.payload.currentLogo || initialVisualState.visualSettings.images.logo, 
          }
        }
      };
    case 'LOAD_STATE':
      if (action.payload.visualState) {
        return {
          ...state,
          visualSettings: {
            ...initialVisualState.visualSettings,
            ...action.payload.visualState.visualSettings,
            images: {
              ...initialVisualState.visualSettings.images,
              ...(action.payload.visualState.visualSettings?.images || {}),
              logo: action.payload.settingsState?.settings?.logo || initialVisualState.visualSettings.images.logo,
            }
          }
        };
      }
      return state;
    default:
      return state;
  }
}