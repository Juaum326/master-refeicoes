import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AppProvider, useApp } from '@/contexts/AppContext';
import { Header } from '@/components/Header';
import { DeliverySelector } from '@/components/DeliverySelector';
import { Menu } from '@/components/Menu';
import { Cart } from '@/components/cart/Cart.jsx';
import { AdminLogin } from '@/components/admin/AdminLogin';
import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { Toaster } from '@/components/ui/toaster';
import { DndProvider } from '@/components/admin/visual-editor/DndProvider.jsx';
import { NotificationBell } from '@/components/NotificationBell.jsx';
import { differenceInDays, parseISO } from 'date-fns';

function CustomerApp() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { state } = useApp();
  const { settings } = state.settingsState || { settings: {} };
  const { events = [], inaugurationDate = null } = state.eventsState || {};
  const { visualSettings } = state.visualState || { visualSettings: { colors: {}, fonts: { titles:{}, body:{}, buttons:{} }, images: {}, texts: {}, layout: [] } };
  
  const [daysSinceInauguration, setDaysSinceInauguration] = useState(0);

  useEffect(() => {
    if (inaugurationDate) {
      const diff = differenceInDays(new Date(), parseISO(inaugurationDate));
      setDaysSinceInauguration(Math.max(0, diff)); 
    } else {
      setDaysSinceInauguration(0);
    }
  }, [inaugurationDate]);

  useEffect(() => {
    const root = document.documentElement;
    
    let activePrimary = visualSettings.colors.primary || '#8b5cf6';
    let activeSecondary = visualSettings.colors.secondary || '#a855f7';
    let activeBackground = visualSettings.colors.background || '#f8fafc';
    let activeTextPrimary = visualSettings.colors.textPrimary || '#1e293b';
    let activeTextSecondary = visualSettings.colors.textSecondary || '#475569';
    let activeButtonBackground = visualSettings.colors.buttonBackground || '#8b5cf6';
    let activeButtonText = visualSettings.colors.buttonText || '#ffffff';

    let activeSiteBackground = visualSettings.images.siteBackground;
    let activeLogo = visualSettings.images.logo;
    let activeBannerText = visualSettings.texts.bannerTitle;


    const today = new Date();
    const activeEventsList = (events || [])
      .filter(event => {
        if (!event || !event.startDate || !event.endDate) return false;
        const startDate = new Date(event.startDate + 'T00:00:00');
        const endDate = new Date(event.endDate + 'T23:59:59');
        return event.active && today >= startDate && today <= endDate;
      })
      .sort((a, b) => (b.priority || 0) - (a.priority || 0));

    if (activeEventsList.length > 0) {
      const currentEventTheme = activeEventsList[0].theme;
      if (currentEventTheme) {
        activePrimary = currentEventTheme.primaryColor || activePrimary;
        activeSecondary = currentEventTheme.secondaryColor || activeSecondary;
        activeBackground = currentEventTheme.backgroundColor || activeBackground;
        activeTextPrimary = currentEventTheme.textPrimaryColor || activeTextPrimary;
        activeTextSecondary = currentEventTheme.textSecondaryColor || activeTextSecondary;
        activeButtonBackground = currentEventTheme.buttonBackgroundColor || activeButtonBackground;
        activeButtonText = currentEventTheme.buttonTextColor || activeButtonText;

        activeSiteBackground = currentEventTheme.siteBackground || activeSiteBackground;
        activeLogo = currentEventTheme.logoOverride || activeLogo;
        activeBannerText = currentEventTheme.bannerText || activeBannerText;
        if (currentEventTheme.customCSS) {
          const styleTagId = 'event-custom-css';
          let styleTag = document.getElementById(styleTagId);
          if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = styleTagId;
            document.head.appendChild(styleTag);
          }
          styleTag.innerHTML = currentEventTheme.customCSS;
        }
      }
    } else {
        const styleTag = document.getElementById('event-custom-css');
        if (styleTag) styleTag.innerHTML = '';
    }
    
    root.style.setProperty('--primary-dynamic', activePrimary);
    root.style.setProperty('--secondary-dynamic', activeSecondary);
    root.style.setProperty('--background-dynamic', activeBackground);
    root.style.setProperty('--text-primary-dynamic', activeTextPrimary);
    root.style.setProperty('--text-secondary-dynamic', activeTextSecondary);
    root.style.setProperty('--button-bg-dynamic', activeButtonBackground);
    root.style.setProperty('--button-text-dynamic', activeButtonText);

    const primaryRGBString = activePrimary.startsWith('#') ? activePrimary.slice(1) : '8b5cf6';
    const primaryRGB = parseInt(primaryRGBString, 16);
    const primaryR = (primaryRGB >> 16) & 0xff;
    const primaryG = (primaryRGB >> 8) & 0xff;
    const primaryB = (primaryRGB >> 0) & 0xff;
    root.style.setProperty('--primary-dynamic_rgb', `${primaryR}, ${primaryG}, ${primaryB}`);
    
    const buttonBgRGBString = activeButtonBackground.startsWith('#') ? activeButtonBackground.slice(1) : '8b5cf6';
    const buttonBgRGB = parseInt(buttonBgRGBString, 16);
    const buttonR = (buttonBgRGB >> 16) & 0xff;
    const buttonG = (buttonBgRGB >> 8) & 0xff;
    const buttonB = (buttonBgRGB >> 0) & 0xff;
    root.style.setProperty('--button-bg-dynamic_rgb', `${buttonR}, ${buttonG}, ${buttonB}`);

    root.style.setProperty('--font-titles', visualSettings.fonts.titles.family || 'Inter, sans-serif');
    root.style.setProperty('--font-body', visualSettings.fonts.body.family || 'Inter, sans-serif');
    root.style.setProperty('--font-buttons', visualSettings.fonts.buttons.family || 'Inter, sans-serif');
    
    if (settings.siteTheme === 'dark') {
      document.documentElement.classList.add('dark');
       root.style.setProperty('--background-dynamic', '#1e293b'); 
       root.style.setProperty('--text-primary-dynamic', '#f8fafc');
       root.style.setProperty('--text-secondary-dynamic', '#94a3b8');
    } else {
      document.documentElement.classList.remove('dark');
    }

  }, [visualSettings, settings.siteTheme, events, inaugurationDate]);

  const getSectionComponent = (sectionId) => {
    let activeBannerText = visualSettings.texts.bannerTitle || (settings && settings.companyName) || "Sabor que Conquista!";
    let activeLogo = visualSettings.images.logo;
    let activeSiteBackground = visualSettings.images.siteBackground;
    
    const today = new Date();
    const activeEventsList = (events || [])
      .filter(event => {
        if (!event || !event.startDate || !event.endDate) return false;
        const startDate = new Date(event.startDate + 'T00:00:00');
        const endDate = new Date(event.endDate + 'T23:59:59');
        return event.active && today >= startDate && today <= endDate;
      })
      .sort((a, b) => (b.priority || 0) - (a.priority || 0));

    let currentEventIcon = '🍽️';
    let currentEvent = null;
    if (activeEventsList.length > 0) {
      currentEvent = activeEventsList[0];
      const currentEventTheme = currentEvent.theme;
      if (currentEventTheme) {
        activeBannerText = currentEventTheme.bannerText || activeBannerText;
        activeLogo = currentEventTheme.logoOverride || activeLogo;
        activeSiteBackground = currentEventTheme.siteBackground || activeSiteBackground;
      }
      currentEventIcon = currentEvent.icon || '🍽️';
    }


    switch(sectionId) {
      case 'header': return <Header onCartClick={() => setIsCartOpen(true)} logoOverride={activeLogo} />;
      case 'banner': 
        let bannerTitle = activeBannerText;
        if (currentEvent && currentEvent.id === 'inauguracao' && daysSinceInauguration >= 0) {
          bannerTitle = `${activeBannerText} - ${daysSinceInauguration} dias de sucesso!`;
        }
        return (
        <div className="text-center py-12 relative">
          {activeSiteBackground && (
            <div 
              className="absolute inset-0 bg-cover bg-center opacity-20"
              style={{ backgroundImage: `url(${activeSiteBackground})`}}
            />
          )}
          <div className="relative z-10">
            <motion.h1 
              className="text-4xl md:text-6xl font-bold mb-4 dynamic-text-gradient"
              style={{ fontFamily: 'var(--font-titles)', fontSize: `${visualSettings.fonts.titles.size || 24}px` }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              {bannerTitle} {currentEventIcon}
            </motion.h1>
            <motion.p 
              className="text-xl mb-8"
              style={{ color: 'var(--text-secondary-dynamic)', fontFamily: 'var(--font-body)', fontSize: `${visualSettings.fonts.body.size || 16}px` }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              {visualSettings.texts.bannerSubtitle || "As melhores quentinhas da região com entrega rápida e sabor incomparável"}
            </motion.p>
            
            <motion.div
              className="flex justify-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <img      
                className="w-full max-w-md h-64 object-cover rounded-2xl shadow-2xl floating-animation"
                alt={visualSettings.images.bannerAlt || "Delicious lunch boxes"}
               src="https://images.unsplash.com/photo-1696935324424-97fcec9f3654" />
            </motion.div>
          </div>
        </div>
      );
      case 'deliverySelector': return <DeliverySelector />;
      case 'menu': return <Menu />;
      default: return null;
    }
  };


  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--background-dynamic)', color: 'var(--text-primary-dynamic)' }}>
      <style>
        {`
          h1, h2, h3, h4, h5, h6 {
            font-family: var(--font-titles);
          }
          p, span, div, li, label, input, select, textarea, button { 
            font-family: var(--font-body);
          }
          .text-4xl { font-size: ${(visualSettings.fonts.titles.size || 24) * 1.5}px !important; } 
          .text-6xl { font-size: ${(visualSettings.fonts.titles.size || 24) * 2}px !important; } 
          .text-xl { font-size: ${(visualSettings.fonts.body.size || 16) * 1.25}px !important; } 
          .text-lg { font-size: ${(visualSettings.fonts.body.size || 16) * 1.125}px !important; }
          .text-sm { font-size: ${(visualSettings.fonts.body.size || 16) * 0.875}px !important; }
          .text-xs { font-size: ${(visualSettings.fonts.body.size || 16) * 0.75}px !important; }
        `}
      </style>
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          {(visualSettings.layout || []).filter(s => s.visible).map(section => (
            <React.Fragment key={section.id}>
              {getSectionComponent(section.id)}
            </React.Fragment>
          ))}
        </motion.div>
      </main>

      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      
      {(visualSettings.layout || []).find(s => s.id === 'footer' && s.visible) && (
        <footer className="py-8 mt-16" style={{ backgroundColor: 'var(--primary-dynamic)' }}>
          <div className="container mx-auto px-4 text-center">
            <p style={{ color: 'var(--button-text-dynamic)', fontFamily: 'var(--font-body)' }}>
              © {new Date().getFullYear()} {settings.companyName}. {visualSettings.texts.footerInfo || "Todos os direitos reservados."}
            </p>
            <p className="text-sm mt-2" style={{color: 'var(--button-text-dynamic)', opacity: 0.8, fontFamily: 'var(--font-body)' }}>
              {visualSettings.texts.footerTagline || "Feito com ❤️ para levar sabor até você!"}
            </p>
          </div>
        </footer>
      )}
    </div>
  );
}

function ProtectedRoute({ children, isAuthenticated, redirectTo = "/login/admin" }) {
  const location = useLocation();
  if (!isAuthenticated) {
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }
  return children;
}

function AppContent() {
  const { state } = useApp();
  const { isAdminAuthenticated } = state.authState || { isAdminAuthenticated: false };
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (isAdminAuthenticated && location.pathname.startsWith('/login')) {
      navigate('/admin', { replace: true });
    }
  }, [isAdminAuthenticated, navigate, location]);

  return (
    <>
      <Routes>
        <Route path="/" element={<CustomerApp />} />
        
        <Route 
          path="/admin" 
          element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated} redirectTo="/login/admin">
              <DndProvider>
                <AdminDashboard />
              </DndProvider>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/login/admin"
          element={ isAdminAuthenticated ? <Navigate to="/admin" replace /> : <AdminLogin /> }
        />
                
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {isAdminAuthenticated && <NotificationBell />}
    </>
  );
}

function App() {
  return (
    <AppProvider>
      <Router>
        <AppContent />
        <Toaster />
      </Router>
    </AppProvider>
  );
}

export default App;